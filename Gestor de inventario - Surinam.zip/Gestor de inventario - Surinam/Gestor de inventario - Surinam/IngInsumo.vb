﻿Public Class IngInsumo
    Public cedu, numI As String
    Dim clas = New Clase()
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub registrar_Click(sender As Object, e As EventArgs) Handles registrar.Click
        Dim completo As Integer = 0
        'en cada uno de los siguientes "If" se comprobaran los datos, si no estan vacios, si tienen ciertos caracteres,etc
        'si los datos son correctos se sumara en cuenta uno en uno
        'se comprobara en el ultimo if si todos lod datos minimos requeridos fueron ingresados y se registra
        If (clas.vacio(nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (clas.vacio(Estado.Text()) = "false") Then
            Est.ForeColor = ForeColor.Red
        Else
            Est.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Categoria.SelectedItem = "") Then
            Cat.Visible = True
        Else
            Cat.Visible = False
            completo += 1
        End If
        If ((Tipo.SelectedIndex + 1) = 0) Then
            T.Visible = True
        Else
            T.Visible = False
            completo += 1
        End If
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6T" Or lugar.SelectedItem = "Sala") Then
            rLugar.Visible = False
            completo += 1
        Else
            If (lugar.SelectedItem = "" OrElse localizado.Text = "") Then

                rLugar.Visible = True
            Else
                rLugar.Visible = False
                completo += 1
            End If
        End If
        If (CompDon.SelectedItem = "Comprado") Then
            completo += 1
            Drequerido.Visible = False
        Else
            If (donador.Text = "") Then
                Drequerido.Visible = True
            Else
                completo += 1
                Drequerido.Visible = False
            End If
        End If
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            completo += 1
        End If
        If (repe.Text > 0) Then
            regis.ForeColor = ForeColor.Black
            completo += 1
        ElseIf (repe.Text = "") Then
            regis.ForeColor = ForeColor.Red
        Else
            regis.ForeColor = ForeColor.Red
        End If
        Dim ree As Integer = CInt(repe.Text)

        If (numI = "") Then
            If (compra.SelectedItem = "") Then
                com.ForeColor = ForeColor.Red
            Else
                completo += 1
            End If

            If (completo = 9) Then
                clas.altaInsumo(cedu, ree, 0)

            End If
        Else
            If (completo = 8) Then
                clas.altaInsumo(cedu, ree, numI)
                Me.Close()
            End If
        End If
    End Sub

    Private Sub Cant_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles compra.SelectedIndexChanged
        If (compra.SelectedIndex = 0) Then
            CantidadComprar.Visible = True
            Label7.Visible = True
        Else
            CantidadComprar.Visible = False
            Label7.Visible = False
        End If

        If (compra.SelectedItem = "") Then
            com.ForeColor = ForeColor.Red
        Else
            com.ForeColor = ForeColor.Black
        End If

    End Sub
    Private Sub soporte_SelectedIndexChanged(sender As Object, e As EventArgs) Handles soporte.SelectedIndexChanged
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            sop.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub lugar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lugar.SelectedIndexChanged
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6T" Or lugar.SelectedItem = "Sala") Then
            localizado.Visible = False
        Else
            localizado.Visible = True
        End If
        If (lugar.SelectedItem = "Oficina") Then
            Label1.Visible = True
        Else
            Label1.Visible = False
        End If


    End Sub

    Private Sub IngInsumo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.rellenarTipoIng()
        CompDon.SelectedItem = "Comprado"
        Tipo.Text = "Tipo"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipoYEditarContrase.Visible = True
    End Sub

    Private Sub CompDon_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CompDon.SelectedIndexChanged
        If (CompDon.SelectedItem = "Comprado") Then
            donador.Visible = False
        Else
            donador.Visible = True
        End If
    End Sub
End Class