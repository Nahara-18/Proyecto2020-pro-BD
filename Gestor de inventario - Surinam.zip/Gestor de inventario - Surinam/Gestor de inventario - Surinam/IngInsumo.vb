﻿Public Class IngInsumo
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub registrar_Click(sender As Object, e As EventArgs) Handles registrar.Click
        If (Modulo.vacio(nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
        End If
        If (Modulo.vacio(Cant.Text()) = "false") Then
            C.ForeColor = ForeColor.Red
        Else
            C.ForeColor = ForeColor.Black
        End If
        If (Modulo.vacio(Estado.Text()) = "false") Then
            Est.ForeColor = ForeColor.Red
        Else
            Est.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub Cant_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Cant.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
End Class