﻿Public Class IngInsumo
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub registrar_Click(sender As Object, e As EventArgs) Handles registrar.Click
        Dim completo As Integer = 0
        'en cada uno de los siguientes "If" se comprobaran los datos, si no estan vacios, si tienen ciertos caracteres,etc
        'si los datos son correctos se sumara en cuenta uno en uno
        'se comprobara en el ultimo if si todos lod datos minimos requeridos fueron ingresados y se registra
        If (Modulo.vacio(nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.vacio(Estado.Text()) = "false") Then
            Est.ForeColor = ForeColor.Red
        Else
            Est.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Categoria.SelectedItem = "") Then
            Cat.Visible = True
        Else
            Cat.Visible = False
            completo += 1
        End If
        If ((Tipo.SelectedIndex + 1) = 0) Then
            T.Visible = True
        Else
            T.Visible = False
            completo += 1
        End If
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6°T") Then
            rLugar.Visible = False
            completo += 1
        Else
            If (lugar.SelectedItem = "" OrElse localizado.Text = "") Then

                rLugar.Visible = True
            Else
                rLugar.Visible = False
                completo += 1
            End If
        End If
        If (compra.SelectedItem = "") Then
            com.ForeColor = ForeColor.Red
        Else
            completo += 1
        End If
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            completo += 1
        End If

        If (completo = 7) Then
            Modulo.altaInsumo()
        End If
    End Sub

    Private Sub Cant_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
    Private Sub ComboBox4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles compra.SelectedIndexChanged
        If (compra.SelectedIndex = 0) Then
            CantidadComprar.Visible = True
            Label7.Visible = True
        Else
            CantidadComprar.Visible = False
            Label7.Visible = False
        End If

        If (compra.SelectedItem = "") Then
            com.ForeColor = ForeColor.Red
        Else
            com.ForeColor = ForeColor.Black
        End If

    End Sub
    Private Sub soporte_SelectedIndexChanged(sender As Object, e As EventArgs) Handles soporte.SelectedIndexChanged
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            sop.ForeColor = ForeColor.Black
        End If
    End Sub

    Private Sub lugar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lugar.SelectedIndexChanged
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6°T") Then
            localizado.Visible = False
        Else
            localizado.Visible = True
        End If
    End Sub

    Private Sub IngInsumo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Modulo.rellenarTipo()
        Tipo.Text = "Tipo"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipo.Visible = True
    End Sub
End Class