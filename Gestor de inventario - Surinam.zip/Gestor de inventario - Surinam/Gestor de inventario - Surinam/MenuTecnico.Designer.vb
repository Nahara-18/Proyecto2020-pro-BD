﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuTecnico
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ingreso = New System.Windows.Forms.Button()
        Me.editar = New System.Windows.Forms.Button()
        Me.tickets = New System.Windows.Forms.Button()
        Me.cerrar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ATicket = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.ins = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ingreso
        '
        Me.ingreso.Location = New System.Drawing.Point(69, 127)
        Me.ingreso.Name = "ingreso"
        Me.ingreso.Size = New System.Drawing.Size(101, 23)
        Me.ingreso.TabIndex = 0
        Me.ingreso.Text = "Ingresar Insumo"
        Me.ingreso.UseVisualStyleBackColor = True
        '
        'editar
        '
        Me.editar.Location = New System.Drawing.Point(192, 165)
        Me.editar.Name = "editar"
        Me.editar.Size = New System.Drawing.Size(112, 23)
        Me.editar.TabIndex = 1
        Me.editar.Text = "Editar Insumo"
        Me.editar.UseVisualStyleBackColor = True
        '
        'tickets
        '
        Me.tickets.Location = New System.Drawing.Point(93, 12)
        Me.tickets.Name = "tickets"
        Me.tickets.Size = New System.Drawing.Size(56, 23)
        Me.tickets.TabIndex = 2
        Me.tickets.Text = "Tickets"
        Me.tickets.UseVisualStyleBackColor = True
        '
        'cerrar
        '
        Me.cerrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.cerrar.Location = New System.Drawing.Point(279, 12)
        Me.cerrar.Name = "cerrar"
        Me.cerrar.Size = New System.Drawing.Size(78, 23)
        Me.cerrar.TabIndex = 4
        Me.cerrar.Text = "Cerrar sesión"
        Me.cerrar.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(253, 41)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 23)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "Editar Contraseña"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ATicket
        '
        Me.ATicket.Location = New System.Drawing.Point(12, 12)
        Me.ATicket.Name = "ATicket"
        Me.ATicket.Size = New System.Drawing.Size(75, 23)
        Me.ATicket.TabIndex = 15
        Me.ATicket.Text = "Abrir Ticket"
        Me.ATicket.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(58, 165)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 23)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "Pedido de Compras "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ins
        '
        Me.ins.Location = New System.Drawing.Point(192, 127)
        Me.ins.Name = "ins"
        Me.ins.Size = New System.Drawing.Size(112, 23)
        Me.ins.TabIndex = 18
        Me.ins.Text = "Listado de Insumos"
        Me.ins.UseVisualStyleBackColor = True
        '
        'MenuTecnico
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PowderBlue
        Me.ClientSize = New System.Drawing.Size(369, 247)
        Me.Controls.Add(Me.ins)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ATicket)
        Me.Controls.Add(Me.cerrar)
        Me.Controls.Add(Me.tickets)
        Me.Controls.Add(Me.editar)
        Me.Controls.Add(Me.ingreso)
        Me.Name = "MenuTecnico"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ingreso As Button
    Friend WithEvents editar As Button
    Friend WithEvents tickets As Button
    Friend WithEvents cerrar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ATicket As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents ins As Button
End Class
