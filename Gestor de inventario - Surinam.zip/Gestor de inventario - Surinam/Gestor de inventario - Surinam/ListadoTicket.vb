﻿Public Class Listado
    Private Sub Tickets_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Tickets.CellContentClick
        Tickets.Rows.Add("fecha", "Codigo", "Prioridad", "Asunto", "sector", "mensaje", "ver")
        Ticket.AutoScroll = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Listado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Modulo.listarT()
    End Sub
End Class