﻿Public Class Listado
    Dim clas = New Clase()
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Dim a As Integer = 0
    Private Sub Listado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.listarTickets(0)
        Label3.Text = Tickets.RowCount()
    End Sub

    Private Sub Tickets_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Tickets.CellMouseClick
        Dim a As String = Me.Tickets.CurrentRow.Cells("Num").Value
        CerrarTicket.Visible = True
        CerrarTicket.buscar.Text = a
        CerrarTicket.Button3.PerformClick()
    End Sub

    Private Sub list_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles list.SelectionChangeCommitted
        If (list.SelectedItem = "Abierto") Then
            clas.listarTickets(1)
            Label3.Text = Tickets.RowCount()
        ElseIf (list.SelectedItem = "Cerrado") Then
            clas.listarTickets(2)
            Label3.Text = Tickets.RowCount()
        Else
            clas.listarTickets(0)
            Label3.Text = Tickets.RowCount()
        End If
    End Sub

End Class