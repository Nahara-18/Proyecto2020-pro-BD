﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuAdmin
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cerrar = New System.Windows.Forms.Button()
        Me.tickets = New System.Windows.Forms.Button()
        Me.edInsumo = New System.Windows.Forms.Button()
        Me.ingIns = New System.Windows.Forms.Button()
        Me.ATicket = New System.Windows.Forms.Button()
        Me.IngresoUsu = New System.Windows.Forms.Button()
        Me.edUsu = New System.Windows.Forms.Button()
        Me.ins = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cerrar
        '
        Me.cerrar.Location = New System.Drawing.Point(283, 12)
        Me.cerrar.Name = "cerrar"
        Me.cerrar.Size = New System.Drawing.Size(78, 23)
        Me.cerrar.TabIndex = 8
        Me.cerrar.Text = "Cerrar sesión"
        Me.cerrar.UseVisualStyleBackColor = True
        '
        'tickets
        '
        Me.tickets.Location = New System.Drawing.Point(81, 111)
        Me.tickets.Name = "tickets"
        Me.tickets.Size = New System.Drawing.Size(75, 23)
        Me.tickets.TabIndex = 7
        Me.tickets.Text = "Tickets"
        Me.tickets.UseVisualStyleBackColor = True
        '
        'edInsumo
        '
        Me.edInsumo.Location = New System.Drawing.Point(66, 197)
        Me.edInsumo.Name = "edInsumo"
        Me.edInsumo.Size = New System.Drawing.Size(100, 23)
        Me.edInsumo.TabIndex = 6
        Me.edInsumo.Text = "Editar Insumo"
        Me.edInsumo.UseVisualStyleBackColor = True
        '
        'ingIns
        '
        Me.ingIns.Location = New System.Drawing.Point(66, 168)
        Me.ingIns.Name = "ingIns"
        Me.ingIns.Size = New System.Drawing.Size(101, 23)
        Me.ingIns.TabIndex = 5
        Me.ingIns.Text = "Ingresar Insumo"
        Me.ingIns.UseVisualStyleBackColor = True
        '
        'ATicket
        '
        Me.ATicket.Location = New System.Drawing.Point(12, 41)
        Me.ATicket.Name = "ATicket"
        Me.ATicket.Size = New System.Drawing.Size(75, 23)
        Me.ATicket.TabIndex = 9
        Me.ATicket.Text = "Abrir Ticket"
        Me.ATicket.UseVisualStyleBackColor = True
        '
        'IngresoUsu
        '
        Me.IngresoUsu.Location = New System.Drawing.Point(207, 168)
        Me.IngresoUsu.Name = "IngresoUsu"
        Me.IngresoUsu.Size = New System.Drawing.Size(101, 23)
        Me.IngresoUsu.TabIndex = 11
        Me.IngresoUsu.Text = "Ingresar Ususario"
        Me.IngresoUsu.UseVisualStyleBackColor = True
        '
        'edUsu
        '
        Me.edUsu.Location = New System.Drawing.Point(208, 197)
        Me.edUsu.Name = "edUsu"
        Me.edUsu.Size = New System.Drawing.Size(100, 23)
        Me.edUsu.TabIndex = 12
        Me.edUsu.Text = "Editar Usuario"
        Me.edUsu.UseVisualStyleBackColor = True
        '
        'ins
        '
        Me.ins.Location = New System.Drawing.Point(219, 111)
        Me.ins.Name = "ins"
        Me.ins.Size = New System.Drawing.Size(75, 23)
        Me.ins.TabIndex = 13
        Me.ins.Text = "Insumos"
        Me.ins.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 12)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Editar Contraseña"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(145, 243)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 15
        Me.Button2.Text = "Compras"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'MenuAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(373, 290)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ins)
        Me.Controls.Add(Me.edUsu)
        Me.Controls.Add(Me.IngresoUsu)
        Me.Controls.Add(Me.ATicket)
        Me.Controls.Add(Me.cerrar)
        Me.Controls.Add(Me.tickets)
        Me.Controls.Add(Me.edInsumo)
        Me.Controls.Add(Me.ingIns)
        Me.Name = "MenuAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "cc "
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents cerrar As Button
    Friend WithEvents tickets As Button
    Friend WithEvents edInsumo As Button
    Friend WithEvents ingIns As Button
    Friend WithEvents ATicket As Button
    Friend WithEvents IngresoUsu As Button
    Friend WithEvents edUsu As Button
    Friend WithEvents ins As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
