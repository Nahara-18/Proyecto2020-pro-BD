﻿Public Class MenuAdmin
    Private Sub ingreso_Click(sender As Object, e As EventArgs) Handles ingreso.Click
        IngInsumo.Visible = True
    End Sub

    Private Sub IngresoUsu_Click(sender As Object, e As EventArgs) Handles IngresoUsu.Click
        IngUsuario.Visible = True
    End Sub

    Private Sub editar_Click(sender As Object, e As EventArgs) Handles editar.Click
        editarInsumo.Visible = True
    End Sub


    Private Sub tickets_Click(sender As Object, e As EventArgs) Handles tickets.Click
        ListadoTicket.Visible = True
    End Sub

    Private Sub cerrar_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Me.Close()
        Login.Visible = True
    End Sub
End Class