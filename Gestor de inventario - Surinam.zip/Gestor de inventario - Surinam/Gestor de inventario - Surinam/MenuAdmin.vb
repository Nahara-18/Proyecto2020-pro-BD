﻿Public Class MenuAdmin
    Public cedu As String
    Private Sub ingreso_Click(sender As Object, e As EventArgs) Handles ingIns.Click
        IngInsumo.Visible = True
        IngInsumo.cedu = cedu
    End Sub
    Private Sub IngresoUsu_Click(sender As Object, e As EventArgs) Handles IngresoUsu.Click
        IngUsuario.Visible = True
    End Sub
    Private Sub editar_Click(sender As Object, e As EventArgs) Handles edInsumo.Click
        editarInsumo.Visible = True
        editarInsumo.cedu = cedu
    End Sub
    Private Sub tickets_Click(sender As Object, e As EventArgs) Handles tickets.Click
        ListadoT.Visible = True
        editarInsumo.cedu = cedu
    End Sub
    Private Sub cerrar_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Login.Visible = True
        Me.Close()
    End Sub
    Private Sub edUsu_Click(sender As Object, e As EventArgs) Handles edUsu.Click
        UsuV.Visible = True
    End Sub
    Private Sub ins_Click(sender As Object, e As EventArgs) Handles ins.Click
        Insumos.Visible = True
        Insumos.cedu = cedu

    End Sub
    Private Sub ATicket_Click(sender As Object, e As EventArgs) Handles ATicket.Click
        Ticket.Visible = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipoYEditarContrase.Text = "Contraseña"
        AgregarTipoYEditarContrase.cedu = cedu
        AgregarTipoYEditarContrase.Visible = True
        AgregarTipoYEditarContrase.v.Visible = True
        AgregarTipoYEditarContrase.Label1.Text = "Contraseña nueva"
        AgregarTipoYEditarContrase.tbxTip.UseSystemPasswordChar = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Compras.Visible = True
        Compras.cedu = cedu
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AgregarHorarios.Visible = True
    End Sub
End Class