﻿Public Class MenuAdmin
    Private Sub ingreso_Click(sender As Object, e As EventArgs) Handles ingIns.Click
        IngInsumo.Visible = True
    End Sub
    Private Sub IngresoUsu_Click(sender As Object, e As EventArgs) Handles IngresoUsu.Click
        IngUsuario.Visible = True
    End Sub
    Private Sub editar_Click(sender As Object, e As EventArgs) Handles edInsumo.Click
        editarInsumo.Visible = True
    End Sub
    Private Sub tickets_Click(sender As Object, e As EventArgs) Handles tickets.Click
        Listado.Visible = True
    End Sub
    Private Sub cerrar_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Me.Close()
        Login.Visible = True
    End Sub
    Private Sub edUsu_Click(sender As Object, e As EventArgs) Handles edUsu.Click
        UsuV.Visible = True
    End Sub
    Private Sub ins_Click(sender As Object, e As EventArgs) Handles ins.Click
        Insumos.Visible = True
    End Sub
    Private Sub ATicket_Click(sender As Object, e As EventArgs) Handles ATicket.Click
        Ticket.Visible = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipoYEditarContrase.Text = "Contraseña"
        AgregarTipoYEditarContrase.Visible = True
        AgregarTipoYEditarContrase.v.Visible = True
        AgregarTipoYEditarContrase.Label1.Text = "Contraseña nueva"
        AgregarTipoYEditarContrase.tip.UseSystemPasswordChar = True
    End Sub
End Class