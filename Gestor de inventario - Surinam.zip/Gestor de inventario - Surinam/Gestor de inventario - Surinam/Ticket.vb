﻿Public Class Ticket
    Private Sub enviar_Click(sender As Object, e As EventArgs) Handles enviar.Click
        Modulo.email(Email.Text)
        If (Modulo.vacio(nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
        End If
        If (Modulo.vacio(Apellido.Text()) = "false") Then
            A.ForeColor = ForeColor.Red
        Else
            A.ForeColor = ForeColor.Black
        End If
        If (Modulo.email(Email.Text) = "false") Then
            Em.ForeColor = ForeColor.Red
        Else
            Em.ForeColor = ForeColor.Black
        End If

    End Sub

    Private Sub estado_Click(sender As Object, e As EventArgs) Handles estado.Click
        InformeInvitado.Visible = True
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Login.Visible = True
        Me.Close()
    End Sub

    Private Sub nombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nombre.KeyPress, Apellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
End Class