﻿Imports System.Net.Http
Public Class Ticket
    Dim clas = New Clase()
    Dim Ins As Integer = 0
    Private Sub enviar_Click(sender As Object, e As EventArgs) Handles enviar.Click
        Dim completo As Integer = 0

        'en cada uno de los siguientes "If" se comprobaran los datos, si no estan vacios, si tienen ciertos caracteres,etc
        'si los datos son correctos se sumara en cuenta uno en uno
        'se comprobara en el ultimo if si todos lod datos minimos requeridos fueron ingresados y se registra
        If (clas.vacio(txbNombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (clas.vacio(txbApellido.Text()) = "false") Then
            A.ForeColor = ForeColor.Red
        Else
            A.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (clas.email(txbEmail.Text) = "false") Then
            Em.ForeColor = ForeColor.Red
        Else
            Em.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (clas.vacio(txbNumero.Text()) = "false") Then
            lblRNum.Visible = True
        ElseIf (clas.ExisteI() = "False") Then
            MsgBox("Insumo no encontrado")
            lblRNum.Visible = True
        Else
            lblRNum.Visible = False
            completo += 1
        End If
        If (txbMensaje.Text = "") Then
            m.ForeColor = ForeColor.Red
            m.Text = "Mensaje - Es importante detallar el problema"
        Else
            m.ForeColor = ForeColor.Black
            m.Text = "Mensaje"
            completo += 1
        End If

        If (Asunto.SelectedItem = "") Then
            asu.Visible = True
        Else
            asu.Visible = False
            completo += 1
        End If
        If (Prioridad.SelectedItem = "") Then
            prio.Visible = True
        Else
            prio.Visible = False
            completo += 1
        End If

        If (completo = 7) Then
            clas.altaTicket()
        End If
    End Sub

    Private Sub estado_Click(sender As Object, e As EventArgs) Handles estado.Click
        InformeInvitado.Visible = True
        Me.Close()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
    Private Sub ver_Click(sender As Object, e As EventArgs)
        clas.buscarInsu()
    End Sub

    Private Sub nombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txbNombre.KeyPress, txbApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub txbNumero_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txbNumero.KeyPress


        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If


    End Sub

    Private Sub txbNumero_TextChanged(sender As Object, e As EventArgs) Handles txbNumero.TextChanged
        If (Len(txbNumero.Text) > 0) Then
            clas.buscarInsu()
        End If
    End Sub
End Class