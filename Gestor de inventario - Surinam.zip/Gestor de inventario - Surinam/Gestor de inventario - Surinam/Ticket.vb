﻿Imports System.Net.Http

Public Class Ticket
    Private Sub enviar_Click(sender As Object, e As EventArgs) Handles enviar.Click
        Dim completo As Integer = 0
        If (Modulo.vacio(nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.vacio(apellido.Text()) = "false") Then
            A.ForeColor = ForeColor.Red
        Else
            A.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.email(email.Text) = "false") Then
            Em.ForeColor = ForeColor.Red
        Else
            Em.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Mensaje.Text = "") Then
            m.ForeColor = ForeColor.Red
            m.Text = "Mensaje - Es importante detallar el problema"
        Else
            m.ForeColor = ForeColor.Black
            m.Text = "Mensaje"
            completo += 1
        End If
        If (Sector.SelectedItem = "Biblioteca" Or Sector.SelectedItem = "6T" Or Sector.SelectedItem = "Taller") Then
            SecLugar.Visible = False
            completo += 1
        Else
            If (Sector.SelectedItem = "" OrElse Lugar.Text = "") Then
                SecLugar.Visible = True
            Else
                SecLugar.Visible = False
                completo += 1
            End If
        End If
        If (Asunto.SelectedItem = "") Then
            asu.Visible = True
        Else
            asu.Visible = False
            completo += 1
        End If
        If (Prioridad.SelectedItem = "") Then
            prio.Visible = True
        Else
            prio.Visible = False
            completo += 1
        End If

        If (completo = 7) Then
            Modulo.altaTiket()
        End If
    End Sub

    Private Sub estado_Click(sender As Object, e As EventArgs) Handles estado.Click
        InformeInvitado.Visible = True
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Login.Visible = True
        Me.Close()
    End Sub

    Private Sub nombre_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nombre.KeyPress, apellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub Sector_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Sector.SelectedIndexChanged
        If (Sector.SelectedItem = "Biblioteca" Or Sector.SelectedItem = "6T" Or Sector.SelectedItem = "Taller") Then
            Lugar.Visible = False
            lug.Visible = False
            SecLugar.Visible = False
        Else
            Lugar.Visible = True
            lug.Visible = True
        End If
    End Sub
End Class