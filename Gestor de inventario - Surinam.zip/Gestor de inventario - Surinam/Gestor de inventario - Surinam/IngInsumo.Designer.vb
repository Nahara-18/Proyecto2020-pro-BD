﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IngInsumo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Est = New System.Windows.Forms.Label()
        Me.N = New System.Windows.Forms.Label()
        Me.nombre = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.CantidadComprar = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.registrar = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.Label()
        Me.Cant = New System.Windows.Forms.TextBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.Estado = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Est
        '
        Me.Est.AutoSize = True
        Me.Est.Location = New System.Drawing.Point(45, 212)
        Me.Est.Name = "Est"
        Me.Est.Size = New System.Drawing.Size(40, 13)
        Me.Est.TabIndex = 2
        Me.Est.Text = "Estado"
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Location = New System.Drawing.Point(45, 40)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(44, 13)
        Me.N.TabIndex = 3
        Me.N.Text = "Nombre"
        '
        'nombre
        '
        Me.nombre.Location = New System.Drawing.Point(110, 40)
        Me.nombre.Name = "nombre"
        Me.nombre.Size = New System.Drawing.Size(229, 20)
        Me.nombre.TabIndex = 4
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Hardware", "Software", "Red"})
        Me.ComboBox1.Location = New System.Drawing.Point(65, 79)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 5
        Me.ComboBox1.Text = "Tipo"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Sala", "Taller", "Salon", "Oficina"})
        Me.ComboBox2.Location = New System.Drawing.Point(65, 166)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 6
        Me.ComboBox2.Text = "Lugar"
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"Si", "No"})
        Me.ComboBox4.Location = New System.Drawing.Point(280, 256)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(81, 21)
        Me.ComboBox4.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(45, 259)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(225, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Es necesario realizar compra de este producto"
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Items.AddRange(New Object() {"Si", "No"})
        Me.ComboBox5.Location = New System.Drawing.Point(192, 336)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox5.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(45, 339)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(141, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Es necesario reslizar soporte"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(201, 166)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 12
        '
        'CantidadComprar
        '
        Me.CantidadComprar.Location = New System.Drawing.Point(171, 290)
        Me.CantidadComprar.Name = "CantidadComprar"
        Me.CantidadComprar.Size = New System.Drawing.Size(100, 20)
        Me.CantidadComprar.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(116, 293)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Cantidad"
        '
        'registrar
        '
        Me.registrar.Location = New System.Drawing.Point(171, 382)
        Me.registrar.Name = "registrar"
        Me.registrar.Size = New System.Drawing.Size(75, 23)
        Me.registrar.TabIndex = 15
        Me.registrar.Text = "Registrar"
        Me.registrar.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Location = New System.Drawing.Point(45, 123)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(49, 13)
        Me.C.TabIndex = 17
        Me.C.Text = "Cantidad"
        '
        'Cant
        '
        Me.Cant.Location = New System.Drawing.Point(109, 120)
        Me.Cant.Name = "Cant"
        Me.Cant.Size = New System.Drawing.Size(100, 20)
        Me.Cant.TabIndex = 16
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"Tutoria", "Sala de profesores", "Biblioteca"})
        Me.ComboBox6.Location = New System.Drawing.Point(218, 166)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox6.TabIndex = 18
        '
        'Estado
        '
        Me.Estado.Location = New System.Drawing.Point(110, 212)
        Me.Estado.Name = "Estado"
        Me.Estado.Size = New System.Drawing.Size(100, 20)
        Me.Estado.TabIndex = 42
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1, 1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 21)
        Me.Button2.TabIndex = 43
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'IngInsumo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 424)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Estado)
        Me.Controls.Add(Me.ComboBox6)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.Cant)
        Me.Controls.Add(Me.registrar)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CantidadComprar)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.ComboBox5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.ComboBox4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.nombre)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Est)
        Me.Name = "IngInsumo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ingreso de Insumo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Est As Label
    Friend WithEvents N As Label
    Friend WithEvents nombre As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents CantidadComprar As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents registrar As Button
    Friend WithEvents C As Label
    Friend WithEvents Cant As TextBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents Estado As TextBox
    Friend WithEvents Button2 As Button
End Class
