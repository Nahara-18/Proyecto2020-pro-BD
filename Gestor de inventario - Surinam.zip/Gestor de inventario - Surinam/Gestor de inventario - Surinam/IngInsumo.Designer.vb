﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IngInsumo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Est = New System.Windows.Forms.Label()
        Me.N = New System.Windows.Forms.Label()
        Me.nombre = New System.Windows.Forms.TextBox()
        Me.Categoria = New System.Windows.Forms.ComboBox()
        Me.lugar = New System.Windows.Forms.ComboBox()
        Me.compra = New System.Windows.Forms.ComboBox()
        Me.com = New System.Windows.Forms.Label()
        Me.soporte = New System.Windows.Forms.ComboBox()
        Me.sop = New System.Windows.Forms.Label()
        Me.localizado = New System.Windows.Forms.TextBox()
        Me.CantidadComprar = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.registrar = New System.Windows.Forms.Button()
        Me.Estado = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Cat = New System.Windows.Forms.Label()
        Me.rLugar = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.T = New System.Windows.Forms.Label()
        Me.Tipo = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CompDon = New System.Windows.Forms.ComboBox()
        Me.donador = New System.Windows.Forms.TextBox()
        Me.Drequerido = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Est
        '
        Me.Est.AutoSize = True
        Me.Est.Location = New System.Drawing.Point(124, 177)
        Me.Est.Name = "Est"
        Me.Est.Size = New System.Drawing.Size(40, 13)
        Me.Est.TabIndex = 2
        Me.Est.Text = "Estado"
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Location = New System.Drawing.Point(45, 40)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(44, 13)
        Me.N.TabIndex = 3
        Me.N.Text = "Nombre"
        '
        'nombre
        '
        Me.nombre.Location = New System.Drawing.Point(110, 40)
        Me.nombre.Name = "nombre"
        Me.nombre.Size = New System.Drawing.Size(229, 20)
        Me.nombre.TabIndex = 4
        '
        'Categoria
        '
        Me.Categoria.FormattingEnabled = True
        Me.Categoria.Items.AddRange(New Object() {"Hardware", "Software", "Red"})
        Me.Categoria.Location = New System.Drawing.Point(53, 93)
        Me.Categoria.Name = "Categoria"
        Me.Categoria.Size = New System.Drawing.Size(121, 21)
        Me.Categoria.TabIndex = 5
        Me.Categoria.Text = "Categoria"
        '
        'lugar
        '
        Me.lugar.FormattingEnabled = True
        Me.lugar.Items.AddRange(New Object() {"Sala", "Taller", "6T", "Salon", "Oficina"})
        Me.lugar.Location = New System.Drawing.Point(43, 143)
        Me.lugar.Name = "lugar"
        Me.lugar.Size = New System.Drawing.Size(121, 21)
        Me.lugar.TabIndex = 6
        Me.lugar.Text = "Lugar"
        '
        'compra
        '
        Me.compra.FormattingEnabled = True
        Me.compra.Items.AddRange(New Object() {"Si", "No"})
        Me.compra.Location = New System.Drawing.Point(275, 252)
        Me.compra.Name = "compra"
        Me.compra.Size = New System.Drawing.Size(81, 21)
        Me.compra.TabIndex = 9
        '
        'com
        '
        Me.com.AutoSize = True
        Me.com.Location = New System.Drawing.Point(40, 255)
        Me.com.Name = "com"
        Me.com.Size = New System.Drawing.Size(225, 13)
        Me.com.TabIndex = 8
        Me.com.Text = "Es necesario realizar compra de este producto"
        '
        'soporte
        '
        Me.soporte.FormattingEnabled = True
        Me.soporte.Items.AddRange(New Object() {"Si", "No"})
        Me.soporte.Location = New System.Drawing.Point(191, 305)
        Me.soporte.Name = "soporte"
        Me.soporte.Size = New System.Drawing.Size(121, 21)
        Me.soporte.TabIndex = 11
        '
        'sop
        '
        Me.sop.AutoSize = True
        Me.sop.Location = New System.Drawing.Point(44, 308)
        Me.sop.Name = "sop"
        Me.sop.Size = New System.Drawing.Size(141, 13)
        Me.sop.TabIndex = 10
        Me.sop.Text = "Es necesario reslizar soporte"
        '
        'localizado
        '
        Me.localizado.Location = New System.Drawing.Point(180, 144)
        Me.localizado.Name = "localizado"
        Me.localizado.Size = New System.Drawing.Size(193, 20)
        Me.localizado.TabIndex = 12
        '
        'CantidadComprar
        '
        Me.CantidadComprar.Location = New System.Drawing.Point(193, 275)
        Me.CantidadComprar.Name = "CantidadComprar"
        Me.CantidadComprar.Size = New System.Drawing.Size(100, 20)
        Me.CantidadComprar.TabIndex = 13
        Me.CantidadComprar.Text = "1"
        Me.CantidadComprar.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(94, 278)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "               Cantidad"
        Me.Label7.Visible = False
        '
        'registrar
        '
        Me.registrar.Location = New System.Drawing.Point(170, 351)
        Me.registrar.Name = "registrar"
        Me.registrar.Size = New System.Drawing.Size(75, 23)
        Me.registrar.TabIndex = 15
        Me.registrar.Text = "Registrar"
        Me.registrar.UseVisualStyleBackColor = True
        '
        'Estado
        '
        Me.Estado.Location = New System.Drawing.Point(170, 177)
        Me.Estado.Name = "Estado"
        Me.Estado.Size = New System.Drawing.Size(116, 20)
        Me.Estado.TabIndex = 42
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1, 1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 21)
        Me.Button2.TabIndex = 43
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Cat
        '
        Me.Cat.AutoSize = True
        Me.Cat.ForeColor = System.Drawing.Color.Red
        Me.Cat.Location = New System.Drawing.Point(95, 77)
        Me.Cat.Name = "Cat"
        Me.Cat.Size = New System.Drawing.Size(56, 13)
        Me.Cat.TabIndex = 44
        Me.Cat.Text = "Requerido"
        Me.Cat.Visible = False
        '
        'rLugar
        '
        Me.rLugar.AutoSize = True
        Me.rLugar.ForeColor = System.Drawing.Color.Red
        Me.rLugar.Location = New System.Drawing.Point(115, 127)
        Me.rLugar.Name = "rLugar"
        Me.rLugar.Size = New System.Drawing.Size(91, 13)
        Me.rLugar.TabIndex = 45
        Me.rLugar.Text = "campos requerido"
        Me.rLugar.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(254, 171)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 46
        '
        'T
        '
        Me.T.AutoSize = True
        Me.T.ForeColor = System.Drawing.Color.Red
        Me.T.Location = New System.Drawing.Point(229, 77)
        Me.T.Name = "T"
        Me.T.Size = New System.Drawing.Size(56, 13)
        Me.T.TabIndex = 48
        Me.T.Text = "Requerido"
        Me.T.Visible = False
        '
        'Tipo
        '
        Me.Tipo.FormattingEnabled = True
        Me.Tipo.Items.AddRange(New Object() {"Hardware", "Software", "Red"})
        Me.Tipo.Location = New System.Drawing.Point(192, 93)
        Me.Tipo.Name = "Tipo"
        Me.Tipo.Size = New System.Drawing.Size(121, 21)
        Me.Tipo.TabIndex = 47
        Me.Tipo.Text = "Tipo"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(319, 93)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(53, 21)
        Me.Button1.TabIndex = 49
        Me.Button1.Text = "Agregar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(212, 127)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(171, 13)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Tutoria,sala profesores o biblioteca"
        Me.Label1.Visible = False
        '
        'CompDon
        '
        Me.CompDon.FormattingEnabled = True
        Me.CompDon.Items.AddRange(New Object() {"Comprado", "Donado"})
        Me.CompDon.Location = New System.Drawing.Point(74, 222)
        Me.CompDon.Name = "CompDon"
        Me.CompDon.Size = New System.Drawing.Size(121, 21)
        Me.CompDon.TabIndex = 52
        '
        'donador
        '
        Me.donador.Location = New System.Drawing.Point(208, 221)
        Me.donador.Name = "donador"
        Me.donador.Size = New System.Drawing.Size(148, 20)
        Me.donador.TabIndex = 53
        Me.donador.Visible = False
        '
        'Drequerido
        '
        Me.Drequerido.AutoSize = True
        Me.Drequerido.ForeColor = System.Drawing.Color.Red
        Me.Drequerido.Location = New System.Drawing.Point(167, 205)
        Me.Drequerido.Name = "Drequerido"
        Me.Drequerido.Size = New System.Drawing.Size(56, 13)
        Me.Drequerido.TabIndex = 54
        Me.Drequerido.Text = "Requerido"
        Me.Drequerido.Visible = False
        '
        'IngInsumo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 387)
        Me.Controls.Add(Me.Drequerido)
        Me.Controls.Add(Me.donador)
        Me.Controls.Add(Me.CompDon)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.T)
        Me.Controls.Add(Me.Tipo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.rLugar)
        Me.Controls.Add(Me.Cat)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Estado)
        Me.Controls.Add(Me.registrar)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CantidadComprar)
        Me.Controls.Add(Me.localizado)
        Me.Controls.Add(Me.soporte)
        Me.Controls.Add(Me.sop)
        Me.Controls.Add(Me.compra)
        Me.Controls.Add(Me.com)
        Me.Controls.Add(Me.lugar)
        Me.Controls.Add(Me.Categoria)
        Me.Controls.Add(Me.nombre)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Est)
        Me.Name = "IngInsumo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ingreso de Insumo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Est As Label
    Friend WithEvents N As Label
    Friend WithEvents nombre As TextBox
    Friend WithEvents Categoria As ComboBox
    Friend WithEvents lugar As ComboBox
    Friend WithEvents compra As ComboBox
    Friend WithEvents com As Label
    Friend WithEvents soporte As ComboBox
    Friend WithEvents sop As Label
    Friend WithEvents localizado As TextBox
    Friend WithEvents CantidadComprar As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents registrar As Button
    Friend WithEvents Estado As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Cat As Label
    Friend WithEvents rLugar As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents T As Label
    Friend WithEvents Tipo As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents CompDon As ComboBox
    Friend WithEvents donador As TextBox
    Friend WithEvents Drequerido As Label
End Class
