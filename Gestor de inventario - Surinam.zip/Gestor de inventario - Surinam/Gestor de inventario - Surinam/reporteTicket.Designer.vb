﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class reporteTicket
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Tickets = New System.Windows.Forms.DataGridView()
        Me.fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.prio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.asun = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sec = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.men = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ver = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(267, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 24
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(276, 60)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(132, 20)
        Me.TextBox1.TabIndex = 23
        '
        'Tickets
        '
        Me.Tickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tickets.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.fecha, Me.cod, Me.prio, Me.asun, Me.sec, Me.men, Me.ver})
        Me.Tickets.EnableHeadersVisualStyles = False
        Me.Tickets.Location = New System.Drawing.Point(1, 119)
        Me.Tickets.Name = "Tickets"
        Me.Tickets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Tickets.RowHeadersVisible = False
        Me.Tickets.Size = New System.Drawing.Size(814, 362)
        Me.Tickets.TabIndex = 22
        '
        'fecha
        '
        Me.fecha.FillWeight = 110.7445!
        Me.fecha.HeaderText = "Fecha"
        Me.fecha.Name = "fecha"
        Me.fecha.Width = 80
        '
        'cod
        '
        Me.cod.FillWeight = 110.7445!
        Me.cod.HeaderText = "Codigo"
        Me.cod.Name = "cod"
        Me.cod.Width = 80
        '
        'prio
        '
        Me.prio.FillWeight = 110.7445!
        Me.prio.HeaderText = "Prioridad"
        Me.prio.Name = "prio"
        Me.prio.Width = 60
        '
        'asun
        '
        Me.asun.FillWeight = 110.7445!
        Me.asun.HeaderText = "Asunto"
        Me.asun.Name = "asun"
        '
        'sec
        '
        Me.sec.FillWeight = 110.7445!
        Me.sec.HeaderText = "Sector"
        Me.sec.Name = "sec"
        Me.sec.Width = 150
        '
        'men
        '
        Me.men.FillWeight = 110.7445!
        Me.men.HeaderText = "Mensaje"
        Me.men.Name = "men"
        Me.men.Width = 284
        '
        'ver
        '
        Me.ver.FillWeight = 35.53299!
        Me.ver.HeaderText = ""
        Me.ver.Name = "ver"
        Me.ver.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ver.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ver.Width = 40
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Codigo", "fecha apertura ", "cierre", "tecnico asociado"})
        Me.ComboBox1.Location = New System.Drawing.Point(304, 22)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(104, 21)
        Me.ComboBox1.TabIndex = 26
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(208, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "buscar por"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(414, 58)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "Buscar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(154, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 13)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "tickets abiertos y cerrados"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"abiertos", "cerrados", "ambos"})
        Me.ComboBox2.Location = New System.Drawing.Point(12, 92)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(74, 21)
        Me.ComboBox2.TabIndex = 29
        Me.ComboBox2.Text = "abiertos"
        '
        'reporteTicket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(818, 493)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Tickets)
        Me.Name = "reporteTicket"
        Me.Text = "reporteTicket"
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Tickets As DataGridView
    Friend WithEvents fecha As DataGridViewTextBoxColumn
    Friend WithEvents cod As DataGridViewTextBoxColumn
    Friend WithEvents prio As DataGridViewTextBoxColumn
    Friend WithEvents asun As DataGridViewTextBoxColumn
    Friend WithEvents sec As DataGridViewTextBoxColumn
    Friend WithEvents men As DataGridViewTextBoxColumn
    Friend WithEvents ver As DataGridViewButtonColumn
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox2 As ComboBox
End Class
