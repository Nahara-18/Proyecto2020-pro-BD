﻿Public Class reporteTicket
    Private Sub Tickets_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Tickets.CellContentClick

    End Sub
End Class