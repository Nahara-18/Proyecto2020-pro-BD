﻿Public Class reporteTicket
    Public cedu As String
End Class