﻿Public Class reporteTicket
    Public cedu As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class