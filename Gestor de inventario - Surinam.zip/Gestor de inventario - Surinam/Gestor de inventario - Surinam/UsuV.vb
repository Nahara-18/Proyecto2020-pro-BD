﻿Public Class UsuV

    Private Sub Editar_Click(sender As Object, e As EventArgs) Handles Editar.Click
        Dim c As String = Cedula.Text
        If c = "" Then
            MessageBox.Show("Debe completar el campo", "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If Modulo.Usu(c) = 1 Then
                EdiUsu.Visible = True
                Modulo.datosUsu()
            Else
                MessageBox.Show("Cedula incorrecta", "Usu", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Eliminar.Click
        MenuAdmin.Visible = True
        Me.Visible = False
        Modulo.EliminarUsu()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Nombre.Text = Modulo.BuscarUsu()
        Nombre.Visible = True
        Editar.Visible = True
        Eliminar.Visible = True
    End Sub
End Class