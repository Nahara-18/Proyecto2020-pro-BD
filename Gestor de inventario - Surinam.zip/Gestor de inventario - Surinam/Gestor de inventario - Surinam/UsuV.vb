﻿Public Class UsuV

    Private Sub Editar_Click(sender As Object, e As EventArgs) Handles Editar.Click
        Dim c As String = Cedula.Text
        If c = "" Then
            MessageBox.Show("Debe completar todos los campos", "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If Modulo.Usu(c) = 1 Then
                EdiUsu.Visible = True
            Else
                MessageBox.Show("Usuario y/o contraseña incorreca", "Usu", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MenuAdmin.Visible = True
        Me.Visible = False
        Modulo.EliminarUsu()
    End Sub
End Class