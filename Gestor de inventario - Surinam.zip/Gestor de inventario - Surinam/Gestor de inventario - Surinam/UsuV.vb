﻿Public Class UsuV
    Dim clas = New Clase()
    Private Sub Editar_Click(sender As Object, e As EventArgs) Handles Editar.Click
        Dim c As String = Cedula.Text
        If c = "" Then
            MessageBox.Show("Debe completar el campo", "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If clas.Usu(c) = 1 Then
                EdiUsu.Visible = True
                clas.datosUsu()
                Nombre.Visible = False
            Else
                MessageBox.Show("Cedula incorrecta", "Usu", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Eliminar.Click
        MenuAdmin.Visible = True
        clas.EliminarUsu()
        Me.Close()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Nombre.Text = clas.BuscarUsu()
        Nombre.Visible = True
        Editar.Visible = True
        Eliminar.Visible = True
    End Sub

    Private Sub Cedula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Cedula.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            Button1.PerformClick()
        End If
    End Sub
End Class