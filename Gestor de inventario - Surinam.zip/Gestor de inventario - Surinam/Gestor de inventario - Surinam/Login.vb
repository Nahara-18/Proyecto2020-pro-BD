﻿Public Class Login

    Private Sub mosCon_CheckedChanged(sender As Object, e As EventArgs) Handles mosCon.CheckedChanged
        If mosCon.Checked = True Then
            contraseña.UseSystemPasswordChar = False
        Else
            contraseña.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Ticket.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim em As String = email.Text
        Dim c As String = contraseña.Text
        If em = "" Or c = "" Then
            MessageBox.Show("Debe completar todos los campos", "Login", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If Modulo.login(em, c) = "Administrador" Then
                MenuAdmin.Visible = True

            ElseIf Modulo.login(em, c) = "Tecnico" Then
                MenuTecnico.Visible = True
            ElseIf Modulo.login(em, c) = "Reporte" Then
                MenuReporte.Visible = True
            Else
                MessageBox.Show("Usuario y/o contraseña incorreca", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub pasar_KeyPress(sender As Object, e As KeyPressEventArgs) Handles email.KeyPress
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
End Class
