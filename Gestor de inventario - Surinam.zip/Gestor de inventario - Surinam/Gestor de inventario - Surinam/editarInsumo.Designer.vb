﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class editarInsumo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.numero = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.guardar = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.Label()
        Me.Cantidad = New System.Windows.Forms.TextBox()
        Me.localizado = New System.Windows.Forms.TextBox()
        Me.soporte = New System.Windows.Forms.ComboBox()
        Me.sop = New System.Windows.Forms.Label()
        Me.compra = New System.Windows.Forms.ComboBox()
        Me.lugar = New System.Windows.Forms.ComboBox()
        Me.Cat = New System.Windows.Forms.ComboBox()
        Me.Nombre = New System.Windows.Forms.TextBox()
        Me.N = New System.Windows.Forms.Label()
        Me.Est = New System.Windows.Forms.Label()
        Me.rCat = New System.Windows.Forms.Label()
        Me.Estado = New System.Windows.Forms.TextBox()
        Me.eliminar = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.rLugar = New System.Windows.Forms.Label()
        Me.com = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(129, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 13)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "editar segun numero"
        '
        'numero
        '
        Me.numero.Location = New System.Drawing.Point(235, 12)
        Me.numero.Name = "numero"
        Me.numero.Size = New System.Drawing.Size(100, 20)
        Me.numero.TabIndex = 23
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(341, 10)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 22
        Me.Button2.Text = "Buscar"
        Me.Button2.UseVisualStyleBackColor = True
        Me.Button2.Visible = False
        '
        'guardar
        '
        Me.guardar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.guardar.Location = New System.Drawing.Point(133, 346)
        Me.guardar.Name = "guardar"
        Me.guardar.Size = New System.Drawing.Size(75, 23)
        Me.guardar.TabIndex = 40
        Me.guardar.Text = "Guardar"
        Me.guardar.UseVisualStyleBackColor = False
        Me.guardar.Visible = False
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Location = New System.Drawing.Point(298, 282)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(49, 13)
        Me.C.TabIndex = 39
        Me.C.Text = "Cantidad"
        Me.C.Visible = False
        '
        'Cantidad
        '
        Me.Cantidad.Location = New System.Drawing.Point(353, 279)
        Me.Cantidad.Name = "Cantidad"
        Me.Cantidad.Size = New System.Drawing.Size(44, 20)
        Me.Cantidad.TabIndex = 38
        Me.Cantidad.Visible = False
        '
        'localizado
        '
        Me.localizado.Location = New System.Drawing.Point(201, 188)
        Me.localizado.Name = "localizado"
        Me.localizado.Size = New System.Drawing.Size(215, 20)
        Me.localizado.TabIndex = 37
        '
        'soporte
        '
        Me.soporte.FormattingEnabled = True
        Me.soporte.Items.AddRange(New Object() {"Si", "No"})
        Me.soporte.Location = New System.Drawing.Point(253, 231)
        Me.soporte.Name = "soporte"
        Me.soporte.Size = New System.Drawing.Size(62, 21)
        Me.soporte.TabIndex = 36
        '
        'sop
        '
        Me.sop.AutoSize = True
        Me.sop.Location = New System.Drawing.Point(106, 234)
        Me.sop.Name = "sop"
        Me.sop.Size = New System.Drawing.Size(141, 13)
        Me.sop.TabIndex = 35
        Me.sop.Text = "Es necesario reslizar soporte"
        '
        'compra
        '
        Me.compra.FormattingEnabled = True
        Me.compra.Items.AddRange(New Object() {"si", "no"})
        Me.compra.Location = New System.Drawing.Point(172, 282)
        Me.compra.Name = "compra"
        Me.compra.Size = New System.Drawing.Size(108, 21)
        Me.compra.TabIndex = 34
        '
        'lugar
        '
        Me.lugar.FormattingEnabled = True
        Me.lugar.Items.AddRange(New Object() {"Sala", "Taller", "6°T", "Salon", "Oficina"})
        Me.lugar.Location = New System.Drawing.Point(67, 188)
        Me.lugar.Name = "lugar"
        Me.lugar.Size = New System.Drawing.Size(121, 21)
        Me.lugar.TabIndex = 31
        Me.lugar.Text = "Lugar"
        '
        'Cat
        '
        Me.Cat.FormattingEnabled = True
        Me.Cat.Items.AddRange(New Object() {"Hardware", "Software", "Red"})
        Me.Cat.Location = New System.Drawing.Point(86, 121)
        Me.Cat.Name = "Cat"
        Me.Cat.Size = New System.Drawing.Size(121, 21)
        Me.Cat.TabIndex = 30
        '
        'Nombre
        '
        Me.Nombre.Location = New System.Drawing.Point(106, 70)
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Size = New System.Drawing.Size(229, 20)
        Me.Nombre.TabIndex = 29
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Location = New System.Drawing.Point(56, 70)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(44, 13)
        Me.N.TabIndex = 28
        Me.N.Text = "Nombre"
        '
        'Est
        '
        Me.Est.AutoSize = True
        Me.Est.Location = New System.Drawing.Point(219, 121)
        Me.Est.Name = "Est"
        Me.Est.Size = New System.Drawing.Size(40, 13)
        Me.Est.TabIndex = 27
        Me.Est.Text = "Estado"
        '
        'rCat
        '
        Me.rCat.AutoSize = True
        Me.rCat.Location = New System.Drawing.Point(31, 121)
        Me.rCat.Name = "rCat"
        Me.rCat.Size = New System.Drawing.Size(52, 13)
        Me.rCat.TabIndex = 25
        Me.rCat.Text = "Categoria"
        '
        'Estado
        '
        Me.Estado.Location = New System.Drawing.Point(265, 122)
        Me.Estado.Name = "Estado"
        Me.Estado.Size = New System.Drawing.Size(143, 20)
        Me.Estado.TabIndex = 44
        '
        'eliminar
        '
        Me.eliminar.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.eliminar.Location = New System.Drawing.Point(253, 346)
        Me.eliminar.Name = "eliminar"
        Me.eliminar.Size = New System.Drawing.Size(75, 23)
        Me.eliminar.TabIndex = 45
        Me.eliminar.Text = "Dar de baja"
        Me.eliminar.UseVisualStyleBackColor = False
        Me.eliminar.Visible = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(3, 7)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(37, 21)
        Me.Button4.TabIndex = 46
        Me.Button4.Text = "<"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'rLugar
        '
        Me.rLugar.AutoSize = True
        Me.rLugar.ForeColor = System.Drawing.Color.Red
        Me.rLugar.Location = New System.Drawing.Point(139, 172)
        Me.rLugar.Name = "rLugar"
        Me.rLugar.Size = New System.Drawing.Size(94, 13)
        Me.rLugar.TabIndex = 47
        Me.rLugar.Text = " campos requerido"
        Me.rLugar.Visible = False
        '
        'com
        '
        Me.com.AutoSize = True
        Me.com.Location = New System.Drawing.Point(28, 285)
        Me.com.Name = "com"
        Me.com.Size = New System.Drawing.Size(138, 13)
        Me.com.TabIndex = 49
        Me.com.Text = "Es necesario comprar stock"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.PeachPuff
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(169, 330)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 13)
        Me.Label1.TabIndex = 50
        Me.Label1.Text = "Insumo dado de baja"
        Me.Label1.Visible = False
        '
        'editarInsumo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ClientSize = New System.Drawing.Size(444, 374)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.com)
        Me.Controls.Add(Me.rLugar)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.eliminar)
        Me.Controls.Add(Me.Estado)
        Me.Controls.Add(Me.guardar)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.Cantidad)
        Me.Controls.Add(Me.localizado)
        Me.Controls.Add(Me.soporte)
        Me.Controls.Add(Me.sop)
        Me.Controls.Add(Me.compra)
        Me.Controls.Add(Me.lugar)
        Me.Controls.Add(Me.Cat)
        Me.Controls.Add(Me.Nombre)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Est)
        Me.Controls.Add(Me.rCat)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.numero)
        Me.Controls.Add(Me.Button2)
        Me.Name = "editarInsumo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "editarInsumo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label9 As Label
    Friend WithEvents numero As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents guardar As Button
    Friend WithEvents C As Label
    Friend WithEvents Cantidad As TextBox
    Friend WithEvents localizado As TextBox
    Friend WithEvents soporte As ComboBox
    Friend WithEvents sop As Label
    Friend WithEvents compra As ComboBox
    Friend WithEvents lugar As ComboBox
    Friend WithEvents Cat As ComboBox
    Friend WithEvents Nombre As TextBox
    Friend WithEvents N As Label
    Friend WithEvents Est As Label
    Friend WithEvents rCat As Label
    Friend WithEvents Estado As TextBox
    Friend WithEvents eliminar As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents rLugar As Label
    Friend WithEvents com As Label
    Friend WithEvents Label1 As Label
End Class
