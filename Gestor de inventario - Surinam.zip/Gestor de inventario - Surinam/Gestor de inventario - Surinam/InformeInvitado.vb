﻿Public Class InformeInvitado
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Ticket.Visible = True
        Me.Close()
    End Sub
    Private Sub Mostrar_Click(sender As Object, e As EventArgs) Handles Mostrar.Click
        Modulo.InformeI()
    End Sub
End Class