﻿Public Class InformeInvitado
    Dim clas = New Clase()
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles det.KeyPress
        e.Handled = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Ticket.Visible = True
        Me.Close()
    End Sub
    Private Sub Mostrar_Click(sender As Object, e As EventArgs) Handles Mostrar.Click
        clas.InformeI()
    End Sub

    Private Sub InformeInvitado_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class