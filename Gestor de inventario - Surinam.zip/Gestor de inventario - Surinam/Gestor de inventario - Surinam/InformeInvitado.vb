﻿Public Class InformeInvitado
    Dim Selec As Integer = 1
    Dim clas = New Clase()
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles det.KeyPress
        e.Handled = True
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Ticket.Visible = True
        Me.Close()
    End Sub
    Private Sub Mostrar_Click(sender As Object, e As EventArgs) Handles Mostrar.Click
        'clas.InformeI()
        Dim completo As Integer
        If (combo.SelectedItem = "") Then
            Label2.Visible = True
        Else
            Label2.Visible = False
            completo += 1
        End If
        If (textBusqueda.Text = "") Then
            Label2.Visible = True
        Else
            Label2.Visible = False
            completo += 1
        End If

        If (completo = 2) Then
            clas.datoInforme(textBusqueda.Text, Selec)
        End If
    End Sub
    Private Sub InformeInvitado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        combo.SelectedItem = "codigo de ticket"
    End Sub

    Private Sub combo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles combo.SelectedIndexChanged
        If (combo.SelectedItem = "codigo de ticket") Then
            Selec = 1
        Else
            Selec = 2
        End If
    End Sub

    Private Sub datos_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles datos.CellMouseClick
        Dim a As String = Me.datos.CurrentRow.Cells("Num").Value
        clas.InformeI(a)

    End Sub
End Class