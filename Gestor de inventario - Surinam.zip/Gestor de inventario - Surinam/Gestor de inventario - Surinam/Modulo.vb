﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    Function conexion()
        co = New OdbcConnection("Dsn=conexion")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    Function login(em, c)
        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Email = '" & em & "'  AND Contraseña = '" & c & "'", co)
        Return cmd.ExecuteScalar()

    End Function


    Sub altaUsu()
        Call conexion()
        If IngUsuario.pNombre.Text = "" Or IngUsuario.sNombre.Text = "" Or IngUsuario.pApellido.Text = "" Or IngUsuario.sApellido.Text = "" Or IngUsuario.Cedula.Text = "" Or IngUsuario.Email.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                If (IngUsuario.Tipo.SelectedIndex = 0) Then
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "','" & IngUsuario.lugar.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "',' ')", co)
                    cmd.ExecuteNonQuery()
                End If
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                IngUsuario.pNombre.Text = ""
                IngUsuario.sNombre.Text = ""
                IngUsuario.pApellido.Text = ""
                IngUsuario.sApellido.Text = ""
                IngUsuario.Cedula.Text = ""
                IngUsuario.Email.Text = ""
                IngUsuario.Contraseña.Text = ""
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
    Sub altaInsumo()
        Call conexion()
        Try
            If (IngInsumo.compra.SelectedItem = "si") Then
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Localización, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & " ','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Localización, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & " ','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                End If

            End If
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            IngInsumo.nombre.Text = ""
            IngInsumo.tipo.SelectedItem = False
            IngInsumo.lugar.SelectedItem = False
            IngInsumo.localizado.Text = ""
            IngInsumo.Estado.Text = ""
            IngInsumo.soporte.SelectedItem = False
            IngInsumo.CantidadComprar.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTiket()
        Dim codi, num As String
        codi = textoAleatorio()
        Call conexion()
        Try
            If (Ticket.Sector.SelectedItem = "Biblioteca" Or Ticket.Sector.SelectedItem = "6T" Or Ticket.Sector.SelectedItem = "Taller") Then
                cmd = New OdbcCommand("Insert into ticket(codigo,NomUsu,ApeUsu,Email ,Sector,Asunto,Prioridad,Mensaje,FechaTick) values('" & codi & "','" & Ticket.nombre.Text & "',' " & Ticket.apellido.Text & "','" & Ticket.email.Text & "','" & Ticket.Sector.SelectedItem & " ','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.Mensaje.Text & "', now())", co)
                cmd.ExecuteNonQuery()
            Else
                cmd = New OdbcCommand("Insert into ticket(codigo,NomUsu,ApeUsu,Email ,Sector,Lugar,Asunto,Prioridad,Mensaje,FechaTick) values('" & codi & "','" & Ticket.nombre.Text & "',' " & Ticket.apellido.Text & "','" & Ticket.email.Text & "','" & Ticket.Sector.SelectedItem & " ','" & Ticket.Lugar.Text & "','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.Mensaje.Text & "')", co)
                cmd.ExecuteNonQuery()
            End If

            ada = New OdbcDataAdapter("Select numero from ticket where codigo ='%" & codi & "%'", co)
            ds = New DataSet()
            MessageBox.Show("Registro guardado" & vbNewLine & "El numero del ticket es: " & num, "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Ticket.nombre.Text = ""
            Ticket.apellido.Text = ""
            Ticket.email.Text = ""
            Ticket.Mensaje.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub

    Sub editarInsumo()

    End Sub

    Function cedula(C As String)
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C)
        pos = 1
        arr = 0
        multi = 0
        suma = 0
        If (cantidad = 8) Then
            While (pos < 8)
                car = Mid(C, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While
            resto = 10 - Mid(suma, 3, 1)
            If (resto = Mid(C, 8, 1)) Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
    Function vacio(text As String)
        If (text = "") Then
            Return False
        Else
            Return True
        End If
    End Function
    Function email(text As String)
        Dim cant As Integer = Len(text)
        Dim pos As Integer = 1
        Dim caracter As String
        Dim arroba, punto As Integer
        arroba = 0
        punto = 0
        While (pos <= cant)
            caracter = Mid(text, pos, 1)
            If (caracter = "@") Then
                arroba = 1
            ElseIf (caracter = ".") Then
                punto = 1
            End If
            pos += 1
        End While
        If (arroba = 1 And punto = 1) Then
            Return True
        Else
            Return False
        End If
    End Function
    Function textoAleatorio()

        Dim obj As New Random()
        Dim posibles As String = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim longitud As Integer = posibles.Length
        Dim letra As Char
        Dim longitudnuevacadena As Integer = 5
        Dim nuevacadena As String = Nothing
        Dim numero As Integer = 0
        Do While numero = 0
            For i As Integer = 0 To longitudnuevacadena - 1
                letra = posibles(obj.[Next](longitud))
                nuevacadena += letra.ToString()
            Next
            If (Val(letra) * 1 >= 0 And Val(letra) <= 9) Then
                numero = numero + 1
            End If
        Loop

        Return nuevacadena
    End Function
End Module
