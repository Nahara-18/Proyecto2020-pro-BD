﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    'Se crea la conexion y el login de usuario
    Function conexion()
        co = New OdbcConnection("Dsn=conexion")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    Function login(em, c)
        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Email = '" & em & "'  AND Contraseña = '" & c & "'", co)
        Return cmd.ExecuteScalar()

    End Function

    'Se da de alta a usuarios, Insumos y tickets
    Sub altaUsu()
        'este Se utiliza en IngUsuario.vb
        Call conexion()
        If IngUsuario.pNombre.Text = "" Or IngUsuario.sNombre.Text = "" Or IngUsuario.pApellido.Text = "" Or IngUsuario.sApellido.Text = "" Or IngUsuario.Cedula.Text = "" Or IngUsuario.Email.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                If (IngUsuario.Tipo.SelectedIndex = 0) Then
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "','" & IngUsuario.lugar.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "',' ')", co)
                    cmd.ExecuteNonQuery()
                End If
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                IngUsuario.pNombre.Text = ""
                IngUsuario.sNombre.Text = " "
                IngUsuario.pApellido.Text = ""
                IngUsuario.sApellido.Text = " "
                IngUsuario.Cedula.Text = ""
                IngUsuario.Email.Text = ""
                IngUsuario.Contraseña.Text = ""
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
    Sub altaInsumo()
        'este Se utiliza en IngInsumo.vb
        Call conexion()
        Try
            If (IngInsumo.compra.SelectedItem = "Si") Then
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Localizacion, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Localizacion, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                End If

            End If
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            IngInsumo.Categoria.SelectedItem = False
            IngInsumo.lugar.SelectedItem = False
            IngInsumo.localizado.Text = ""
            IngInsumo.Estado.Text = ""
            IngInsumo.soporte.SelectedItem = False
            IngInsumo.CantidadComprar.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTicket()
        'este Se utiliza en Ticket.vb
        Dim codi As String
        codi = textoAleatorio()
        Call conexion()
        Try
            cmd = New OdbcCommand("Insert into ticket(idInsumo,codigo,NomUsu,ApeUsu,Email ,Asunto,Prioridad,Mensaje) values(" & Ticket.txbNumero.Text & ",'" & codi & "','" & Ticket.txbNombre.Text & "',' " & Ticket.txbApellido.Text & "','" & Ticket.txbEmail.Text & "','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.txbMensaje.Text & "')", co)
            cmd.ExecuteNonQuery()
            Ticket.txbNombre.Text = ""
            Ticket.txbApellido.Text = ""
            Ticket.txbEmail.Text = ""
            Ticket.txbMensaje.Text = ""
            numTick(codi)
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub cerraTicket()
        Call conexion()
        Dim sol As String
        If (CerrarTicket.solucion.SelectedItem = "Algunos puntos si") Then
            sol = "mm"
        Else
            sol = CerrarTicket.solucion.SelectedItem
        End If
        Try
            cmd = New OdbcCommand("UPDATE ticket Set Solucion ='" & sol & "' , Detalle = '" & CerrarTicket.det.Text & "' where numero = " & CerrarTicket.Num.Text, co)
            cmd.ExecuteNonQuery()
            'Set 
            cmd = New OdbcCommand("Insert into fechasticket  Values(now()," & CerrarTicket.Num.Text & ",'Cierre')", co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Ticket cerrado", "Cerrado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            CerrarTicket.Close()
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTipo()
        Call conexion()
        cmd = New OdbcCommand("Insert Into tipoinsumo(tipo) values('" & AgregarTipo.tip.Text & "')", co)
        cmd.ExecuteNonQuery()
        MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    'Se cargan los datos en textbox y demas, para poder despues editarlos y guardarlos
    Sub datosIns()
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        cmd = New OdbcCommand("SELECT Nombre FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.Nombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Categoria FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.Cat.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Estado FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.Estado.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Lugar FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.lugar.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Localizacion FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        Dim l As String = cmd.ExecuteScalar().ToString
        If (l = "") Then
            editarInsumo.localizado.Text = ""
        Else
            editarInsumo.localizado.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Soporte FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.soporte.SelectedItem = cmd.ExecuteScalar()

        cmd = New OdbcCommand("SELECT CantPedido FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        Dim c As String = cmd.ExecuteScalar().ToString
        If (c = "") Then
            editarInsumo.Cantidad.Text = ""
            editarInsumo.compra.SelectedItem = "no"
        Else
            editarInsumo.Cantidad.Text = cmd.ExecuteScalar()
            editarInsumo.compra.SelectedItem = "si"
        End If
    End Sub
    Sub datosUsu()
        'este Se utiliza en EdiUsu.vb
        Call conexion()
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.NuevoNombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Snombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim n As String = cmd.ExecuteScalar().ToString
        If (n = "") Then
            EdiUsu.Nombre2.Text = " "
        Else
            EdiUsu.Nombre2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Papellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Apellido.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Sapellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim ap As String = cmd.ExecuteScalar().ToString
        If (ap = "") Then
            EdiUsu.Apellido2.Text = " "
        Else
            EdiUsu.Apellido2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Tipo FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Tipo.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Lugar FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim l As String = cmd.ExecuteScalar().ToString
        If (l = "") Then
            EdiUsu.Lugar.SelectedItem = ""
        Else
            EdiUsu.Lugar.SelectedItem = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Email FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.CorreoNuevo.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Contrasenia FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.ContraNueva.Text = cmd.ExecuteScalar()

    End Sub
    Sub datosCerrarTicket()
        Call conexion()
        cmd = New OdbcCommand("SELECT numero FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
        If (cmd.ExecuteScalar() = 0 Or cmd.ExecuteScalar().ToString = "") Then
            MessageBox.Show("Error: ticket no encontrado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            cmd = New OdbcCommand("SELECT accion FROM fechasticket  Where numTicket=" & CerrarTicket.buscar.Text & " Order BY Fecha DESC", co)
            Dim cerrado As String = cmd.ExecuteScalar()
            If (cerrado = "Cierre") Then
                CerrarTicket.Men.Text = "Este ticket ya fue resuelto"
            Else
                cmd = New OdbcCommand("SELECT numero FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Num.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT codigo FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Cod.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT Asunto FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Asu.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT Email FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Em.Text = cmd.ExecuteScalar()

                Dim nomb As String
                cmd = New OdbcCommand("SELECT NomUsu FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                nomb = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT ApeUsu FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Nom.Text = nomb & " " & cmd.ExecuteScalar()

                cmd = New OdbcCommand("SELECT insumo.Lugar FROM ticket inner join insumo on Id= idInsumo Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Sec.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT Prioridad FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Prio.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("SELECT Mensaje FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
                CerrarTicket.Men.Text = cmd.ExecuteScalar()
            End If

        End If


    End Sub
    Sub rellenarTipo()
        Call conexion()
        ada = New OdbcDataAdapter("Select id,tipo from tipoinsumo", co)
        ds = New DataSet()
        ada.Fill(ds)
        IngInsumo.Tipo.DataSource = ds.Tables(0)
        IngInsumo.Tipo.ValueMember = ds.Tables(0).Columns(0).Caption
        IngInsumo.Tipo.DisplayMember = ds.Tables(0).Columns(1).Caption.ToString
    End Sub
    Sub rellenarTipoInsList()
        Call conexion()
        ada = New OdbcDataAdapter("Select id,tipo from tipoinsumo", co)
        ds = New DataSet()
        ada.Fill(ds)
        Insumos.tip.DataSource = ds.Tables(0)
        Insumos.tip.ValueMember = "id"
        Insumos.tip.DisplayMember = "tipo"
    End Sub
    'Busca para luego rellenar textboxs con la informacion
    Function BuscarUsu()
        'este Se utiliza en UsuV.vb
        Call conexion()
        Dim n1, n2, t, nom As String
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        n1 = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Papellido FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        n2 = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Tipo FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        t = cmd.ExecuteScalar()
        nom = n1 & " " & n2 & " - " & t
        Return nom
    End Function
    Function ExisteI()
        Dim si As String = "False"
        Call conexion()
        cmd = New OdbcCommand("Select Lugar from insumo where Id = " & Ticket.txbNumero.Text, co)
        'Dim l As String = cmd.ExecuteScalar().ToString
        If (Len(cmd.ExecuteScalar) = 0) Then
            si = "False"
        Else
            si = "True"
        End If
        Return si
    End Function
    Sub buscarInsu()
        Call conexion()
        If (ExisteI() = False) Then
            MessageBox.Show("Error :no se encontro insumo con el numero indicado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                cmd = New OdbcCommand("Select Lugar from insumo where Id = " & Ticket.txbNumero.Text, co)
                Ticket.lblLugar.Text = cmd.ExecuteScalar()
                Ticket.lblLugar.Visible = True
                cmd = New OdbcCommand("Select Localizacion from insumo where Id =" & Ticket.txbNumero.Text, co)
                Ticket.lblLoca.Text = cmd.ExecuteScalar().ToString
                Ticket.lblLoca.Visible = True
                cmd = New OdbcCommand("Select tipoinsumo.tipo from insumo inner join tipoinsumo on tipoinsumo.id=insumo.Tipo where insumo.Id = " & Ticket.txbNumero.Text, co)
                Ticket.lblTipo.Text = cmd.ExecuteScalar()
                Ticket.lblTipo.Visible = True
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub

    'Se actualizan los datos de Usuarios e insumos en la BD con los datos editados 
    Sub editarPersona()
        'este Se utiliza en EdiUsu.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("UPDATE usuario Set Pnombre = '" & EdiUsu.NuevoNombre.Text & "', Snombre ='" & EdiUsu.Nombre2.Text & "' , Papellido = '" & EdiUsu.Apellido.Text & "' , Sapellido = '" & EdiUsu.Apellido2.Text & "' , Email = '" & EdiUsu.CorreoNuevo.Text & "', Contrasenia = '" & EdiUsu.ContraNueva.Text & "' , Tipo = '" & EdiUsu.Tipo.SelectedItem & "', Lugar = '" & EdiUsu.Lugar.SelectedItem & "' WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub editInsumo()
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        Try
            If (editarInsumo.compra.SelectedItem = "si") Then
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "', CantPedido='" & editarInsumo.Cantidad.Text & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localizacion ='" & editarInsumo.localizado.Text & "', Estado ='" & editarInsumo.Estado.Text & "', Soporte = '" & editarInsumo.soporte.SelectedItem & "', CantPedido ='" & editarInsumo.Cantidad.Text & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localizacion ='" & editarInsumo.localizado.Text & "', Estado ='" & editarInsumo.Estado.Text & "', Soporte = '" & editarInsumo.soporte.SelectedItem & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                End If

            End If
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            editarInsumo.Nombre.Text = ""
            editarInsumo.localizado.Text = ""
            editarInsumo.Estado.Text = ""
            editarInsumo.soporte.SelectedItem = ""
            editarInsumo.Cantidad.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub

    'Se eliminan Usuarios e insumos
    Sub EliminarUsu()
        'este Se utiliza en UsuV.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("DELETE FROM usuario WHERE Cedula= '" & UsuV.Cedula.Text & "' ", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        End Try
    End Sub
    Sub eliminarIns()
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("DELETE FROM insumo WHERE Id= '" & editarInsumo.numero.Text & "' ", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        End Try
    End Sub

    'Se listan los datos con diferentes filtros(Sin terminar)
    Sub listarTAbiertos()
        Call conexion()
        ada = New OdbcDataAdapter("Select fechasticket.Fecha AS FECHA, Prioridad AS PRIORIDAD , Asunto AS ASUNTO, insumo.Lugar as SECTOR,Mensaje as MENSAJE FROM ticket inner join fechasticket on numTicket = numero inner join insumo on Id= idInsumo where fechasticket.accion = 'Alta' ", co)
        ds = New DataSet()
        ada.Fill(ds)
        Listado.Tickets.DataSource = ds.Tables(0)
        Listado.Tickets.Columns("FECHA").Width = 100
        Listado.Tickets.Columns("PRIORIDAD").Width = 80
        Listado.Tickets.Columns("ASUNTO").Width = 80
        Listado.Tickets.Columns("SECTOR").Width = 80
        Listado.Tickets.Columns("MENSAJE").Width = 300
    End Sub
    Sub listarTCerrados()
        Call conexion()
        cmd = New OdbcCommand("Select ")
        ada = New OdbcDataAdapter("Select fechasticket.Fecha AS FECHA, Prioridad AS PRIORIDAD , Asunto AS ASUNTO, insumo.Lugar as SECTOR,Mensaje as MENSAJE FROM ticket inner join fechasticket on numTicket = numero inner join insumo on Id= idInsumo where fechasticket.accion = 'Cierre' ", co)
        ds = New DataSet()
        ada.Fill(ds)
        Listado.Tickets.DataSource = ds.Tables(0)
        Listado.Tickets.Columns("FECHA").Width = 100
        Listado.Tickets.Columns("PRIORIDAD").Width = 80
        Listado.Tickets.Columns("ASUNTO").Width = 80
        Listado.Tickets.Columns("SECTOR").Width = 80
        Listado.Tickets.Columns("MENSAJE").Width = 300
    End Sub
    Sub listarInsumos(num As Integer)
        Call conexion()
        If (num = 0) Then
            ada = New OdbcDataAdapter("Select Nombre AS NOMBRE,Lugar AS LUGAR, tipoinsumo.tipo as TIPO FROM insumo inner join tipoinsumo on tipoinsumo.Id = insumo.Tipo", co)
            ds = New DataSet()
            ada.Fill(ds)
            Insumos.Insumo.DataSource = ds.Tables(0)
            Insumos.Insumo.Columns("NOMBRE").Width = 100
            Insumos.Insumo.Columns("TIPO").Width = 80
            Insumos.Insumo.Columns("LUGAR").Width = 80
            'Insumos.Insumo.Columns("Comprar").Width = 80
        Else
            ada = New OdbcDataAdapter("Select Nombre AS NOMBRE,Lugar AS LUGAR, tipoinsumo.tipo as TIPO FROM insumo inner join tipoinsumo on tipoinsumo.Id = insumo.Tipo where tipoinsumo.id = " & num, co)
            ds = New DataSet()
            ada.Fill(ds)
            Insumos.Insumo.DataSource = ds.Tables(0)
            Insumos.Insumo.Columns("NOMBRE").Width = 100
            Insumos.Insumo.Columns("TIPO").Width = 80
            Insumos.Insumo.Columns("LUGAR").Width = 80
            'Insumos.Insumo.Columns("Comprar").Width = 80
        End If
    End Sub

    'esto busca y muestra al usuario el numero de un ticket segun el codigo
    Sub numTick(cod)
        ' se utiliza en Modulo.altaTicket()
        Call conexion()
        Dim num As Integer
        cmd = New OdbcCommand("Select numero from ticket where codigo ='" & cod & "'", co)
        num = cmd.ExecuteScalar()
        MessageBox.Show("Registro guardado" & vbNewLine & "El numero del ticket es: " & num, "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    'se verifica la cedula, que no exista en la BD y que sea valida
    Function cedula(C As String)
        'este Se utiliza en IngUsuario.vb
        'Se comprueba si existe la cedula en la BD
        Call conexion()
        Dim n1, n2 As String
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario  WHERE Cedula = '" & C & "'", co)
        n1 = cmd.ExecuteScalar()
        ' si no existe no rellenara n2
        If (n1 = "") Then
            n2 = ""
        Else
            n2 = "Existe"
        End If

        'Se verifica si es Uruguaya
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C)
        pos = 1
        arr = 0
        multi = 0
        suma = 0
        If (cantidad = 8) Then
            While (pos < 8)
                car = Mid(C, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While
            resto = 10 - Mid(suma, 3, 1)

            'si no existe(n2 vacio) y es valida, retornara true indicando que se puede guardar
            If (resto = Mid(C, 8, 1) And n2 = "") Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
    'Esto solo comprueba si esta vacio un textbox o si cumple ciertos puntos
    Function vacio(text As String)
        If (text = "") Then
            Return False
        Else
            Return True
        End If
    End Function
    Function email(text As String)
        Dim cant As Integer = Len(text)
        Dim pos As Integer = 1
        Dim caracter As String
        Dim arroba, punto As Integer
        arroba = 0
        punto = 0
        While (pos <= cant)
            caracter = Mid(text, pos, 1)
            If (caracter = "@") Then
                arroba = 1
            ElseIf (caracter = ".") Then
                punto = 1
            End If
            pos += 1
        End While
        If (arroba = 1 And punto = 1) Then
            Return True
        Else
            Return False
        End If
    End Function
    'En este se genera un texto aleatorio de 5 digitos de numeros y letras para los tickets
    Function textoAleatorio()
        'este Se utiliza en Modulo.altaTicket()
        Call conexion()
        Dim obj As New Random()
        Dim posibles As String = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim longitud As Integer = posibles.Length
        Dim letra As Char
        Dim longitudnuevacadena As Integer = 5
        Dim nuevacadena As String = Nothing
        Dim numero As Integer = 0
        Dim Existe As Integer = 1
        While Existe = 1
            numero = 0
            'While numero = 0
            For i As Integer = 0 To longitudnuevacadena - 1
                    letra = posibles(obj.[Next](longitud))
                    nuevacadena += letra.ToString()
                Next
            'If (Val(letra) * 1 >= 0 And Val(letra) <= 9) Then
            'numero = numero + 1
            'End If
            'End While

            'para no repetir codigos, se busca el codigo en BD y si ya esta registrado se realiza otro codigo de nuevo
            cmd = New OdbcCommand("SELECT numero FROM ticket  WHERE codigo = '" & nuevacadena & "'", co)
            Dim num As String = cmd.ExecuteScalar()
            If (num = "") Then
                Existe = 0
            Else
                Existe = 1
            End If
        End While
        Return nuevacadena
    End Function
    'Se rellena el informe del ticket al invitado querer saber sobre un ticket
    Sub InformeI()
        Call conexion()
        cmd = New OdbcCommand("Select NomUsu FROM ticket WHERE numero = '" & InformeInvitado.TextBox2.Text & "' ", co)
        If (cmd.ExecuteScalar() = "") Then
            MessageBox.Show("Error: ticket no encontrado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            cmd = New OdbcCommand("Select numero FROM ticket WHERE numero = '" & InformeInvitado.TextBox2.Text & "' ", co)
            InformeInvitado.num.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("Select Solucion FROM ticket WHERE numero = '" & InformeInvitado.TextBox2.Text & "' ", co)
            Dim so As String = cmd.ExecuteScalar().ToString
            If (so = "") Then
                InformeInvitado.s.Text = "Aún no se soluciono"
                InformeInvitado.det.Text = ""
            Else
                InformeInvitado.s.Text = cmd.ExecuteScalar()
                cmd = New OdbcCommand("Select Detalle FROM ticket WHERE numero = '" & InformeInvitado.TextBox2.Text & "' ", co)
                InformeInvitado.det.Text = cmd.ExecuteScalar()
            End If
        End If
    End Sub
    'se comprueba que exista el usuario con la cedula ingresada en UsuV.vb
    Function Usu(Cedula)
        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        Return cmd.ExecuteNonQuery()
    End Function
End Module