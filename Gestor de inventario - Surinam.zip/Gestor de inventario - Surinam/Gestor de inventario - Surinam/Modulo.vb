﻿Imports System.Data.Odbc
Module Modulo
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet
    Function conexion()
        co = New OdbcConnection("Dsn=conexion")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    Function login(em, c)
        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Email = '" & em & "'  AND Contraseña = '" & c & "'", co)
        Return cmd.ExecuteScalar()

    End Function

    Sub altaUsu()
        Call conexion()
        If IngUsuario.pNombre.Text = "" Or IngUsuario.sNombre.Text = "" Or IngUsuario.pApellido.Text = "" Or IngUsuario.sApellido.Text = "" Or IngUsuario.Cedula.Text = "" Or IngUsuario.Email.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                If (IngUsuario.Tipo.SelectedIndex = 0) Then
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "','" & IngUsuario.lugar.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into usuario values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & "',' ')", co)
                    cmd.ExecuteNonQuery()
                End If
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                IngUsuario.pNombre.Text = ""
                IngUsuario.sNombre.Text = " "
                IngUsuario.pApellido.Text = ""
                IngUsuario.sApellido.Text = " "
                IngUsuario.Cedula.Text = ""
                IngUsuario.Email.Text = ""
                IngUsuario.Contraseña.Text = ""
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
    Sub altaInsumo()
        Call conexion()
        Try
            If (IngInsumo.compra.SelectedItem = "si") Then
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Localización, Estado, Soporte, CantPedido) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & " ','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & IngInsumo.CantidadComprar.Text & "')", co)
                    cmd.ExecuteNonQuery()
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre, Tipo, Lugar, Localización, Estado, Soporte) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.tipo.SelectedItem & "','" & IngInsumo.lugar.SelectedItem & "','" & IngInsumo.localizado.Text & " ','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "')", co)
                    cmd.ExecuteNonQuery()
                End If

            End If
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            IngInsumo.nombre.Text = ""
            IngInsumo.tipo.SelectedItem = False
            IngInsumo.lugar.SelectedItem = False
            IngInsumo.localizado.Text = ""
            IngInsumo.Estado.Text = ""
            IngInsumo.soporte.SelectedItem = False
            IngInsumo.CantidadComprar.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTiket()
        Dim codi, num As String
        codi = textoAleatorio()
        Call conexion()
        Try
            If (Ticket.Sector.SelectedItem = "Biblioteca" Or Ticket.Sector.SelectedItem = "6T" Or Ticket.Sector.SelectedItem = "Taller") Then
                cmd = New OdbcCommand("Insert into ticket(codigo,NomUsu,ApeUsu,Email ,Sector,Asunto,Prioridad,Mensaje,FechaTick) values('" & codi & "','" & Ticket.nombre.Text & "',' " & Ticket.apellido.Text & "','" & Ticket.email.Text & "','" & Ticket.Sector.SelectedItem & " ','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.Mensaje.Text & "', now())", co)
                cmd.ExecuteNonQuery()
            Else
                cmd = New OdbcCommand("Insert into ticket(codigo,NomUsu,ApeUsu,Email ,Sector,Lugar,Asunto,Prioridad,Mensaje,FechaTick) values('" & codi & "','" & Ticket.nombre.Text & "',' " & Ticket.apellido.Text & "','" & Ticket.email.Text & "','" & Ticket.Sector.SelectedItem & " ','" & Ticket.Lugar.Text & "','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.Mensaje.Text & "')", co)
                cmd.ExecuteNonQuery()
            End If

            cmd = New OdbcCommand("Select numero from ticket where codigo ='" & codi & "'", co)
            num = cmd.ExecuteNonQuery()
            MessageBox.Show("Registro guardado" & vbNewLine & "El numero del ticket es: " & num, "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Ticket.nombre.Text = ""
            Ticket.apellido.Text = ""
            Ticket.email.Text = ""
            Ticket.Mensaje.Text = ""

        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub

    Sub editarPersona()
        Call conexion()
        Try
            cmd = New OdbcCommand("UPDATE usuario Set Pnombre = '" & EdiUsu.NuevoNombre.Text & "', Snombre ='" & EdiUsu.Nombre2.Text & "' , Papellido = '" & EdiUsu.Apellido.Text & "' , Sapellido = '" & EdiUsu.Apellido2.Text & "' , Email = '" & EdiUsu.CorreoNuevo.Text & "', Contraseña = '" & EdiUsu.ContraNueva.Text & "' , Tipo = '" & EdiUsu.Tipo.SelectedItem & "', Lugar = '" & EdiUsu.Lugar.SelectedItem & "' WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        End Try
    End Sub
    Sub editInsumo()
        Call conexion()
        Try
            If (editarInsumo.compra.SelectedItem = "si") Then
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Tipo='" & editarInsumo.tipo.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "', CantPedido='" & editarInsumo.Cantidad.Text & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Tipo='" & editarInsumo.tipo.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localización ='" & editarInsumo.localizado.Text & "', Estado ='" & editarInsumo.Estado.Text & "', Soporte = '" & editarInsumo.soporte.SelectedItem & "', CantPedido ='" & editarInsumo.Cantidad.Text & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6°T") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Tipo='" & editarInsumo.tipo.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Tipo='" & editarInsumo.tipo.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localización ='" & editarInsumo.localizado.Text & "', Estado ='" & editarInsumo.Estado.Text & "', Soporte = '" & editarInsumo.soporte.SelectedItem & "' where Id = '" & editarInsumo.numero.Text & "'", co)
                    cmd.ExecuteNonQuery()
                End If

            End If
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
            editarInsumo.Nombre.Text = ""
            editarInsumo.localizado.Text = ""
            editarInsumo.Estado.Text = ""
            editarInsumo.soporte.SelectedItem = ""
            editarInsumo.Cantidad.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub

    Sub EliminarUsu()
        Call conexion()
        Try
            cmd = New OdbcCommand("DELETE FROM usuario WHERE Cedula= '" & UsuV.Cedula.Text & "' ", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        End Try
    End Sub
    Sub eliminarIns()
        Call conexion()
        Try
            cmd = New OdbcCommand("DELETE FROM insumo WHERE Id= '" & editarInsumo.numero.Text & "' ", co)
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        End Try
    End Sub

    Sub datosIns()
        Call conexion()
        cmd = New OdbcCommand("SELECT Nombre FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.Nombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Tipo FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.tipo.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Estado FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.Estado.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Lugar FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.lugar.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Localización FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        Dim l As String = cmd.ExecuteScalar().ToString
        If (l = "") Then
            editarInsumo.localizado.Text = ""
        Else
            editarInsumo.localizado.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Soporte FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        editarInsumo.soporte.SelectedItem = cmd.ExecuteScalar()

        cmd = New OdbcCommand("SELECT CantPedido FROM insumo Where Id=" & editarInsumo.numero.Text, co)
        Dim c As String = cmd.ExecuteScalar().ToString
        If (c = "") Then
            editarInsumo.Cantidad.Text = ""
            editarInsumo.compra.SelectedItem = "no"
        Else
            editarInsumo.Cantidad.Text = cmd.ExecuteScalar()
            editarInsumo.compra.SelectedItem = "si"
        End If
    End Sub
    Sub datosUsu()
        Call conexion()
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.NuevoNombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Snombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim n As String = cmd.ExecuteScalar().ToString
        If (n = "") Then
            EdiUsu.Nombre2.Text = " "
        Else
            EdiUsu.Nombre2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Papellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Apellido.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Sapellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim ap As String = cmd.ExecuteScalar().ToString
        If (ap = "") Then
            EdiUsu.Apellido2.Text = " "
        Else
            EdiUsu.Apellido2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Tipo FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Tipo.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Lugar FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim l As String = cmd.ExecuteScalar().ToString
        If (l = "") Then
            EdiUsu.Lugar.SelectedItem = ""
        Else
            EdiUsu.Lugar.SelectedItem = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Email FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.CorreoNuevo.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Contraseña FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.ContraNueva.Text = cmd.ExecuteScalar()

    End Sub

    Sub listarT()
        Call conexion()
        ada = New OdbcDataAdapter("Select FechaTick AS FECHA, Prioridad AS PRIORIDAD , Asunto AS ASUNTO, Sector as SECTOR,Mensaje as MENSAJE FROM ticket", co)
        ds = New DataSet()
        ada.Fill(ds)
        Listado.Tickets.DataSource = ds.Tables(0)
        Listado.Tickets.Columns("FECHA").Width = 100
        Listado.Tickets.Columns("PRIORIDAD").Width = 80
        Listado.Tickets.Columns("ASUNTO").Width = 80
        Listado.Tickets.Columns("SECTOR").Width = 80
        Listado.Tickets.Columns("MENSAJE").Width = 300
    End Sub
    Sub listarTAbiertos()
        Call conexion()
        ada = New OdbcDataAdapter("Select FechaTick AS FECHA, Prioridad AS PRIORIDAD , Asunto AS ASUNTO, Sector as SECTOR,Mensaje as MENSAJE FROM ticket where NumInforme < 1 ", co)
        ds = New DataSet()
        ada.Fill(ds)
        Listado.Tickets.DataSource = ds.Tables(0)
        Listado.Tickets.Columns("FECHA").Width = 100
        Listado.Tickets.Columns("PRIORIDAD").Width = 80
        Listado.Tickets.Columns("ASUNTO").Width = 80
        Listado.Tickets.Columns("SECTOR").Width = 80
        Listado.Tickets.Columns("MENSAJE").Width = 300
    End Sub

    Sub InformeI()
        Call conexion()
        cmd = New OdbcCommand("Select numero As" & InformeInvitado.Label14.Text & " , Solucion AS " & InformeInvitado.Label14.Text & ", Detalle AS Descripcion  FROM ticket WHERE Codigo = '" & InformeInvitado.TextBox2.Text & "' ", co)
        ds = New DataSet()
        cmd.ExecuteScalar()
    End Sub
    Function Usu(Cedula)

        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        Return cmd.ExecuteNonQuery()

    End Function

    Function cedula(C As String)
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C)
        pos = 1
        arr = 0
        multi = 0
        suma = 0
        If (cantidad = 8) Then
            While (pos < 8)
                car = Mid(C, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While
            resto = 10 - Mid(suma, 3, 1)
            If (resto = Mid(C, 8, 1)) Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
    Function vacio(text As String)
        If (text = "") Then
            Return False
        Else
            Return True
        End If
    End Function
    Function email(text As String)
        Dim cant As Integer = Len(text)
        Dim pos As Integer = 1
        Dim caracter As String
        Dim arroba, punto As Integer
        arroba = 0
        punto = 0
        While (pos <= cant)
            caracter = Mid(text, pos, 1)
            If (caracter = "@") Then
                arroba = 1
            ElseIf (caracter = ".") Then
                punto = 1
            End If
            pos += 1
        End While
        If (arroba = 1 And punto = 1) Then
            Return True
        Else
            Return False
        End If
    End Function
    Function textoAleatorio()

        Dim obj As New Random()
        Dim posibles As String = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim longitud As Integer = posibles.Length
        Dim letra As Char
        Dim longitudnuevacadena As Integer = 5
        Dim nuevacadena As String = Nothing
        Dim numero As Integer = 0
        Do While numero = 0
            For i As Integer = 0 To longitudnuevacadena - 1
                letra = posibles(obj.[Next](longitud))
                nuevacadena += letra.ToString()
            Next
            If (Val(letra) * 1 >= 0 And Val(letra) <= 9) Then
                numero = numero + 1
            End If
        Loop

        Return nuevacadena
    End Function
End Module
