﻿Public Class Insumos
    Private Sub Insumos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Modulo.rellenarTipoInsList()
        tip.Text = ""
        Modulo.listarInsumos(0)
        stock.Text = Insumo.RowCount()
    End Sub

    Private Sub tip_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tip.SelectedIndexChanged
        If (tip.SelectedIndex + 1 > 0) Then
            Modulo.listarInsumos(tip.SelectedIndex + 1)
            stock.Text = Insumo.RowCount()
        End If
    End Sub
End Class