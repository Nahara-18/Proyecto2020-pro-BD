﻿Public Class CerrarTicket
    Dim clas = New Clase()
    Private Sub tbMensajeT_KeyPress_1(sender As Object, e As KeyPressEventArgs)
        e.Handled = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Listado.Visible = True
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        clas.cerraTicket()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        clas.datosCerrarTicket()
        If (det.Text = "") Then
            Button1.Visible = True
            Label1.Visible = False
        Else
            Button1.Visible = False
            Label1.Visible = True
        End If
    End Sub
End Class