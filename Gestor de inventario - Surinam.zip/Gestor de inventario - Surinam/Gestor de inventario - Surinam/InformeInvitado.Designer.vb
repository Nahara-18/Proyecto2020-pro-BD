﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class InformeInvitado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.num = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.det = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.s = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.textBusqueda = New System.Windows.Forms.TextBox()
        Me.Mostrar = New System.Windows.Forms.Button()
        Me.combo = New System.Windows.Forms.ComboBox()
        Me.datos = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.datos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Numero:"
        '
        'num
        '
        Me.num.AutoSize = True
        Me.num.Location = New System.Drawing.Point(78, 50)
        Me.num.Name = "num"
        Me.num.Size = New System.Drawing.Size(10, 13)
        Me.num.TabIndex = 6
        Me.num.Text = " "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(25, 128)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 13)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Detalles"
        '
        'det
        '
        Me.det.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.det.Location = New System.Drawing.Point(28, 145)
        Me.det.Multiline = True
        Me.det.Name = "det"
        Me.det.ReadOnly = True
        Me.det.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.det.Size = New System.Drawing.Size(410, 165)
        Me.det.TabIndex = 15
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(12, 78)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 13)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "¿Se soluciono?"
        '
        's
        '
        Me.s.AutoSize = True
        Me.s.Location = New System.Drawing.Point(39, 101)
        Me.s.Name = "s"
        Me.s.Size = New System.Drawing.Size(10, 13)
        Me.s.TabIndex = 17
        Me.s.Text = " "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(58, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "buscar por"
        '
        'textBusqueda
        '
        Me.textBusqueda.Location = New System.Drawing.Point(246, 14)
        Me.textBusqueda.Name = "textBusqueda"
        Me.textBusqueda.Size = New System.Drawing.Size(108, 20)
        Me.textBusqueda.TabIndex = 19
        '
        'Mostrar
        '
        Me.Mostrar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Mostrar.Location = New System.Drawing.Point(361, 11)
        Me.Mostrar.Name = "Mostrar"
        Me.Mostrar.Size = New System.Drawing.Size(62, 23)
        Me.Mostrar.TabIndex = 22
        Me.Mostrar.Text = "Buscar"
        Me.Mostrar.UseVisualStyleBackColor = True
        '
        'combo
        '
        Me.combo.FormattingEnabled = True
        Me.combo.Items.AddRange(New Object() {"codigo de ticket", "nombre de usuario"})
        Me.combo.Location = New System.Drawing.Point(112, 13)
        Me.combo.Name = "combo"
        Me.combo.Size = New System.Drawing.Size(111, 21)
        Me.combo.TabIndex = 23
        Me.combo.Text = " "
        '
        'datos
        '
        Me.datos.AllowUserToAddRows = False
        Me.datos.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.datos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.datos.Location = New System.Drawing.Point(199, 53)
        Me.datos.Name = "datos"
        Me.datos.RowHeadersVisible = False
        Me.datos.Size = New System.Drawing.Size(251, 86)
        Me.datos.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(205, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Requeridos"
        Me.Label2.Visible = False
        '
        'InformeInvitado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(462, 329)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.combo)
        Me.Controls.Add(Me.Mostrar)
        Me.Controls.Add(Me.textBusqueda)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.s)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.det)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.num)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.datos)
        Me.Name = "InformeInvitado"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Informe de Ticket"
        CType(Me.datos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents num As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents det As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents s As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents textBusqueda As TextBox
    Friend WithEvents Mostrar As Button
    Friend WithEvents combo As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents datos As DataGridView
End Class
