﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EdiUsu
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tipo = New System.Windows.Forms.ComboBox()
        Me.Lugar = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Nombre2 = New System.Windows.Forms.TextBox()
        Me.Apellido2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ContraNueva = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CorreoNuevo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Apellido = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NuevoNombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Guardar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Tipo
        '
        Me.Tipo.FormattingEnabled = True
        Me.Tipo.Items.AddRange(New Object() {"Administrador", "Técnico", "Invitado"})
        Me.Tipo.Location = New System.Drawing.Point(123, 137)
        Me.Tipo.Name = "Tipo"
        Me.Tipo.Size = New System.Drawing.Size(177, 21)
        Me.Tipo.TabIndex = 41
        '
        'Lugar
        '
        Me.Lugar.FormattingEnabled = True
        Me.Lugar.Items.AddRange(New Object() {"6ºTec", "Taller", "Salones", "Oficina"})
        Me.Lugar.Location = New System.Drawing.Point(365, 134)
        Me.Lugar.Name = "Lugar"
        Me.Lugar.Size = New System.Drawing.Size(177, 21)
        Me.Lugar.TabIndex = 40
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(325, 134)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 39
        Me.Label8.Text = "Lugar"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(89, 137)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 13)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "Tipo"
        '
        'Nombre2
        '
        Me.Nombre2.Location = New System.Drawing.Point(410, 40)
        Me.Nombre2.Name = "Nombre2"
        Me.Nombre2.Size = New System.Drawing.Size(192, 20)
        Me.Nombre2.TabIndex = 37
        '
        'Apellido2
        '
        Me.Apellido2.Location = New System.Drawing.Point(410, 77)
        Me.Apellido2.Name = "Apellido2"
        Me.Apellido2.Size = New System.Drawing.Size(192, 20)
        Me.Apellido2.TabIndex = 36
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(312, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Segundo Apellido"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(312, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Segundo Nombre"
        '
        'ContraNueva
        '
        Me.ContraNueva.Location = New System.Drawing.Point(266, 224)
        Me.ContraNueva.Name = "ContraNueva"
        Me.ContraNueva.Size = New System.Drawing.Size(177, 20)
        Me.ContraNueva.TabIndex = 33
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(200, 225)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 13)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Contraseña "
        '
        'CorreoNuevo
        '
        Me.CorreoNuevo.Location = New System.Drawing.Point(266, 182)
        Me.CorreoNuevo.Name = "CorreoNuevo"
        Me.CorreoNuevo.Size = New System.Drawing.Size(177, 20)
        Me.CorreoNuevo.TabIndex = 31
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(222, 182)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Correo"
        '
        'Apellido
        '
        Me.Apellido.Location = New System.Drawing.Point(94, 80)
        Me.Apellido.Name = "Apellido"
        Me.Apellido.Size = New System.Drawing.Size(192, 20)
        Me.Apellido.TabIndex = 29
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(46, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Apellido"
        '
        'NuevoNombre
        '
        Me.NuevoNombre.Location = New System.Drawing.Point(94, 39)
        Me.NuevoNombre.Name = "NuevoNombre"
        Me.NuevoNombre.Size = New System.Drawing.Size(192, 20)
        Me.NuevoNombre.TabIndex = 27
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(44, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 26
        Me.Label2.Text = "Nombre"
        '
        'Guardar
        '
        Me.Guardar.Location = New System.Drawing.Point(299, 278)
        Me.Guardar.Name = "Guardar"
        Me.Guardar.Size = New System.Drawing.Size(75, 23)
        Me.Guardar.TabIndex = 25
        Me.Guardar.Text = "Guardar"
        Me.Guardar.UseVisualStyleBackColor = True
        '
        'EdiUsu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(660, 341)
        Me.Controls.Add(Me.Tipo)
        Me.Controls.Add(Me.Lugar)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Nombre2)
        Me.Controls.Add(Me.Apellido2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ContraNueva)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CorreoNuevo)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Apellido)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.NuevoNombre)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Guardar)
        Me.Name = "EdiUsu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EdiUsu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Tipo As ComboBox
    Friend WithEvents Lugar As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Nombre2 As TextBox
    Friend WithEvents Apellido2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents ContraNueva As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents CorreoNuevo As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Apellido As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents NuevoNombre As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Guardar As Button
End Class
