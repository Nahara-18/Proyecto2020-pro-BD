﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuHorarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataHorarios = New System.Windows.Forms.DataGridView()
        Me.ComboClase = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboDia = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.DataHorarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataHorarios
        '
        Me.DataHorarios.AllowUserToAddRows = False
        Me.DataHorarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataHorarios.Enabled = False
        Me.DataHorarios.Location = New System.Drawing.Point(7, 116)
        Me.DataHorarios.Name = "DataHorarios"
        Me.DataHorarios.RowHeadersVisible = False
        Me.DataHorarios.Size = New System.Drawing.Size(493, 322)
        Me.DataHorarios.TabIndex = 2
        '
        'ComboClase
        '
        Me.ComboClase.FormattingEnabled = True
        Me.ComboClase.Location = New System.Drawing.Point(42, 65)
        Me.ComboClase.Name = "ComboClase"
        Me.ComboClase.Size = New System.Drawing.Size(121, 21)
        Me.ComboClase.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(198, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Dia"
        '
        'ComboDia
        '
        Me.ComboDia.FormattingEnabled = True
        Me.ComboDia.Items.AddRange(New Object() {"Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado"})
        Me.ComboDia.Location = New System.Drawing.Point(201, 65)
        Me.ComboDia.Name = "ComboDia"
        Me.ComboDia.Size = New System.Drawing.Size(121, 21)
        Me.ComboDia.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Clase"
        '
        'MenuHorarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(507, 450)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ComboDia)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ComboClase)
        Me.Controls.Add(Me.DataHorarios)
        Me.Name = "MenuHorarios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "MenuHorarios"
        CType(Me.DataHorarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataHorarios As DataGridView
    Friend WithEvents ComboClase As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboDia As ComboBox
    Friend WithEvents Label3 As Label
End Class
