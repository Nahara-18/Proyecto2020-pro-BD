﻿Public Class AgregarTipoYEditarContrase
    Dim clas = New Clase()
    Private Sub g_Click(sender As Object, e As EventArgs) Handles g.Click
        If (Label1.Text = "Contraseña nueva") Then
            clas.editarContraseña()
            Me.Close()
        Else
            clas.altaTipo()
            Me.Close()
            clas.rellenarTipoIng()
            IngInsumo.Tipo.Text = "Tipo"
        End If
    End Sub

    Private Sub v_CheckedChanged(sender As Object, e As EventArgs) Handles v.CheckedChanged
        If v.Checked = True Then
            tip.UseSystemPasswordChar = False
        Else
            tip.UseSystemPasswordChar = True
        End If
    End Sub
End Class