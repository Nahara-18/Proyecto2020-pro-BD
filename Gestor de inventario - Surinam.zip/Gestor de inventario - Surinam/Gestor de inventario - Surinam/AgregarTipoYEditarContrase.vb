﻿Public Class AgregarTipoYEditarContrase
    Public cedu As String
    Dim clas = New Clase()
    Private Sub g_Click(sender As Object, e As EventArgs) Handles g.Click
        If (Label1.Text = "Contraseña nueva") Then
            clas.editarContraseña(cedu)
            Me.Close()
        ElseIf (tbxTip.ReadOnly = True) Then
            Me.Close()
            Ticket.Close()
        Else
            clas.altaTipo()
            Me.Close()
            clas.rellenarTipoIng()
            IngInsumo.Tipo.Text = "Tipo"
        End If
    End Sub

    Private Sub v_CheckedChanged(sender As Object, e As EventArgs) Handles v.CheckedChanged
        If v.Checked = True Then
            tbxTip.UseSystemPasswordChar = False
        Else
            tbxTip.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub AgregarTipoYEditarContrase_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (tbxTip.ReadOnly = True) Then
            Me.Text = ""
            tbxTip.Font = New Font(tbxTip.Font.Size, 11)
            tbxTip.ForeColor = ForeColor.Blue
            Label1.Text = "Registro guardado" & vbNewLine & "El codigo del ticket es: "
            Label2.Visible = True
            v.Visible = False
            g.Text = "OK"

        End If
    End Sub
End Class