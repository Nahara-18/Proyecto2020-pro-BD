﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Listado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.list = New System.Windows.Forms.ComboBox()
        Me.Tickets = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.buscar = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ord = New System.Windows.Forms.Button()
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(82, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Listado de tickets"
        '
        'list
        '
        Me.list.FormattingEnabled = True
        Me.list.Items.AddRange(New Object() {"Abierto", "Cerrado"})
        Me.list.Location = New System.Drawing.Point(178, 6)
        Me.list.Name = "list"
        Me.list.Size = New System.Drawing.Size(104, 21)
        Me.list.TabIndex = 2
        Me.list.Text = "Todo"
        '
        'Tickets
        '
        Me.Tickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tickets.EnableHeadersVisualStyles = False
        Me.Tickets.Location = New System.Drawing.Point(1, 86)
        Me.Tickets.Name = "Tickets"
        Me.Tickets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Tickets.RowHeadersVisible = False
        Me.Tickets.Size = New System.Drawing.Size(645, 362)
        Me.Tickets.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(436, 48)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Buscar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'buscar
        '
        Me.buscar.Location = New System.Drawing.Point(285, 50)
        Me.buscar.Name = "buscar"
        Me.buscar.Size = New System.Drawing.Size(132, 20)
        Me.buscar.TabIndex = 5
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(12, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 21)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(550, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Cantidad"
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Codigo", "fecha apertura", "fecha  cierre", "tecnico asociado"})
        Me.ComboBox2.Location = New System.Drawing.Point(136, 48)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(134, 21)
        Me.ComboBox2.TabIndex = 22
        Me.ComboBox2.Text = "Opciones de busqueda"
        '
        'ord
        '
        Me.ord.Location = New System.Drawing.Point(303, 4)
        Me.ord.Name = "ord"
        Me.ord.Size = New System.Drawing.Size(54, 23)
        Me.ord.TabIndex = 23
        Me.ord.Text = "Ordenar"
        Me.ord.UseVisualStyleBackColor = True
        '
        'Listado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(647, 450)
        Me.Controls.Add(Me.ord)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.buscar)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Tickets)
        Me.Controls.Add(Me.list)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Listado"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ListadoTicket"
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents list As ComboBox
    Friend WithEvents Tickets As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents buscar As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ord As Button
End Class
