﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ListadoT
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.list = New System.Windows.Forms.ComboBox()
        Me.Tickets = New System.Windows.Forms.DataGridView()
        Me.b = New System.Windows.Forms.Button()
        Me.buscar = New System.Windows.Forms.TextBox()
        Me.Button = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.busc = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(82, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Listado de tickets"
        '
        'list
        '
        Me.list.FormattingEnabled = True
        Me.list.Items.AddRange(New Object() {"Todo", "Abierto", "Cerrado"})
        Me.list.Location = New System.Drawing.Point(178, 6)
        Me.list.Name = "list"
        Me.list.Size = New System.Drawing.Size(104, 21)
        Me.list.TabIndex = 2
        Me.list.Text = "Todo"
        '
        'Tickets
        '
        Me.Tickets.AllowUserToAddRows = False
        Me.Tickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tickets.EnableHeadersVisualStyles = False
        Me.Tickets.Location = New System.Drawing.Point(1, 86)
        Me.Tickets.Name = "Tickets"
        Me.Tickets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Tickets.RowHeadersVisible = False
        Me.Tickets.Size = New System.Drawing.Size(645, 362)
        Me.Tickets.TabIndex = 3
        '
        'b
        '
        Me.b.Location = New System.Drawing.Point(452, 45)
        Me.b.Name = "b"
        Me.b.Size = New System.Drawing.Size(75, 23)
        Me.b.TabIndex = 4
        Me.b.Text = "Buscar"
        Me.b.UseVisualStyleBackColor = True
        Me.b.Visible = False
        '
        'buscar
        '
        Me.buscar.Location = New System.Drawing.Point(314, 47)
        Me.buscar.Name = "buscar"
        Me.buscar.Size = New System.Drawing.Size(132, 20)
        Me.buscar.TabIndex = 5
        Me.buscar.Visible = False
        '
        'Button
        '
        Me.Button.Location = New System.Drawing.Point(12, 2)
        Me.Button.Name = "Button"
        Me.Button.Size = New System.Drawing.Size(37, 21)
        Me.Button.TabIndex = 19
        Me.Button.Text = "<"
        Me.Button.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 13)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Cantidad"
        '
        'busc
        '
        Me.busc.FormattingEnabled = True
        Me.busc.Items.AddRange(New Object() {"Codigo", "fecha apertura", "fecha cierre", "tecnico asociado"})
        Me.busc.Location = New System.Drawing.Point(313, 9)
        Me.busc.Name = "busc"
        Me.busc.Size = New System.Drawing.Size(134, 21)
        Me.busc.TabIndex = 22
        Me.busc.Text = "Opciones de busqueda"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(81, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(10, 13)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "."
        '
        'ListadoT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(647, 450)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.busc)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button)
        Me.Controls.Add(Me.buscar)
        Me.Controls.Add(Me.b)
        Me.Controls.Add(Me.Tickets)
        Me.Controls.Add(Me.list)
        Me.Controls.Add(Me.Label1)
        Me.Name = "ListadoT"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ListadoTicket"
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents list As ComboBox
    Friend WithEvents Tickets As DataGridView
    Friend WithEvents b As Button
    Friend WithEvents buscar As TextBox
    Friend WithEvents Button As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents busc As ComboBox
    Friend WithEvents Label3 As Label
End Class
