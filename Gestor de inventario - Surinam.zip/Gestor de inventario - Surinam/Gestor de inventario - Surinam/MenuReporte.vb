﻿Public Class MenuReporte
    Public cedu As String
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Login.Visible = True
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipoYEditarContrase.Text = "Contraseña"
        AgregarTipoYEditarContrase.cedu = cedu
        AgregarTipoYEditarContrase.Visible = True
        AgregarTipoYEditarContrase.v.Visible = True
        AgregarTipoYEditarContrase.Label1.Text = "Contraseña nueva"
        AgregarTipoYEditarContrase.tbxTip.UseSystemPasswordChar = True
    End Sub

    Private Sub ATicket_Click(sender As Object, e As EventArgs) Handles ATicket.Click
        Ticket.Visible = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Compras.Visible = True
        Compras.cedu = cedu
        Compras.tipo = "repor"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListadoT.Visible = True
        ListadoT.tipo = "repor"
    End Sub
End Class