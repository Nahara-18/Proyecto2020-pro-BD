﻿Public Class MenuReporte
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Login.Visible = True
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        AgregarTipoYEditarContrase.Text = "Contraseña"
        AgregarTipoYEditarContrase.Visible = True
        AgregarTipoYEditarContrase.v.Visible = True
        AgregarTipoYEditarContrase.Label1.Text = "Contraseña nueva"
        AgregarTipoYEditarContrase.tip.UseSystemPasswordChar = True
    End Sub

    Private Sub ATicket_Click(sender As Object, e As EventArgs) Handles ATicket.Click
        Ticket.Visible = True
    End Sub
End Class