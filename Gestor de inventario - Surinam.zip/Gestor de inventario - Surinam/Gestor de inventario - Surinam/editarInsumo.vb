﻿Public Class editarInsumo
    Private Sub guardar_Click(sender As Object, e As EventArgs) Handles guardar.Click
        Dim completo As Integer = 0
        'en cada uno de los siguientes "If" se comprobaran los datos, si no estan vacios, si tienen ciertos caracteres,etc
        'si los datos son correctos se sumara en cuenta uno en uno
        'se comprobara en el ultimo if si todos lod datos minimos requeridos fueron ingresados y se registra
        If (Modulo.vacio(Nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Cat.SelectedItem = "") Then
            rCat.ForeColor = ForeColor.Red
        Else
            rCat.ForeColor = ForeColor.Black
            completo += 1

        End If
        If (Modulo.vacio(Estado.Text()) = "false") Then
            Est.ForeColor = ForeColor.Red
        Else
            Est.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6°T") Then
            rLugar.Visible = False
            completo += 1
        Else
            If (lugar.SelectedItem = "" OrElse localizado.Text = "") Then

                rLugar.Visible = True
            Else
                rLugar.Visible = False
                completo += 1
            End If
        End If
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            sop.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (compra.SelectedItem = "") Then
            com.ForeColor = ForeColor.Red
        ElseIf (compra.SelectedItem = "si") Then
            If (Cantidad.Text = "") Then
                C.ForeColor = ForeColor.Red
            Else
                C.ForeColor = ForeColor.Black
                completo += 1
            End If
        Else
            C.ForeColor = ForeColor.Black
            completo += 1
        End If

        If (completo = 6) Then
            Modulo.editInsumo()
        End If
    End Sub
    Private Sub eliminar_Click(sender As Object, e As EventArgs) Handles eliminar.Click
        Modulo.eliminarIns()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Cantidad.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub
    Private Sub x_SelectedIndexChanged(sender As Object, e As EventArgs) Handles compra.SelectedIndexChanged
        If (compra.SelectedItem = "si") Then
            Cantidad.Visible = True
            C.Visible = True
        Else
            Cantidad.Visible = False
            C.Visible = False
        End If
    End Sub
    Private Sub lugar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lugar.SelectedIndexChanged
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6°T") Then
            localizado.Visible = False
        Else
            localizado.Visible = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Modulo.datosIns()
    End Sub

End Class