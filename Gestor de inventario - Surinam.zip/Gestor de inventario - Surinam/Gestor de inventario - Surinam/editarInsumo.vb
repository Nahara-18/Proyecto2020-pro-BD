﻿Public Class editarInsumo

    Private Sub guardar_Click(sender As Object, e As EventArgs) Handles guardar.Click
        Dim completo As Integer = 0
        If (Modulo.vacio(Nombre.Text()) = "false") Then
            N.ForeColor = ForeColor.Red
        Else
            N.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (tipo.SelectedItem = "") Then
            rTipo.Visible = True
        Else
            rTipo.Visible = False
            completo += 1

        End If
        If (Modulo.vacio(Estado.Text()) = "false") Then
            Est.ForeColor = ForeColor.Red
        Else
            Est.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (lugar.SelectedItem = "Taller" Or lugar.SelectedItem = "6°T") Then
            rLugar.Visible = False
            completo += 1
        Else
            If (lugar.SelectedItem = "" OrElse localizado.Text = "") Then

                rLugar.Visible = True
            Else
                rLugar.Visible = False
                completo += 1
            End If
        End If
        If (soporte.SelectedItem = "") Then
            sop.ForeColor = ForeColor.Red
        Else
            completo += 1
        End If
        If (x.SelectedItem = "") Then
            com.ForeColor = ForeColor.Red
        Else
            completo += 1
        End If

    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub


End Class