﻿Public Class Hora
    Dim clas = New Clase()
    Public materia As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim completo As Integer = 0
        If (TextBox4.Visible = True) Then
            If (TextBox4.Text = "" Or TextBox3.Text = "") Then
                MsgBox("Complete los campos")
            Else
                clas.AltaProfe(materia)
                Me.Close()
            End If
        Else
                If (TextBox1.Text = "" Or TextBox2.Text = "") Then
                Label1.ForeColor = ForeColor.Red
            Else
                Label1.ForeColor = ForeColor.Black
                clas.AltaHora()
                Me.Close()
            End If
        End If

    End Sub


    Private Sub dat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

End Class