﻿Public Class AgregarTipo
    Private Sub g_Click(sender As Object, e As EventArgs) Handles g.Click
        Modulo.altaTipo()
        Me.Close()
        Modulo.rellenarTipo()
        IngInsumo.Tipo.Text = "Tipo"
    End Sub
End Class