﻿Public Class IngUsuario
    Private Sub Registrar_Click(sender As Object, e As EventArgs) Handles Registrar.Click
        Dim cuenta As Integer = 0
        If (Modulo.vacio(pNombre.Text()) = "false") Then
            pNom.ForeColor = ForeColor.Red
        Else
            pNom.ForeColor = ForeColor.Black
            cuenta += 1
        End If
        If (Modulo.vacio(pApellido.Text()) = "false") Then
            pAp.ForeColor = ForeColor.Red
        Else
            pAp.ForeColor = ForeColor.Black
            cuenta += 1
        End If
        If (Modulo.cedula(Cedula.Text) = "false") Then
            C.ForeColor = ForeColor.Red
        Else
            C.ForeColor = ForeColor.Black
            cuenta += 1
        End If
        If (Modulo.email(Email.Text) = "false") Then
            Em.ForeColor = ForeColor.Red
        Else
            Em.ForeColor = ForeColor.Black
            cuenta += 1
        End If
        If (Modulo.vacio(Contraseña.Text()) = "false") Then
            pAp.ForeColor = ForeColor.Red
        Else
            pAp.ForeColor = ForeColor.Black
            cuenta += 1
        End If


        If (cuenta = 5) Then
            Modulo.altaUsu()
        End If

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub texto_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles pNombre.KeyPress, sNombre.KeyPress, pApellido.KeyPress, sApellido.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub Email_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Email.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf (e.KeyChar = "@") Then
            e.Handled = False
        ElseIf (e.KeyChar = ".") Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub Conttraseña_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub
    Private Sub Cedula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Cedula.KeyPress
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
        If e.KeyChar = ChrW(Keys.Enter) Then
            e.Handled = True
            SendKeys.Send("{TAB}")
        End If
    End Sub

    Private Sub Tipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Tipo.SelectedIndexChanged
        If (Tipo.SelectedItem = "Tecnico") Then
            lugar.Visible = True
        Else
            lugar.Visible = False
        End If
    End Sub

    Private Sub mosCon_CheckedChanged(sender As Object, e As EventArgs) Handles mosCon.CheckedChanged
        If mosCon.Checked = True Then
            Contraseña.UseSystemPasswordChar = False
        Else
            Contraseña.UseSystemPasswordChar = True
        End If
    End Sub
End Class