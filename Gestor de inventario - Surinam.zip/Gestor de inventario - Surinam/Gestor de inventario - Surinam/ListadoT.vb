﻿Public Class ListadoT
    Dim clas = New Clase()
    Public cedu As String
    Public sector As String

    Dim a As Integer = 0
    Private Sub Listado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.listarTickets(0, sector)
        Label3.Text = Tickets.RowCount()
    End Sub

    Private Sub Tickets_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Tickets.CellMouseClick
        Dim a As String = Me.Tickets.CurrentRow.Cells("Num").Value
        CerrarTicket.Visible = True
        CerrarTicket.cedu = cedu
        CerrarTicket.buscar.Text = a
        CerrarTicket.Button3.PerformClick()
    End Sub

    Private Sub list_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles list.SelectionChangeCommitted
        If (list.SelectedItem = "Abierto") Then
            clas.listarTickets(1, sector)
        ElseIf (list.SelectedItem = "Cerrado") Then
            clas.listarTickets(2, sector)
        Else
            clas.listarTickets(0, sector)
        End If
        Label3.Text = Tickets.RowCount()
    End Sub
    Dim selec As Integer
    Private Sub ComboBox2_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles busc.SelectionChangeCommitted

        If (busc.SelectedItem = "Codigo") Then
            buscar.Visible = True
            selec = 1
        ElseIf (busc.SelectedItem = "fecha apertura") Then
            selec = 2
            buscar.Visible = True
        ElseIf (busc.SelectedItem = "fecha cierre") Then
            selec = 3
            buscar.Visible = True
        ElseIf (busc.SelectedItem = "tecnico asociado") Then
            selec = 4
            buscar.Visible = True
        Else
            selec = 0
            buscar.Visible = False
        End If
        b.Visible = True


    End Sub

    Private Sub b_Click(sender As Object, e As EventArgs) Handles b.Click
        If (selec = 1) Then
            clas.bustick(1)
        ElseIf (selec = 2) Then
            clas.bustick(2)
        ElseIf (selec = 3) Then
            clas.bustick(3)
        ElseIf (selec = 4) Then
            clas.bustick(4)
        Else
            clas.listarTickets(0)
        End If
        Label3.Text = Tickets.RowCount()
    End Sub

    Private Sub Button_Click(sender As Object, e As EventArgs) Handles Button.Click
        Me.Close()
    End Sub

End Class