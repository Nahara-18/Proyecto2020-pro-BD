﻿Public Class ListadoT
    Dim clas = New Clase()
    Public cedu, sector, tipo As String
    Dim estado As Integer = 0

    Dim a As Integer = 0
    Private Sub Listado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.listarTickets(1, sector)
        Label3.Text = Tickets.RowCount()
        If (sector = "") Then
        Else
            list.Visible = False
            Label1.Visible = False
            End IfS
    End Sub

    Private Sub Tickets_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Tickets.CellMouseClick

        Dim a As String = Me.Tickets.CurrentRow.Cells("Num").Value
            CerrarTicket.Visible = True
            CerrarTicket.cedu = cedu
            CerrarTicket.buscar.Text = a
        CerrarTicket.Button3.PerformClick()
        If (tipo = "") Then
        Else
            CerrarTicket.Button1.Visible = False
        End If
    End Sub

    Private Sub list_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles list.SelectionChangeCommitted
        If (list.SelectedItem = "Abierto") Then
            estado = 1
            clas.listarTickets(1, sector)
        ElseIf (list.SelectedItem = "Cerrado") Then
            estado = 2
            clas.listarTickets(2, sector)
        Else
            estado = 0
            clas.listarTickets(0, sector)
        End If
        Label3.Text = Tickets.RowCount()
    End Sub
    Dim selec As Integer
    Private Sub ComboBox2_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles busc.SelectionChangeCommitted

        If (busc.SelectedItem = "Codigo") Then
            buscar.Visible = True
            selec = 1
            lugar.Visible = False
        ElseIf (busc.SelectedItem = "fecha apertura") Then
            selec = 2
            buscar.Visible = True
            lugar.Visible = False
        ElseIf (busc.SelectedItem = "fecha cierre") Then
            selec = 3
            buscar.Visible = True
            lugar.Visible = False
        ElseIf (busc.SelectedItem = "Area") Then
            selec = 4
            lugar.Visible = True
            buscar.Visible = False
        Else
            selec = 0
            buscar.Visible = False
            lugar.Visible = False
        End If
        b.Visible = True


    End Sub


    Private Sub b_Click(sender As Object, e As EventArgs) Handles b.Click
        If (selec = 1) Then
            clas.bustick(1, estado)
        ElseIf (selec = 2) Then
            clas.bustick(2, estado)
        ElseIf (selec = 3) Then
            clas.bustick(3, estado)
        ElseIf (selec = 4) Then
            clas.bustick(4, estado)
        Else
            clas.listarTickets(0)
        End If
        Label3.Text = Tickets.RowCount()
    End Sub

    Private Sub Button_Click(sender As Object, e As EventArgs) Handles Button.Click
        Me.Close()
    End Sub
End Class