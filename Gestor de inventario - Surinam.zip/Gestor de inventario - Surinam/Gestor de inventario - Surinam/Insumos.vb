﻿Public Class Insumos
    Dim clas = New Clase()
    Private Sub Insumos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.rellenarTipoList()
        tip.Text = "Todo"
        clas.listarInsumos(0)
        stock.Text = Insumo.RowCount()
    End Sub

    Private Sub tip_SelectedIndexChanged(sender As Object, e As EventArgs) Handles tip.SelectedIndexChanged
        If (tip.SelectedIndex + 1 > 0) Then
            clas.listarInsumos(tip.SelectedIndex + 1)
            stock.Text = Insumo.RowCount()
        End If
    End Sub

    Private Sub Insumo_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles Insumo.CellMouseClick
        Dim a As String = Me.Insumo.CurrentRow.Cells("Num").Value
        editarInsumo.Visible = True
        editarInsumo.numero.Text = a
        editarInsumo.Button2.PerformClick()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (tip.Text = "Todo") Then
            clas.busInsuNombre(0)
            stock.Text = Insumo.RowCount()
        Else
            clas.busInsuNombre(tip.SelectedIndex + 1)
            stock.Text = Insumo.RowCount()
        End If
    End Sub

End Class