﻿Public Class AgregarHorarios
    Dim clas = New Clase()
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim completo As Integer = 0

        If (ComboDia.Text = "Seleccionar") Then
            Label5.ForeColor = ForeColor.Red
        Else
            Label5.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (ComboProfesor.Text = "Seleccionar") Then
            Label2.ForeColor = ForeColor.Red
        Else
            Label2.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (comboClase.Text = "Seleccionar") Then
            Label4.ForeColor = ForeColor.Red
        Else
            Label4.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (ComboMateria.Text = "Seleccionar") Then
            Label3.ForeColor = ForeColor.Red
        Else
            Label3.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (ComboHora.Text = "Seleccionar") Then
            Label1.ForeColor = ForeColor.Red
        Else
            Label1.ForeColor = ForeColor.Black
            completo += 1
        End If

        If (completo = 5) Then
            clas.altasHorarios()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        AgregarTipoYEditarContrase.Label1.Text = "Agregar Clase"
        AgregarTipoYEditarContrase.Text = ""
        AgregarTipoYEditarContrase.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Hora.Visible = True
        Hora.materia = ComboMateria.SelectedIndex + 1
        Hora.TextBox4.Visible = True
        Hora.TextBox3.Visible = True
        Hora.Label2.Visible = True
        Hora.Label3.Visible = True
        Hora.Label6.Visible = False
        Hora.Label1.Visible = False
        Hora.TextBox1.Visible = False
        Hora.TextBox2.Visible = False
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        AgregarTipoYEditarContrase.Label1.Text = "Agregar Materia"
        AgregarTipoYEditarContrase.Text = ""
        AgregarTipoYEditarContrase.Visible = True
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Hora.Visible = True
    End Sub

    Private Sub AgregarHorarios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ventana As String = "1"
        clas.rellenarHora()
        clas.rellenarClase(ventana)
        clas.rellenarMateria()
        ComboProfesor.Text = "Seleccionar"
    End Sub
    Private Sub ComboMateria_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboMateria.SelectionChangeCommitted
        Dim i As String = ComboMateria.SelectedIndex + 1
        clas.rellenarProfesor(i)
    End Sub
End Class