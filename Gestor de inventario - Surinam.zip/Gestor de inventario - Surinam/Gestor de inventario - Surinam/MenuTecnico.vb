﻿Public Class MenuTecnico
    Private Sub ingreso_Click(sender As Object, e As EventArgs) Handles ingreso.Click
        IngInsumo.Visible = True
    End Sub

    Private Sub editar_Click(sender As Object, e As EventArgs) Handles editar.Click
        editarInsumo.Visible = True
    End Sub

    Private Sub tickets_Click(sender As Object, e As EventArgs) Handles tickets.Click
        Listado.Visible = True
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Me.Close()
        Login.Visible = True
    End Sub

End Class