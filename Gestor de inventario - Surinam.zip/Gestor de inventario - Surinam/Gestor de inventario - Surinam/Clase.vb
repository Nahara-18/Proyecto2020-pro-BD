﻿Imports System.Data.Odbc
Public Class Clase
    Public co As New Odbc.OdbcConnection
    Public cmd As New Odbc.OdbcCommand
    Public ada As New Odbc.OdbcDataAdapter
    Public ds As New DataSet

    '  Conexion
    Function conexion()
        co = New OdbcConnection("Dsn=conexion")
        If co.State = ConnectionState.Closed Then
            co.Open()
        Else
            MsgBox("Error de conexion")
        End If
        Return co
    End Function
    '  Login Usuario
    Function login(em, c)
        Call conexion()
        cmd = New OdbcCommand("SELECT Tipo FROM usuario  WHERE Email = '" & em & "'  AND Contrasenia = '" & c & "'", co)
        Dim tipo As String = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Cedula FROM usuario  WHERE Email = '" & em & "'  AND Contrasenia = '" & c & "'", co)
        Dim ce As String = cmd.ExecuteScalar()
        cmd = New OdbcCommand("UPDATE usuario Set ultimoLogin = Now()  WHERE Email = '" & em & "'  AND Contrasenia = '" & c & "'", co)
        cmd.ExecuteScalar()
        If (tipo = "Tecnico") Then
            MenuTecnico.cedu = ce
            cmd = New OdbcCommand("SELECT Lugar FROM usuario  WHERE Email = '" & em & "'  AND Contrasenia = '" & c & "'", co)
            MenuTecnico.sector = cmd.ExecuteScalar()
        ElseIf (tipo = "Administrador") Then
            MenuAdmin.cedu = ce
        Else
            MenuReporte.cedu = ce
        End If
        Return tipo
    End Function

    '  Altas



    Sub altaUsu()
        'este Se utiliza en IngUsuario.vb
        Call conexion()
        If IngUsuario.pNombre.Text = "" Or IngUsuario.sNombre.Text = "" Or IngUsuario.pApellido.Text = "" Or IngUsuario.sApellido.Text = "" Or IngUsuario.Cedula.Text = "" Or IngUsuario.Email.Text = "" Then
            MessageBox.Show("Error: campo/s vacio/s", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                Dim sol As String
                If (IngUsuario.Tipo.SelectedIndex = 0) Then
                    sol = "','" & IngUsuario.lugar.SelectedItem & "')"
                Else
                    sol = "',' ')"
                End If
                cmd = New OdbcCommand("Insert into usuario(Cedula,Pnombre,Snombre,Papellido,Sapellido,Email,Contrasenia,Tipo,Lugar) values(" & IngUsuario.Cedula.Text & ",'" & IngUsuario.pNombre.Text & "',' " & IngUsuario.sNombre.Text & "','" & IngUsuario.pApellido.Text & "','" & IngUsuario.sApellido.Text & " ','" & IngUsuario.Email.Text & "','" & IngUsuario.Contraseña.Text & "','" & IngUsuario.Tipo.SelectedItem & sol, co)
                cmd.ExecuteNonQuery()
                MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                IngUsuario.pNombre.Text = ""
                IngUsuario.sNombre.Text = " "
                IngUsuario.pApellido.Text = ""
                IngUsuario.sApellido.Text = " "
                IngUsuario.Cedula.Text = ""
                IngUsuario.Email.Text = ""
                IngUsuario.Contraseña.Text = ""
            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
    Sub altaInsumo(c As String, repe As Integer, idIns As Integer)
        'este Se utiliza en IngInsumo.vb
        Call conexion()
        Try
            Dim veces As Integer = 1
            Dim nInsumo, sector As String
            veces = repe
            Do While (veces > 0)
                Dim pedido As Integer
                If (veces = 1) Then
                    pedido = IngInsumo.CantidadComprar.Text
                Else
                    pedido = 0
                End If
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6T" Or IngInsumo.lugar.SelectedItem = "Sala") Then
                    sector = "NULL"
                Else
                    sector = IngInsumo.localizado.Text
                End If

                If (IngInsumo.compra.SelectedItem = "Si") Then
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Localizacion,CompODon,Donador, Estado, Soporte, CantPedido,disponible) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & sector & "','" & IngInsumo.CompDon.SelectedItem & "','" & IngInsumo.donador.Text & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','" & pedido & "','s')", co)

                Else
                    cmd = New OdbcCommand("Insert into insumo(Nombre,Categoria, Tipo, Lugar, Localizacion,CompODon,Donador, Estado, Soporte,disponible) values('" & IngInsumo.nombre.Text & "','" & IngInsumo.Categoria.SelectedItem & "','" & (IngInsumo.Tipo.SelectedIndex + 1) & "','" & IngInsumo.lugar.SelectedItem & "','" & sector & "','" & IngInsumo.CompDon.SelectedItem & "','" & IngInsumo.donador.Text & "','" & IngInsumo.Estado.Text & "','" & IngInsumo.soporte.SelectedItem & "','s')", co)

                End If
                cmd.ExecuteNonQuery()
                cmd = New OdbcCommand("Select @@identity as Id from insumo", co)
                nInsumo = cmd.ExecuteScalar()
                cmd = New OdbcCommand("INSERT INTO gestiona (CeduUsu,Insu,accion, Lugar , Localizacion) VALUES (" & c & "," & nInsumo & ", 'Alta','" & IngInsumo.lugar.SelectedItem & "','" & sector & "')", co)
                cmd.ExecuteNonQuery()

                MessageBox.Show("Registro guardado" & vbNewLine & "El numero del insumo recien cargado es: " & nInsumo, "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
                veces -= 1
            Loop
            If (idIns > 0) Then
                cmd = New OdbcCommand("select CantPedido from insumo where Id= " & idIns, co)
                Dim nump As String = cmd.ExecuteScalar().ToString

                nump = CInt(nump) - repe
                If (nump > 0) Then
                    cmd = New OdbcCommand("UPDATE insumo set CantPedido=" & nump & " where Id = " & idIns, co)
                    cmd.ExecuteNonQuery()
                Else
                    cmd = New OdbcCommand("UPDATE insumo set CantPedido = 0 where Id = " & idIns, co)
                    cmd.ExecuteNonQuery()
                    cmd = New OdbcCommand("UPDATE insumo set ultiCompra = Now() where Id = " & idIns, co)
                    cmd.ExecuteNonQuery()
                    cmd = New OdbcCommand("select CantComprado from insumo where Id= " & idIns, co)
                    Dim numc As String = cmd.ExecuteScalar().ToString
                    If (numc = "") Then
                        numc = 0
                    End If
                    numc = CInt(numc) + repe
                    cmd = New OdbcCommand("UPDATE insumo set CantComprado=" & numc & " where Id = " & idIns, co)
                    cmd.ExecuteNonQuery()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTicket()
        'este Se utiliza en Ticket.vb
        Dim codi As String
        codi = textoAleatorio()
        Call conexion()
        Try
            cmd = New OdbcCommand("Insert into ticket(idInsumo,codigo,NomUsu,ApeUsu,Email ,Asunto,Prioridad,Mensaje) values(" & Ticket.txbNumero.Text & ",'" & codi & "','" & Ticket.txbNombre.Text & "',' " & Ticket.txbApellido.Text & "','" & Ticket.txbEmail.Text & "','" & Ticket.Asunto.SelectedItem & "','" & Ticket.Prioridad.SelectedItem & "','" & Ticket.txbMensaje.Text & "')", co)
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("Select numero from ticket where codigo = '" & codi & "'", co)
            Dim num As Integer = cmd.ExecuteScalar()
            cmd = New OdbcCommand("Insert into registra(FechaInicio,numTicket)  Values(now()," & num & ")", co)
            cmd.ExecuteNonQuery()
            AgregarTipoYEditarContrase.tbxTip.Text = codi
            AgregarTipoYEditarContrase.tbxTip.ReadOnly = True
            AgregarTipoYEditarContrase.Visible = True
            Ticket.txbNombre.Text = ""
            Ticket.txbApellido.Text = ""
            Ticket.txbEmail.Text = ""
            Ticket.txbMensaje.Text = ""
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub cerraTicket(c As String)
        Call conexion()
        Dim sol As String
        If (CerrarTicket.solucion.SelectedItem = "Algunos puntos si") Then
            sol = "Mm"
        Else
            sol = CerrarTicket.solucion.SelectedItem
        End If
        Try
            cmd = New OdbcCommand("UPDATE ticket Set Solucion ='" & sol & "' , Detalle = '" & CerrarTicket.det.Text & "' where numero = " & CerrarTicket.Num.Text, co)
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("UPDATE registra Set FechaCierre =now() where numTicket = " & CerrarTicket.Num.Text, co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Ticket cerrado", "Cerrado", MessageBoxButtons.OK, MessageBoxIcon.Information)
            CerrarTicket.Close()
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub altaTipo()
        Call conexion()
        cmd = New OdbcCommand("Insert Into tipoinsumo(tipo) values('" & AgregarTipoYEditarContrase.tbxTip.Text & "')", co)
        cmd.ExecuteNonQuery()
    End Sub

    '  Listar

    Sub listarTickets(i As Integer, s As String)

        Dim estado As String = ""
        Dim lug As String
        Dim num As Integer = 0
        Dim orden As String = " Order by Fecha"
        If (s = "") Then
            lug = ""
        Else
            lug = "and Sector = '" & s & "'"
        End If
        Call conexion()
        If (i = 1) Then

            ada = New OdbcDataAdapter("select * FROM listado_tickets where Cierre Is NULL " & lug & orden, co)
        ElseIf (i = 2) Then
            ada = New OdbcDataAdapter("select * FROM listado_tickets where Cierre Is NOT NULL " & lug & orden, co)
        Else
            ada = New OdbcDataAdapter("select * FROM listado_tickets" & orden, co)
        End If
        ds = New DataSet()
        ada.Fill(ds)
        ListadoT.Tickets.DataSource = ds.Tables(0)
        ListadoT.Tickets.Columns("Num").Width = 40
        ListadoT.Tickets.Columns("Cod").Width = 44
        ListadoT.Tickets.Columns("Fecha").Width = 100
        ListadoT.Tickets.Columns("Cierre").Width = 100
        ListadoT.Tickets.Columns("Prioridad").Width = 60
        ListadoT.Tickets.Columns("Asunto").Width = 60
        ListadoT.Tickets.Columns("Sector").Width = 60
        ListadoT.Tickets.Columns("Mensaje").Width = 220
    End Sub
    Sub bustick(num As Integer, estado As Integer)
        Dim selec As String = ""
        Dim esta As String
        If (estado = 1) Then
            esta = "  and Cierre is NULL"
        ElseIf (estado = 2) Then
            esta = "  and Cierre is NOT NULL"
        Else
            esta = ""
        End If
        Call conexion()
        If (num = 1) Then
            selec = "WHERE Cod LIKE '%" & ListadoT.buscar.Text & "%' " & esta
        ElseIf (num = 2) Then
            Dim f As String = ListadoT.buscar.Text
            selec = "WHERE Fecha LIKE '%" & f & "%' and Cierre is NULL"
        ElseIf (num = 3) Then
            Dim f As String = ListadoT.buscar.Text
            selec = "WHERE Fecha LIKE '%" & f & "%' and Cierre is NOT NULL"
        ElseIf (num = 4) Then
            selec = "WHERE Sector LIKE '%" & ListadoT.lugar.SelectedItem & "%'" & esta
        End If
        ada = New OdbcDataAdapter("select * from listado_tickets " & selec, co)
        ds = New DataSet()
        ada.Fill(ds)
        ListadoT.Tickets.DataSource = ds.Tables(0)
        ListadoT.Tickets.Columns("Num").Width = 40
        ListadoT.Tickets.Columns("Cod").Width = 44
        ListadoT.Tickets.Columns("Fecha").Width = 90
        ListadoT.Tickets.Columns("Cierre").Width = 90
        ListadoT.Tickets.Columns("Prioridad").Width = 60
        ListadoT.Tickets.Columns("Asunto").Width = 60
        ListadoT.Tickets.Columns("Sector").Width = 60
        ListadoT.Tickets.Columns("Mensaje").Width = 220
    End Sub
    Sub listarInsumos(num As Integer)
        Dim selec As String = ""
        Call conexion()
        If (num = 0) Then
            selec = ""
        Else
            selec = "where tipoinsumo.id = " & num
        End If
        ada = New OdbcDataAdapter("Select insumo.Id As Num, Nombre As NOMBRE, Lugar As LUGAR, tipoinsumo.tipo As TIPO,insumo.Estado as ESTADO,insumo.CompODon as Obtenido FROM insumo inner join tipoinsumo On tipoinsumo.Id = insumo.Tipo " & selec, co)
        ds = New DataSet()
        ada.Fill(ds)
        Insumos.Insumo.DataSource = ds.Tables(0)
        Insumos.Insumo.Columns("Num").Width = 30
        Insumos.Insumo.Columns("NOMBRE").Width = 100
        Insumos.Insumo.Columns("TIPO").Width = 70
        Insumos.Insumo.Columns("LUGAR").Width = 60
        Insumos.Insumo.Columns("ESTADO").Width = 80
        Insumos.Insumo.Columns("Obtenido").Width = 60

    End Sub
    Sub rellenarCompra(selec As Integer)
        ' Inicio,finalizacion,cantidad,insumo,idInsumo
        Dim condicion As String
        If (selec = 1) Then
            condicion = "Where CantPedido > 0"
        ElseIf (selec = 2) Then
            condicion = "Where Comprado > 0"
        Else
            condicion = ""
        End If
        Call conexion()
        ada = New OdbcDataAdapter("Select Fecha,Insumo,Nombre,CantPedido,Comprado from compras " & condicion, co)
        ds = New DataSet()
        ada.Fill(ds)
        Compras.compra.DataSource = ds.Tables(0)
        Compras.compra.Columns("Fecha").Width = 100
        Compras.compra.Columns("Insumo").Width = 45
        Compras.compra.Columns("Nombre").Width = 150
        Compras.compra.Columns("CantPedido").Width = 70
        Compras.compra.Columns("Comprado").Width = 60
    End Sub
    Sub buscarInsu()
        Call conexion()
        If (ExisteI() = False) Then
            MessageBox.Show("Error :no se encontro insumo con el numero indicado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            Try
                cmd = New OdbcCommand("Select Lugar from insumo where Id = " & Ticket.txbNumero.Text, co)
                Ticket.lblLugar.Text = cmd.ExecuteScalar()
                Ticket.lblLugar.Visible = True
                cmd = New OdbcCommand("Select Localizacion from insumo where Id =" & Ticket.txbNumero.Text, co)
                Ticket.lblLoca.Text = cmd.ExecuteScalar().ToString
                Ticket.lblLoca.Visible = True
                cmd = New OdbcCommand("Select tipoinsumo.tipo from insumo inner join tipoinsumo on tipoinsumo.id=insumo.Tipo where insumo.Id = " & Ticket.txbNumero.Text, co)
                Ticket.lblTipo.Text = cmd.ExecuteScalar()
                Ticket.lblTipo.Visible = True

            Catch ex As Exception
                MessageBox.Show("Error" & ex.Message)
            End Try
        End If
    End Sub
    Sub busInsuNombre(num As Integer)
        Dim selec As String = ""
        Call conexion()
        If (num = 0) Then
            selec = ""
        Else
            selec = "and tipoinsumo.id = " & num
        End If
        ada = New OdbcDataAdapter("Select insumo.Id AS Num,Nombre AS NOMBRE,Lugar AS LUGAR, tipoinsumo.tipo as TIPO FROM insumo inner join tipoinsumo on tipoinsumo.Id = insumo.Tipo WHERE Nombre LIKE '%" & Insumos.nom.Text & "%' " & selec, co)
        ds = New DataSet()
        ada.Fill(ds)
        Insumos.Insumo.DataSource = ds.Tables(0)
        Insumos.Insumo.Columns("Num").Width = 30
        Insumos.Insumo.Columns("NOMBRE").Width = 100
        Insumos.Insumo.Columns("TIPO").Width = 80
        Insumos.Insumo.Columns("LUGAR").Width = 80
    End Sub


    '  Rellenar campos

    Sub datosIns()
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("SELECT Nombre FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            editarInsumo.Nombre.Text = cmd.ExecuteScalar()

            cmd = New OdbcCommand("SELECT Categoria FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            editarInsumo.Cat.SelectedItem = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Estado FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            editarInsumo.Estado.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Lugar FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            editarInsumo.lugar.SelectedItem = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Localizacion FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            Dim l As String = cmd.ExecuteScalar().ToString
            If (l = "") Then
                editarInsumo.localizado.Text = ""
            Else
                editarInsumo.localizado.Text = cmd.ExecuteScalar()
            End If
            cmd = New OdbcCommand("SELECT Soporte FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            editarInsumo.soporte.SelectedItem = cmd.ExecuteScalar()

            cmd = New OdbcCommand("SELECT CantPedido FROM insumo Where Id=" & editarInsumo.numero.Text, co)
            Dim c As String = cmd.ExecuteScalar().ToString
            If (c = "") Then
                editarInsumo.Cantidad.Text = ""
                editarInsumo.compra.SelectedItem = "no"
            Else
                editarInsumo.Cantidad.Text = cmd.ExecuteScalar()
                editarInsumo.compra.SelectedItem = "si"

            End If
            cmd = New OdbcCommand("Select disponible from insumo where Id =" & editarInsumo.numero.Text, co)
            Dim disp As String = cmd.ExecuteScalar()
            editarInsumo.dispo = disp
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try


    End Sub
    Sub datosUsu()
        'este Se utiliza en EdiUsu.vb
        Call conexion()
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.NuevoNombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Snombre FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim n As String = cmd.ExecuteScalar().ToString
        If (n = "") Then
            EdiUsu.Nombre2.Text = " "
        Else
            EdiUsu.Nombre2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Papellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Apellido.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Sapellido FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim ap As String = cmd.ExecuteScalar().ToString
        If (ap = "") Then
            EdiUsu.Apellido2.Text = " "
        Else
            EdiUsu.Apellido2.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Tipo FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.Tipo.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Lugar FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        Dim l As String = cmd.ExecuteScalar().ToString
        If (l = "") Then
            EdiUsu.Lugar.SelectedItem = ""
        Else
            EdiUsu.Lugar.SelectedItem = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("SELECT Email FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.CorreoNuevo.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Contrasenia FROM usuario Where Cedula=" & UsuV.Cedula.Text, co)
        EdiUsu.ContraNueva.Text = cmd.ExecuteScalar()

    End Sub
    Sub datosCerrarTicket()
        Call conexion()
        cmd = New OdbcCommand("SELECT numero FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
        If (cmd.ExecuteScalar() = 0 Or cmd.ExecuteScalar().ToString = "") Then
            MessageBox.Show("Error: ticket no encontrado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            cmd = New OdbcCommand("SELECT numero FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Num.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT codigo FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Cod.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Asunto FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Asu.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Email FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Em.Text = cmd.ExecuteScalar()

            Dim nomb As String
            cmd = New OdbcCommand("SELECT NomUsu FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            nomb = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT ApeUsu FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Nom.Text = nomb & " " & cmd.ExecuteScalar()

            cmd = New OdbcCommand("SELECT insumo.Lugar FROM ticket inner join insumo on Id= idInsumo Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Sec.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Prioridad FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Prio.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("SELECT Mensaje FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            CerrarTicket.Men.Text = cmd.ExecuteScalar()

            cmd = New OdbcCommand("SELECT Solucion FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            Dim s As String = cmd.ExecuteScalar().ToString
            If (s = "Mm") Then
                CerrarTicket.solucion.SelectedItem = "Algunos puntos si"
            ElseIf (s = "") Then
            Else
                CerrarTicket.solucion.SelectedItem = s
            End If
            cmd = New OdbcCommand("SELECT Detalle FROM ticket Where numero=" & CerrarTicket.buscar.Text, co)
            Dim d As String = cmd.ExecuteScalar().ToString
            If (d = "") Then
            Else
                Dim num As Integer = CerrarTicket.buscar.Text
                cmd = New OdbcCommand("select cantDias from calculoTickets where numero=" & num, co)
                Dim cuenta As String = cmd.ExecuteScalar()
                CerrarTicket.cuenta.Text = cuenta & " Dias en cerrarce"
                CerrarTicket.det.Text = d
            End If
        End If

    End Sub

    Sub rellenarAgregarInsumo(num As Integer)
        Call conexion()
        rellenarTipoIng()
        Dim accion As String = " from insumo where Id =" & num
        cmd = New OdbcCommand("Select  Nombre" & accion, co)
        IngInsumo.nombre.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("Select  Categoria" & accion, co)
        IngInsumo.Categoria.SelectedItem = cmd.ExecuteScalar()

        cmd = New OdbcCommand("Select  tipoinsumo.tipo from tipoinsumo inner join insumo on insumo.Tipo= tipoinsumo.tipo where insumo.Id =" & num, co)
        Dim t As String = cmd.ExecuteScalar()

        IngInsumo.Tipo.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("Select  Lugar" & accion, co)
        IngInsumo.lugar.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("Select  Localizacion" & accion, co)
        Dim l As String = cmd.ExecuteNonQuery().ToString
        If (l = "") Then
            IngInsumo.localizado.Text = ""
        Else
            IngInsumo.localizado.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("Select  Estado" & accion, co)
        IngInsumo.Estado.Text = cmd.ExecuteScalar()
        cmd = New OdbcCommand("Select  CompODon" & accion, co)
        IngInsumo.CompDon.SelectedItem = cmd.ExecuteScalar()
        cmd = New OdbcCommand("Select  Donador" & accion, co)
        Dim d As String = cmd.ExecuteNonQuery().ToString
        If (d = "") Then
            IngInsumo.donador.Text = ""
        Else
            IngInsumo.donador.Text = cmd.ExecuteScalar()
        End If
        cmd = New OdbcCommand("Select  Soporte" & accion, co)
        IngInsumo.soporte.SelectedItem = cmd.ExecuteScalar()

    End Sub
    'Se rellena el informe del ticket
    Sub InformeI(num As String)
        Call conexion()
        cmd = New OdbcCommand("Select NomUsu FROM ticket WHERE numero = '" & num & "' ", co)
        If (cmd.ExecuteScalar() = "") Then
            MessageBox.Show("Error: ticket no encontrado", "Busqueda", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            cmd = New OdbcCommand("Select numero FROM ticket WHERE numero = '" & num & "'", co)
            InformeInvitado.num.Text = cmd.ExecuteScalar()
            cmd = New OdbcCommand("Select Solucion FROM ticket WHERE numero = '" & num & "' ", co)
            Dim so As String = cmd.ExecuteScalar().ToString
            If (so = "") Then
                InformeInvitado.s.Text = "Aún no se soluciono"
                InformeInvitado.det.Text = ""
            ElseIf (so = "mm") Then
                InformeInvitado.s.Text = "Algunos puntos si"
            Else
                InformeInvitado.s.Text = cmd.ExecuteScalar()
            End If
            cmd = New OdbcCommand("Select Detalle FROM ticket WHERE numero = '" & num & "' ", co)
            InformeInvitado.det.Text = cmd.ExecuteScalar().ToString
        End If
    End Sub
    Sub datoInforme(tbuscar As String, selec As Integer)
        Call conexion()
        If (selec = 1) Then
            ada = New OdbcDataAdapter("select codigo as Codigo,NomUsu as Nombre,ApeUsu as Apellido,numero as Num from ticket where codigo LIKE '%" & tbuscar & "%'", co)
        Else
            ada = New OdbcDataAdapter("select codigo as Codigo,NomUsu as Nombre,ApeUsu as Apellido,numero as Num from ticket where NomUsu LIKE '%" & tbuscar & "%' or ApeUsu LIKE '%" & tbuscar & "%'", co)
        End If
        ds = New DataSet()
        ada.Fill(ds)
        InformeInvitado.datos.DataSource = ds.Tables(0)
        InformeInvitado.datos.Columns("Num").Width = 30
        InformeInvitado.datos.Columns("Num").Visible = False
        InformeInvitado.datos.Columns("Codigo").Width = 50
        InformeInvitado.datos.Columns("Nombre").Width = 80
        InformeInvitado.datos.Columns("Apellido").Width = 80

    End Sub
    'combos
    Sub rellenarTipoIng()
        Call conexion()
        ada = New OdbcDataAdapter("Select id,tipo from tipoinsumo", co)
        ds = New DataSet()
        ada.Fill(ds)
        IngInsumo.Tipo.DataSource = ds.Tables(0)
        IngInsumo.Tipo.ValueMember = "id"
        IngInsumo.Tipo.DisplayMember = "tipo"
    End Sub
    Sub rellenarTipoList()
        Call conexion()
        ada = New OdbcDataAdapter("Select id,tipo from tipoinsumo", co)
        ds = New DataSet()
        ada.Fill(ds)
        Insumos.tip.DataSource = ds.Tables(0)
        Insumos.tip.ValueMember = "id"
        Insumos.tip.DisplayMember = "tipo"
    End Sub
    'datos concretos
    Function BuscarUsu()
        'este Se utiliza en UsuV.vb
        Call conexion()
        Dim n1, n2, t, nom, solu As String
        solu = "FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'"
        cmd = New OdbcCommand("SELECT Pnombre " & solu, co)
        n1 = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Papellido " & solu, co)
        n2 = cmd.ExecuteScalar()
        cmd = New OdbcCommand("SELECT Tipo " & solu, co)
        t = cmd.ExecuteScalar()
        nom = n1 & " " & n2 & " - " & t
        Return nom
    End Function
    Function ExisteI()
        Dim si As String = "False"
        Call conexion()
        cmd = New OdbcCommand("Select Lugar from insumo where Id = " & Ticket.txbNumero.Text, co)
        If (Len(cmd.ExecuteScalar) = 0) Then
            si = "False"
        Else
            si = "True"
        End If
        Return si
    End Function



    '  Actualizar Datos

    Sub editarPersona()
        'este Se utiliza en EdiUsu.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("UPDATE usuario Set Pnombre = '" & EdiUsu.NuevoNombre.Text & "', Snombre ='" & EdiUsu.Nombre2.Text & "' , Papellido = '" & EdiUsu.Apellido.Text & "' , Sapellido = '" & EdiUsu.Apellido2.Text & "' , Email = '" & EdiUsu.CorreoNuevo.Text & "', Contrasenia = '" & EdiUsu.ContraNueva.Text & "' , Tipo = '" & EdiUsu.Tipo.SelectedItem & "', Lugar = '" & EdiUsu.Lugar.SelectedItem & "' WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Registro Actualizado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub editInsumo(c As String)
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        Try
            If (editarInsumo.compra.SelectedItem = "si") Then

                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6T" Or IngInsumo.lugar.SelectedItem = "Sala") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "', CantPedido='" & editarInsumo.Cantidad.Text & "' where Id = " & editarInsumo.numero.Text, co)
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localizacion ='" & editarInsumo.localizado.Text & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "', CantPedido='" & editarInsumo.Cantidad.Text & "' where Id = " & editarInsumo.numero.Text, co)
                End If
            Else
                If (IngInsumo.lugar.SelectedItem = "Taller" Or IngInsumo.lugar.SelectedItem = "6T" Or IngInsumo.lugar.SelectedItem = "Sala") Then
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "' where Id = " & editarInsumo.numero.Text, co)
                Else
                    cmd = New OdbcCommand("UPDATE insumo Set Nombre='" & editarInsumo.Nombre.Text & "', Categoria ='" & editarInsumo.Cat.SelectedItem & "', Lugar='" & editarInsumo.lugar.SelectedItem & "', Localizacion ='" & editarInsumo.localizado.Text & "', Estado='" & editarInsumo.Estado.Text & "', Soporte='" & editarInsumo.soporte.SelectedItem & "' where Id = " & editarInsumo.numero.Text, co)
                End If
            End If
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("INSERT INTO gestiona (CeduUsu,Insu,accion, Lugar , Localizado) VALUES (" & c & "," & editarInsumo.numero.Text & ", 'Editado','" & editarInsumo.lugar.SelectedItem & "','" & editarInsumo.localizado.Text & "')", co)
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("Select @@identity as id from gestiona", co)
            Dim n As String = cmd.ExecuteScalar()
            cmd = New OdbcCommand("INSERT INTO fechasInsumo (Fecha, idG) VALUES(now()," & n & ") ", co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Registro Actualizado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub
    Sub editarContraseña(c As String)
        Call conexion()
        Try
            cmd = New OdbcCommand("UPDATE usuario Set Contrasenia = '" & AgregarTipoYEditarContrase.tbxTip.Text & "' WHERE Cedula = '" & c & "'", co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Registro guardado", "ALTA", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Error" & ex.Message)
        End Try
    End Sub


    '  eliminar

    Sub EliminarUsu()
        'este Se utiliza en UsuV.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("DELETE FROM usuario WHERE Cedula= '" & UsuV.Cedula.Text & "' ", co)
            cmd.ExecuteNonQuery()
            MessageBox.Show("Usuario Eliminado", "BAJA", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
        End Try
    End Sub
    Sub eliminarIns(c As String)
        'este Se utiliza en editarInsumo.vb
        Call conexion()
        Try
            cmd = New OdbcCommand("INSERT INTO gestiona (CeduUsu,Insu,accion) VALUES (" & c & "," & editarInsumo.numero.Text & ", 'Dado de Baja')", co)
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("Select @@identity as id from gestiona", co)
            Dim n As String = cmd.ExecuteScalar()
            MsgBox("hola")
            cmd = New OdbcCommand("INSERT INTO fechasInsumo (Fecha, idG) VALUES(now()," & n & ") ", co)
            cmd.ExecuteNonQuery()
            cmd = New OdbcCommand("Update insumo set disponible = 'n'  WHERE Id= '" & editarInsumo.numero.Text & "' ", co)
            cmd.ExecuteScalar()
            MessageBox.Show("Dado de Baja", "BAJA", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
        End Try
    End Sub


    '  Otros

    Sub altasHorarios()
        Call conexion()
        Dim mate, profe As String
        mate = AgregarHorarios.ComboMateria.SelectedIndex + 1
        profe = AgregarHorarios.ComboProfesor.Text
        cmd = New OdbcCommand("select id from profeda inner join materia on materia.IdMateria = ProfeDa.Materia inner join profesor on profesor.IdProfesor = ProfeDa.Profesor where ProfeDa.Materia = " & mate & " and ProfeDa.Profesor= " & profe, co)
        Dim id As String = cmd.ExecuteScalar
        cmd = New OdbcCommand("Insert into clasetiene(hora,dia,clase,MateriaProfe) values(" & AgregarHorarios.ComboHora.SelectedIndex + 1 & ",'" & AgregarHorarios.ComboDia.SelectedItem & "'," & AgregarHorarios.comboClase.SelectedIndex + 1 & "," & id & ")", co)
        cmd.ExecuteNonQuery()
        MsgBox("Registro guardado")
    End Sub

    Sub AltaClase()
        Call conexion()
        cmd = New OdbcCommand("Insert into clase(nombre) values('" & AgregarTipoYEditarContrase.tbxTip.Text & "')", co)
        cmd.ExecuteNonQuery()
        MsgBox("Registrado con exito")
        rellenarClase("1")
    End Sub
    Sub AltaProfe(mate As String)
        Call conexion()
        cmd = New OdbcCommand("Insert into profesor(IdProfesor,Nombre,Apellido) values(" & Hora.TextBox4.Text & "," & nombreYapellido(Hora.TextBox3.Text) & ")", co)
        cmd.ExecuteNonQuery()
        cmd = New OdbcCommand("Insert into ProfeDa(Materia,Profesor) values(" & mate & "," & Hora.TextBox4.Text & ")", co)
        cmd.ExecuteNonQuery()
        MsgBox("Registrado con exito")
    End Sub
    Function nombreYapellido(text As String)
        Dim pos As Integer
        Dim car, Nom, Ape, solu As String
        pos = 1
        While (pos < Len(text))
            car = Mid(text, pos, 1)
            If (car = " ") Then
                Nom = Mid(text, 1, pos - 1)
                Ape = Mid(text, pos + 1)
            End If
            pos += 1
        End While
        solu = "'" & Nom & "','" & Ape & "'"
        Return solu
    End Function
    Sub AltaMateria()
        Call conexion()
        cmd = New OdbcCommand("Insert into materia(NomMateria) values('" & AgregarTipoYEditarContrase.tbxTip.Text & "')", co)
        cmd.ExecuteNonQuery()
        MsgBox("Registrado con exito")
        rellenarMateria()
    End Sub
    Sub AltaHora()
        Dim H As String
        H = Hora.TextBox1.Text & ":" & Hora.TextBox2.Text & ":00"
        Call conexion()
        cmd = New OdbcCommand("insert into Hora(hora) values('" & H & "')", co)
        cmd.ExecuteNonQuery()
        MsgBox("Registrado con exito")
        rellenarHora()
    End Sub

    Sub rellenarHora()
        Call conexion()
        ada = New OdbcDataAdapter("Select id,hora from Hora", co)
        ds = New DataSet()
        ada.Fill(ds)
        AgregarHorarios.ComboHora.DataSource = ds.Tables(0)
        AgregarHorarios.ComboHora.ValueMember = "id"
        AgregarHorarios.ComboHora.DisplayMember = "hora"
        AgregarHorarios.ComboHora.Text = "Seleccionar"
    End Sub
    Sub rellenarClase(ventana As String)
        Call conexion()
        Dim ven As Object
        If (ventana = "1") Then
            ven = AgregarHorarios.comboClase
        Else
            ven = MenuHorarios.ComboClase
        End If
        ada = New OdbcDataAdapter("Select id,nombre from clase", co)
        ds = New DataSet()
        ada.Fill(ds)
        ven.DataSource = ds.Tables(0)
        ven.ValueMember = "id"
        ven.DisplayMember = "nombre"
        ven.Text = "Seleccionar"
    End Sub
    Sub rellenarMateria()
        Call conexion()
        ada = New OdbcDataAdapter("Select IdMateria,NomMateria from materia", co)
        ds = New DataSet()
        ada.Fill(ds)
        AgregarHorarios.ComboMateria.DataSource = ds.Tables(0)
        AgregarHorarios.ComboMateria.ValueMember = "IdMateria"
        AgregarHorarios.ComboMateria.DisplayMember = "NomMateria"
        AgregarHorarios.ComboMateria.Text = "Seleccionar"
    End Sub
    Sub rellenarProfesor(id As Integer)
        Call conexion()
        ada = New OdbcDataAdapter("Select IdProfesor from profesor inner join ProfeDa on ProfeDa.Profesor=profesor.IdProfesor where ProfeDa.Materia=" & id, co)
        ds = New DataSet()
        ada.Fill(ds)
        AgregarHorarios.Button1.Visible = True
        AgregarHorarios.Label2.Visible = True
        AgregarHorarios.ComboProfesor.Visible = True
        AgregarHorarios.ComboProfesor.DataSource = ds.Tables(0)
        AgregarHorarios.ComboProfesor.DisplayMember = "IdProfesor"
        AgregarHorarios.ComboDia.Text = "Seleccionar"
    End Sub

    Sub ListarGrid(dia As String, clase As String)
        Call conexion()
        Dim condicion As String
        If (dia = "" And clase = "") Then
        ElseIf (Len(dia) > 2 And clase = "") Then
            condicion = " where Dia='" & dia & "'"
        ElseIf (len(clase) > 2 And dia = "") Then
            condicion = " where Clase='" & clase & "'"
        Else
            condicion = " where Dia='" & dia & "' and Clase='" & clase & "'"
        End If
        ada = New OdbcDataAdapter("select * from Horarios " & condicion, co)
        ds = New DataSet()
        ada.Fill(ds)
        MenuHorarios.DataHorarios.DataSource = ds.Tables(0)
        MenuHorarios.DataHorarios.Columns("Nombre").Width = 80
        MenuHorarios.DataHorarios.Columns("Apellido").Width = 80
        MenuHorarios.DataHorarios.Columns("Materia").Width = 90
        MenuHorarios.DataHorarios.Columns("Clase").Width = 80
        MenuHorarios.DataHorarios.Columns("Hora").Width = 60
        MenuHorarios.DataHorarios.Columns("Dia").Width = 70
    End Sub





    'se verifica la cedula, que no exista en la BD y que sea valida
    Function cedula(C As String)
        'este Se utiliza en IngUsuario.vb
        'Se comprueba si existe la cedula en la BD
        Call conexion()
        Dim n1, n2 As String
        cmd = New OdbcCommand("SELECT Pnombre FROM usuario  WHERE Cedula = '" & C & "'", co)
        n1 = cmd.ExecuteScalar()
        ' si no existe no rellenara n2
        If (n1 = "") Then
            n2 = ""
        Else
            n2 = "Existe"
        End If

        'Se verifica si es Uruguaya
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C)
        pos = 1
        arr = 0
        multi = 0
        suma = 0
        If (cantidad = 8) Then
            While (pos < 8)
                car = Mid(C, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While

            If (Mid(suma, 3, 1) = "") Then
                resto = 10 - Mid(suma, 2, 1)
            Else
                resto = 10 - Mid(suma, 3, 1)
            End If
            If resto = 10 Then
                resto = 0
            End If

            'si no existe(n2 vacio) y es valida, retornara true indicando que se puede guardar
            If (resto = Mid(C, 8, 1) And n2 = "") Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
    'se verifica la cedula, que no exista en la BD y que sea valida
    Function vacio(text As String)
        If (text = "") Then
            Return False
        Else
            Return True
        End If
    End Function
    Function email(text As String)
        Dim cant As Integer = Len(text)
        Dim pos As Integer = 1
        Dim caracter As String
        Dim arroba, punto As Integer
        arroba = 0
        punto = 0
        While (pos <= cant)
            caracter = Mid(text, pos, 1)
            If (caracter = "@") Then
                arroba = 1
            ElseIf (caracter = ".") Then
                punto = 1
            End If
            pos += 1
        End While
        If (arroba = 1 And punto = 1) Then
            Return True
        Else
            Return False
        End If
    End Function
    'En este se genera un texto aleatorio de 5 digitos de numeros y letras para los tickets
    Function textoAleatorio()
        'este Se utiliza en Modulo.altaTicket()
        Call conexion()
        Dim obj As New Random()
        Dim posibles As String = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Dim longitud As Integer = posibles.Length
        Dim letra As Char
        Dim longitudnuevacadena As Integer = 5
        Dim nuevacadena As String = Nothing
        Dim numero As Integer = 0
        Dim Existe As Integer = 1
        While Existe = 1
            numero = 0
            'While numero = 0
            For i As Integer = 0 To longitudnuevacadena - 1
                letra = posibles(obj.[Next](longitud))
                nuevacadena += letra.ToString()
            Next
            'If (Val(letra) * 1 >= 0 And Val(letra) <= 9) Then
            'numero = numero + 1
            'End If
            'End While

            'para no repetir codigos, se busca el codigo en BD y si ya esta registrado se realiza otro codigo de nuevo
            cmd = New OdbcCommand("SELECT numero FROM ticket  WHERE codigo = '" & nuevacadena & "'", co)
            Dim num As String = cmd.ExecuteScalar()
            If (num = "") Then
                Existe = 0
            Else
                Existe = 1
            End If
        End While
        Return nuevacadena
    End Function
    'se comprueba que exista el usuario con la cedula ingresada en UsuV.vb
    Function Usu(Cedula)
        Call conexion()
        cmd = New OdbcCommand("SELECT tipo FROM usuario  WHERE Cedula = '" & UsuV.Cedula.Text & "'", co)
        Return cmd.ExecuteNonQuery()
    End Function
End Class
