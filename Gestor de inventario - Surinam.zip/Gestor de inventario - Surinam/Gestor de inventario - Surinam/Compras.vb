﻿Public Class Compras
    Dim clas = New Clase()
    Public cedu, tipo As String


    Private Sub Compras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbxEstado.SelectedItem = "a comprar"
        clas.rellenarCompra(1)
        If (tipo = "repor") Then
            compra.Enabled = False
        ElseIf (tipo = "Tecnico") Then
            cbxEstado.Visible = False
        End If
    End Sub



    Private Sub cbxEstado_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles cbxEstado.SelectionChangeCommitted
        If (cbxEstado.SelectedItem = "a comprar") Then
            clas.rellenarCompra(1)
        ElseIf (cbxEstado.SelectedItem = "compras realizadas") Then
            clas.rellenarCompra(2)
        Else
            clas.rellenarCompra(3)
        End If
    End Sub

    Private Sub compra_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles compra.CellMouseClick

        Dim num As Integer = Me.compra.CurrentRow.Cells("Insumo").Value
        IngInsumo.Visible = True
        IngInsumo.cedu = cedu
        IngInsumo.compra.SelectedItem = "No"
        IngInsumo.compra.Visible = False
        IngInsumo.com.Visible = False
        IngInsumo.Label7.Visible = False
        IngInsumo.CantidadComprar.Visible = False
        clas.rellenarAgregarInsumo(num)
        IngInsumo.numI = num
    End Sub
End Class