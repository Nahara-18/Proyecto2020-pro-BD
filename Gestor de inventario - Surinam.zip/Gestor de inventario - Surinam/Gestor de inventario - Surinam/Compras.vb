﻿Public Class Compras
    Dim clas = New Clase()
    Public cedu, tipo As String
    Private Sub Compras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.rellenarCompra()
        If (tipo = "repor") Then
            compra.Enabled = False
        End If
    End Sub

    Private Sub compra_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles compra.CellMouseClick
        Dim num As Integer = Me.compra.CurrentRow.Cells("Num de Insumo").Value
        IngInsumo.Visible = True
        IngInsumo.cedu = cedu
        IngInsumo.compra.SelectedItem = "No"
        IngInsumo.compra.Visible = False
        IngInsumo.com.Visible = False
        IngInsumo.Label7.Visible = False
        IngInsumo.CantidadComprar.Visible = False
        clas.rellenarAgregarInsumo(num)
        IngInsumo.numI = num
    End Sub
End Class