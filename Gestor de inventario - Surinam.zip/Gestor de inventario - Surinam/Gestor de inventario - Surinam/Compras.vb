﻿Public Class Compras
    Dim clas = New Clase()
    Public cedu As String
    Private Sub Compras_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        clas.rellenarCompra()

    End Sub

    Private Sub compra_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles compra.CellMouseClick
        Dim num As Integer = Me.compra.CurrentRow.Cells("Num de Insumo").Value
        IngInsumo.Visible = True
        IngInsumo.cedu = cedu
        IngInsumo.compra.SelectedItem = "No"
        IngInsumo.compra.Visible = False
        IngInsumo.com.Visible = False
        IngInsumo.Label7.Visible = True
        IngInsumo.CantidadComprar.Visible = True
        IngInsumo.Label7.Text = "Cantidad a agregar"
        clas.rellenarAgregarInsumo(num)
        IngInsumo.numI = num

    End Sub
End Class