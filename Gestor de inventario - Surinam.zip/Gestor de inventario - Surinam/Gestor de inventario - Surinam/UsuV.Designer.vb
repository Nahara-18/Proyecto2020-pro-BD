﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UsuV
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Editar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(111, 50)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 16)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Cedula"
        '
        'Cedula
        '
        Me.Cedula.Location = New System.Drawing.Point(184, 50)
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(182, 20)
        Me.Cedula.TabIndex = 12
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(247, 117)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(159, 23)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Eliminar Usuario "
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Editar
        '
        Me.Editar.Location = New System.Drawing.Point(59, 117)
        Me.Editar.Name = "Editar"
        Me.Editar.Size = New System.Drawing.Size(141, 23)
        Me.Editar.TabIndex = 10
        Me.Editar.Text = "Editar Usuario"
        Me.Editar.UseVisualStyleBackColor = True
        '
        'UsuV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 211)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Editar)
        Me.Name = "UsuV"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "UsuV"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents Cedula As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Editar As Button
End Class
