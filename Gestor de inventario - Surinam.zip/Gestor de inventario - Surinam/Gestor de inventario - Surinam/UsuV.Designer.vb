﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class UsuV
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.Eliminar = New System.Windows.Forms.Button()
        Me.Editar = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Nombre = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(124, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 16)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Cedula"
        '
        'Cedula
        '
        Me.Cedula.Location = New System.Drawing.Point(192, 41)
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(95, 20)
        Me.Cedula.TabIndex = 12
        '
        'Eliminar
        '
        Me.Eliminar.Location = New System.Drawing.Point(255, 136)
        Me.Eliminar.Name = "Eliminar"
        Me.Eliminar.Size = New System.Drawing.Size(159, 23)
        Me.Eliminar.TabIndex = 11
        Me.Eliminar.Text = "Eliminar Usuario "
        Me.Eliminar.UseVisualStyleBackColor = True
        Me.Eliminar.Visible = False
        '
        'Editar
        '
        Me.Editar.Location = New System.Drawing.Point(89, 136)
        Me.Editar.Name = "Editar"
        Me.Editar.Size = New System.Drawing.Size(141, 23)
        Me.Editar.TabIndex = 10
        Me.Editar.Text = "Editar Usuario"
        Me.Editar.UseVisualStyleBackColor = True
        Me.Editar.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(304, 41)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(67, 19)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Buscar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Nombre
        '
        Me.Nombre.Location = New System.Drawing.Point(145, 97)
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Size = New System.Drawing.Size(206, 20)
        Me.Nombre.TabIndex = 15
        Me.Nombre.Visible = False
        '
        'UsuV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 186)
        Me.Controls.Add(Me.Nombre)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.Eliminar)
        Me.Controls.Add(Me.Editar)
        Me.Name = "UsuV"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "UsuV"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label4 As Label
    Friend WithEvents Cedula As TextBox
    Friend WithEvents Eliminar As Button
    Friend WithEvents Editar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Nombre As TextBox
End Class
