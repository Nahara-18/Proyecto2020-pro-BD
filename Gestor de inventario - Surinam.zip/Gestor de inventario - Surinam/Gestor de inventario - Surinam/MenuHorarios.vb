﻿Public Class MenuHorarios
    Dim clas = New Clase()
    Private Sub MenuHorarios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim ventana As String = "MenuHorarios"
        ComboDia.Text = "Selecionar"
        clas.rellenarClase("2")
        clas.ListarGrid("", "")
    End Sub

    Private Sub ComboDia_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboDia.SelectionChangeCommitted
        Dim dia, clase As String
        dia = ComboDia.SelectedItem
        If (ComboClase.Text = "Seleccionar") Then
            clase = ""
        Else
            clase = ComboClase.Text
        End If

        clas.ListarGrid(dia, clase)
    End Sub

    Private Sub ComboClase_SelectionChangeCommitted(sender As Object, e As EventArgs) Handles ComboClase.SelectionChangeCommitted
        Dim dia, clase As String
        clase = ComboClase.Text
        If (ComboDia.Text = "Seleccionar") Then
            dia = ""
        Else
            dia = ComboDia.SelectedItem
        End If

        clas.ListarGrid(dia, clase)
    End Sub
End Class