﻿Public Class EdiUsu
    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Modulo.editarPersona()
        MenuAdmin.Visible = True
        Me.Visible = False
        UsuV.Visible = False
        UsuV.Cedula.Text = ""
    End Sub

    Private Sub Tipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Tipo.SelectedIndexChanged
        If Tipo.SelectedItem = "Técnico" Then
            Lugar.Visible = True
        Else
            Lugar.Visible = False
        End If
    End Sub
End Class