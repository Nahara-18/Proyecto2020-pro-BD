﻿Public Class EdiUsu
    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Dim completo As Integer = 0
        'en cada uno de los siguientes "If" se comprobaran los datos, si no estan vacios, si tienen ciertos caracteres,etc
        'si los datos son correctos se sumara en cuenta uno en uno
        'se comprobara en el ultimo if si todos lod datos minimos requeridos fueron ingresados y se registra
        If (Modulo.vacio(NuevoNombre.Text()) = "false") Then
            N1.ForeColor = ForeColor.Red
        Else
            N1.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.vacio(Apellido.Text()) = "false") Then
            A1.ForeColor = ForeColor.Red
        Else
            A1.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.vacio(CorreoNuevo.Text()) = "false") Then
            Corr.ForeColor = ForeColor.Red
        Else
            Corr.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Modulo.vacio(ContraNueva.Text()) = "false") Then
            Cont.ForeColor = ForeColor.Red
        Else
            Cont.ForeColor = ForeColor.Black
            completo += 1
        End If
        If (Tipo.SelectedItem = "") Then
            Tip.ForeColor = ForeColor.Red
        Else
            Tip.ForeColor = ForeColor.Black
            completo += 1
        End If

        If (completo = 5) Then
            Modulo.editarPersona()
        End If

        MenuAdmin.Visible = True
        Me.Visible = False
        UsuV.Visible = False
        UsuV.Cedula.Text = ""
    End Sub

    Private Sub Tipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Tipo.SelectedIndexChanged
        If Tipo.SelectedItem = "Técnico" Then
            Lugar.Visible = True
        Else
            Lugar.Visible = False
        End If
    End Sub

    Private Sub mosCon_CheckedChanged(sender As Object, e As EventArgs) Handles mosCon.CheckedChanged
        If mosCon.Checked = True Then
            ContraNueva.UseSystemPasswordChar = False
        Else
            ContraNueva.UseSystemPasswordChar = True
        End If
    End Sub
End Class