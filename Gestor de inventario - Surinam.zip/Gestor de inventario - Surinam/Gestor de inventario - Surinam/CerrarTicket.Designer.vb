﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CerrarTicket
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.det = New System.Windows.Forms.TextBox()
        Me.solucion = New System.Windows.Forms.ComboBox()
        Me.Num = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Prio = New System.Windows.Forms.Label()
        Me.Asu = New System.Windows.Forms.Label()
        Me.Sec = New System.Windows.Forms.Label()
        Me.Em = New System.Windows.Forms.Label()
        Me.Nom = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Cod = New System.Windows.Forms.Label()
        Me.Men = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.buscar = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'det
        '
        Me.det.Location = New System.Drawing.Point(240, 217)
        Me.det.Multiline = True
        Me.det.Name = "det"
        Me.det.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.det.Size = New System.Drawing.Size(383, 108)
        Me.det.TabIndex = 16
        '
        'solucion
        '
        Me.solucion.FormattingEnabled = True
        Me.solucion.Items.AddRange(New Object() {"Si", "Algunos puntos si", "No"})
        Me.solucion.Location = New System.Drawing.Point(36, 230)
        Me.solucion.Name = "solucion"
        Me.solucion.Size = New System.Drawing.Size(174, 21)
        Me.solucion.TabIndex = 18
        Me.solucion.Text = "¿Se solucionó?"
        '
        'Num
        '
        Me.Num.AutoSize = True
        Me.Num.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Num.Location = New System.Drawing.Point(184, 19)
        Me.Num.Name = "Num"
        Me.Num.Size = New System.Drawing.Size(48, 13)
        Me.Num.TabIndex = 19
        Me.Num.Text = "numero"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(272, 347)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 23)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "Cerrar Ticket"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(382, 201)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Detalles"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(143, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Numero"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 13)
        Me.Label5.TabIndex = 33
        Me.Label5.Text = "Prioridad"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(378, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Asunto"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 123)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(38, 13)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "Sector"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(417, 69)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(47, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Mensaje"
        '
        'Prio
        '
        Me.Prio.AutoSize = True
        Me.Prio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Prio.Location = New System.Drawing.Point(55, 153)
        Me.Prio.Name = "Prio"
        Me.Prio.Size = New System.Drawing.Size(56, 13)
        Me.Prio.TabIndex = 50
        Me.Prio.Text = "prioridad"
        '
        'Asu
        '
        Me.Asu.AutoSize = True
        Me.Asu.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Asu.Location = New System.Drawing.Point(419, 19)
        Me.Asu.Name = "Asu"
        Me.Asu.Size = New System.Drawing.Size(45, 13)
        Me.Asu.TabIndex = 49
        Me.Asu.Text = "asunto"
        '
        'Sec
        '
        Me.Sec.AutoSize = True
        Me.Sec.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Sec.Location = New System.Drawing.Point(54, 123)
        Me.Sec.Name = "Sec"
        Me.Sec.Size = New System.Drawing.Size(42, 13)
        Me.Sec.TabIndex = 48
        Me.Sec.Text = "sector"
        '
        'Em
        '
        Me.Em.AutoSize = True
        Me.Em.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Em.Location = New System.Drawing.Point(10, 64)
        Me.Em.Name = "Em"
        Me.Em.Size = New System.Drawing.Size(37, 13)
        Me.Em.TabIndex = 47
        Me.Em.Text = "Email"
        '
        'Nom
        '
        Me.Nom.AutoSize = True
        Me.Nom.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nom.Location = New System.Drawing.Point(12, 88)
        Me.Nom.Name = "Nom"
        Me.Nom.Size = New System.Drawing.Size(48, 13)
        Me.Nom.TabIndex = 46
        Me.Nom.Text = "nombre"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(269, 19)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(40, 13)
        Me.Label16.TabIndex = 52
        Me.Label16.Text = "Codigo"
        '
        'Cod
        '
        Me.Cod.AutoSize = True
        Me.Cod.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cod.Location = New System.Drawing.Point(306, 19)
        Me.Cod.Name = "Cod"
        Me.Cod.Size = New System.Drawing.Size(45, 13)
        Me.Cod.TabIndex = 51
        Me.Cod.Text = "codigo"
        '
        'Men
        '
        Me.Men.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Men.Location = New System.Drawing.Point(251, 85)
        Me.Men.Multiline = True
        Me.Men.Name = "Men"
        Me.Men.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Men.Size = New System.Drawing.Size(389, 91)
        Me.Men.TabIndex = 53
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(11, 11)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 21)
        Me.Button2.TabIndex = 54
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'buscar
        '
        Me.buscar.Location = New System.Drawing.Point(504, 45)
        Me.buscar.Name = "buscar"
        Me.buscar.Size = New System.Drawing.Size(76, 20)
        Me.buscar.TabIndex = 56
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(586, 43)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(54, 23)
        Me.Button3.TabIndex = 55
        Me.Button3.Text = "Buscar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(274, 331)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 13)
        Me.Label1.TabIndex = 57
        Me.Label1.Text = "Ya se a cerrado"
        Me.Label1.Visible = False
        '
        'CerrarTicket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(652, 382)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.buscar)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Men)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Cod)
        Me.Controls.Add(Me.Prio)
        Me.Controls.Add(Me.Asu)
        Me.Controls.Add(Me.Sec)
        Me.Controls.Add(Me.Em)
        Me.Controls.Add(Me.Nom)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Num)
        Me.Controls.Add(Me.solucion)
        Me.Controls.Add(Me.det)
        Me.Name = "CerrarTicket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = " "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents det As TextBox
    Friend WithEvents solucion As ComboBox
    Friend WithEvents Num As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Prio As Label
    Friend WithEvents Asu As Label
    Friend WithEvents Sec As Label
    Friend WithEvents Em As Label
    Friend WithEvents Nom As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Cod As Label
    Friend WithEvents Men As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents buscar As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Label1 As Label
End Class
