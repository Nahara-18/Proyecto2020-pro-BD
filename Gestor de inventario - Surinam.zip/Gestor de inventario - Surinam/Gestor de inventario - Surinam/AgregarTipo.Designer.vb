﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AgregarTipo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tip = New System.Windows.Forms.TextBox()
        Me.g = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'tip
        '
        Me.tip.Location = New System.Drawing.Point(40, 44)
        Me.tip.Name = "tip"
        Me.tip.Size = New System.Drawing.Size(84, 20)
        Me.tip.TabIndex = 0
        '
        'g
        '
        Me.g.Location = New System.Drawing.Point(130, 44)
        Me.g.Name = "g"
        Me.g.Size = New System.Drawing.Size(75, 20)
        Me.g.TabIndex = 1
        Me.g.Text = "Guardar"
        Me.g.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(119, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Agregar Tipo de insumo"
        '
        'AgregarTipo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(249, 85)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.g)
        Me.Controls.Add(Me.tip)
        Me.Name = "AgregarTipo"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "AgregarTipo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tip As TextBox
    Friend WithEvents g As Button
    Friend WithEvents Label1 As Label
End Class
