﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IngUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Tipo = New System.Windows.Forms.ComboBox()
        Me.Registrar = New System.Windows.Forms.Button()
        Me.lugar = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.sNom = New System.Windows.Forms.Label()
        Me.sNombre = New System.Windows.Forms.TextBox()
        Me.pNom = New System.Windows.Forms.Label()
        Me.pNombre = New System.Windows.Forms.TextBox()
        Me.pApellido = New System.Windows.Forms.TextBox()
        Me.pAp = New System.Windows.Forms.Label()
        Me.sApellido = New System.Windows.Forms.TextBox()
        Me.sAp = New System.Windows.Forms.Label()
        Me.C = New System.Windows.Forms.Label()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.Em = New System.Windows.Forms.Label()
        Me.Email = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Contraseña = New System.Windows.Forms.TextBox()
        Me.mosCon = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Tipo
        '
        Me.Tipo.FormattingEnabled = True
        Me.Tipo.Items.AddRange(New Object() {"Tecnico", "Reporte", "Administrador"})
        Me.Tipo.Location = New System.Drawing.Point(107, 280)
        Me.Tipo.Name = "Tipo"
        Me.Tipo.Size = New System.Drawing.Size(121, 21)
        Me.Tipo.TabIndex = 3
        Me.Tipo.Text = "Tipo"
        '
        'Registrar
        '
        Me.Registrar.Location = New System.Drawing.Point(142, 334)
        Me.Registrar.Name = "Registrar"
        Me.Registrar.Size = New System.Drawing.Size(75, 23)
        Me.Registrar.TabIndex = 10
        Me.Registrar.Text = "Registrar"
        Me.Registrar.UseVisualStyleBackColor = True
        '
        'lugar
        '
        Me.lugar.FormattingEnabled = True
        Me.lugar.Items.AddRange(New Object() {"6T", "Taller", "Salones", "Oficinas"})
        Me.lugar.Location = New System.Drawing.Point(107, 307)
        Me.lugar.Name = "lugar"
        Me.lugar.Size = New System.Drawing.Size(139, 21)
        Me.lugar.TabIndex = 17
        Me.lugar.Text = "Encargado de:"
        Me.lugar.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(3, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(37, 21)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'sNom
        '
        Me.sNom.AutoSize = True
        Me.sNom.Location = New System.Drawing.Point(189, 34)
        Me.sNom.Name = "sNom"
        Me.sNom.Size = New System.Drawing.Size(90, 13)
        Me.sNom.TabIndex = 29
        Me.sNom.Text = "Segundo Nombre"
        '
        'sNombre
        '
        Me.sNombre.Location = New System.Drawing.Point(197, 53)
        Me.sNombre.Name = "sNombre"
        Me.sNombre.Size = New System.Drawing.Size(96, 20)
        Me.sNombre.TabIndex = 28
        '
        'pNom
        '
        Me.pNom.AutoSize = True
        Me.pNom.Location = New System.Drawing.Point(71, 34)
        Me.pNom.Name = "pNom"
        Me.pNom.Size = New System.Drawing.Size(76, 13)
        Me.pNom.TabIndex = 25
        Me.pNom.Text = "Primer Nombre"
        '
        'pNombre
        '
        Me.pNombre.Location = New System.Drawing.Point(79, 53)
        Me.pNombre.Name = "pNombre"
        Me.pNombre.Size = New System.Drawing.Size(96, 20)
        Me.pNombre.TabIndex = 24
        '
        'pApellido
        '
        Me.pApellido.Location = New System.Drawing.Point(79, 106)
        Me.pApellido.Name = "pApellido"
        Me.pApellido.Size = New System.Drawing.Size(104, 20)
        Me.pApellido.TabIndex = 33
        '
        'pAp
        '
        Me.pAp.AutoSize = True
        Me.pAp.Location = New System.Drawing.Point(76, 87)
        Me.pAp.Name = "pAp"
        Me.pAp.Size = New System.Drawing.Size(76, 13)
        Me.pAp.TabIndex = 32
        Me.pAp.Text = "Primer Apellido"
        '
        'sApellido
        '
        Me.sApellido.Location = New System.Drawing.Point(197, 106)
        Me.sApellido.Name = "sApellido"
        Me.sApellido.Size = New System.Drawing.Size(104, 20)
        Me.sApellido.TabIndex = 37
        '
        'sAp
        '
        Me.sAp.AutoSize = True
        Me.sAp.Location = New System.Drawing.Point(194, 87)
        Me.sAp.Name = "sAp"
        Me.sAp.Size = New System.Drawing.Size(90, 13)
        Me.sAp.TabIndex = 36
        Me.sAp.Text = "Segundo Apellido"
        '
        'C
        '
        Me.C.AutoSize = True
        Me.C.Location = New System.Drawing.Point(110, 154)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(40, 13)
        Me.C.TabIndex = 41
        Me.C.Text = "Cedula"
        '
        'Cedula
        '
        Me.Cedula.Location = New System.Drawing.Point(155, 150)
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(101, 20)
        Me.Cedula.TabIndex = 40
        '
        'Em
        '
        Me.Em.AutoSize = True
        Me.Em.Location = New System.Drawing.Point(35, 191)
        Me.Em.Name = "Em"
        Me.Em.Size = New System.Drawing.Size(32, 13)
        Me.Em.TabIndex = 43
        Me.Em.Text = "Email"
        '
        'Email
        '
        Me.Email.Location = New System.Drawing.Point(74, 188)
        Me.Email.Name = "Email"
        Me.Email.Size = New System.Drawing.Size(236, 20)
        Me.Email.TabIndex = 44
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(88, 227)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Contraseña"
        '
        'Contraseña
        '
        Me.Contraseña.Location = New System.Drawing.Point(155, 224)
        Me.Contraseña.Name = "Contraseña"
        Me.Contraseña.Size = New System.Drawing.Size(101, 20)
        Me.Contraseña.TabIndex = 47
        Me.Contraseña.UseSystemPasswordChar = True
        '
        'mosCon
        '
        Me.mosCon.AutoSize = True
        Me.mosCon.Location = New System.Drawing.Point(129, 250)
        Me.mosCon.Name = "mosCon"
        Me.mosCon.Size = New System.Drawing.Size(117, 17)
        Me.mosCon.TabIndex = 48
        Me.mosCon.Text = "Mostrar contraseña"
        Me.mosCon.UseVisualStyleBackColor = True
        '
        'IngUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(366, 369)
        Me.Controls.Add(Me.mosCon)
        Me.Controls.Add(Me.Contraseña)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Email)
        Me.Controls.Add(Me.Em)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.sApellido)
        Me.Controls.Add(Me.sAp)
        Me.Controls.Add(Me.pApellido)
        Me.Controls.Add(Me.pAp)
        Me.Controls.Add(Me.sNom)
        Me.Controls.Add(Me.sNombre)
        Me.Controls.Add(Me.pNom)
        Me.Controls.Add(Me.pNombre)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lugar)
        Me.Controls.Add(Me.Registrar)
        Me.Controls.Add(Me.Tipo)
        Me.Name = "IngUsuario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Registro de Usuario"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Tipo As ComboBox
    Friend WithEvents Registrar As Button
    Friend WithEvents lugar As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents sNom As Label
    Friend WithEvents sNombre As TextBox
    Friend WithEvents pNom As Label
    Friend WithEvents pNombre As TextBox
    Friend WithEvents pApellido As TextBox
    Friend WithEvents pAp As Label
    Friend WithEvents sApellido As TextBox
    Friend WithEvents sAp As Label
    Friend WithEvents C As Label
    Friend WithEvents Cedula As TextBox
    Friend WithEvents Em As Label
    Friend WithEvents Email As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Contraseña As TextBox
    Friend WithEvents mosCon As CheckBox
End Class
