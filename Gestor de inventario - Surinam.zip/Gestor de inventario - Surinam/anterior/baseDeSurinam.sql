Create database DBSurinam; 
Use DBSurinam; 

 
Create table usuario( 
Cedula int(10) Primary Key NOT NULL, 
Pnombre varchar(15) NOT NULL, 
Snombre varchar(15),  
Papellido varchar(15) NOT NULL,  
Sapellido varchar(15),  
Email varchar(200) NOT NULL,  
Contrase�a varchar(15) NOT NULL,  
Tipo varchar(15) NOT NULL,  
Lugar varchar(20)); 

 
Create table insumo( 
Id int(10) Primary Key NOT NULL AUTO_INCREMENT, 
Nombre varchar(20) NOT NULL,
Tipo varchar(12) NOT NULL,  
Lugar varchar(15) NOT NULL,  
Localizaci�n varchar(50),  
Estado varchar(15),  
Soporte varchar(2), 
CantPedido int(3), 
cantComprado int(3)); 

 
Create table ticket( 
numero int(6) AUTO_INCREMENT PRIMARY KEY,
codigo varchar(5) NOT NULL UNIQUE,    
NomUsu varchar(15) NOT NULL, 
ApeUsu varchar(15) NOT NULL,  
Email varchar(200) NOT NULL, 
Sector varchar(15) NOT NULL, 
Lugar varchar(30),  
Asunto varchar(15) NOT NULL,  
Prioridad varchar(6) NOT NULL,  
Mensaje varchar(1000),
FechaTick datetime NOT NULL,
NumInforme int(15),
FechaInfor datetime, 
Solucion varchar(2), 
Detalle varchar(1000)); 


Create table gestiona( 
CeduUsu int(10), 
Insu int(10), 
Primary Key(CeduUsu,insu),
FOREIGN KEY(CeduUsu)REFERENCES usuario(Cedula),
Foreign Key(Insu) references insumo(Id));

 
Create table tiene(  
IdInsu int(10),  
NumTick int(6), 
Primary key(IdInsu, NumTick), 
FOREIGN KEY(IdInsu)REFERENCES insumo(Id), 
Foreign Key(NumTick)REFERENCES ticket(numero));

Insert into usuario(cedula,Pnombre,Papellido,email,contrase�a,tipo) VALUES(53676163,"Nahara","Superi","Nahara@gmail.com","19","Administrador");
Insert into usuario(cedula,Pnombre,Papellido,email,contrase�a,tipo,Lugar) VALUES(12345678,"Pablito","blabla","Pablito@gmail.com","11","Tecnico","Taller"),(87654321,"Fulanito","bla","Fulanito@gmail.com","22","Tecnico","Taller");
Insert into usuario(cedula,Pnombre,Snombre,Papellido,Sapellido,email,contrase�a,tipo,Lugar) VALUES(51855591,"Melanie","Lucia","Martinez","Borgarelli","097940754mela@gmail.com","13","Tecnico","Salones");

CREATE USER 'Administrador'
IDENTIFIED BY '12345' ;

GRANT ALL PRIVILEGES 
ON *.* 
TO 'Administrador' ;


CREATE USER 'Tecnico'
IDENTIFIED BY '4567' ;

GRANT DELETE , SELECT , UPDATE 
ON dbsurinam.ticket 
TO 'Tecnico' ;


CREATE USER 'Invitado'
IDENTIFIED BY ' ' ;

GRANT INSERT
ON dbsurinam.ticket 
TO 'Invitado' ;
