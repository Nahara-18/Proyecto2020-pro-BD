-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-08-2020 a las 02:34:56
-- Versión del servidor: 5.7.14
-- Versión de PHP: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbsurinam`
--
CREATE DATABASE IF NOT EXISTS `dbsurinam` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `dbsurinam`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gestiona`
--

CREATE TABLE `gestiona` (
  `CeduUsu` int(10) NOT NULL,
  `Insu` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `insumo`
--

CREATE TABLE `insumo` (
  `Id` int(10) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Tipo` varchar(12) NOT NULL,
  `Lugar` varchar(15) NOT NULL,
  `Localización` varchar(50) DEFAULT NULL,
  `Estado` varchar(15) DEFAULT NULL,
  `Soporte` varchar(2) DEFAULT NULL,
  `CantPedido` int(3) DEFAULT NULL,
  `cantComprado` int(3) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `insumo`
--

INSERT INTO `insumo` (`Id`, `Nombre`, `Tipo`, `Lugar`, `Localización`, `Estado`, `Soporte`, `CantPedido`, `cantComprado`) VALUES
(1, 'mouse ', 'Hardware', 'Taller', NULL, 'disponible', 'No', NULL, NULL),
(2, 'mouse 12', 'Hardware', 'Taller', '', 'disp', 'Si', 2, NULL),
(3, 'monitor 12', 'Hardware', 'Taller', NULL, 'disp', 'No', NULL, NULL),
(4, 'monitor 12.1', 'Hardware', 'Taller', '', 'disp', 'No', 1, NULL),
(5, 'teclado 2', 'Hardware', 'Sala', 'Informatica', 'dis', 'No', 6, NULL),
(6, 'teclado 2', 'Hardware', 'Taller', NULL, 'dip', 'No', NULL, NULL),
(7, 'laptop 1', 'Hardware', 'Taller', NULL, 'bloqueada', 'No', NULL, NULL),
(8, 'monitor', 'Hardware', 'Sala', 'informatica ', 'disponible', 'No', NULL, NULL),
(9, 'mouse', 'Hardware', 'Taller', NULL, 'disp', 'No', NULL, NULL),
(10, 'teclado', 'Hardware', 'Taller', NULL, 'dis', 'No', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ticket`
--

CREATE TABLE `ticket` (
  `numero` int(6) NOT NULL,
  `codigo` varchar(5) NOT NULL,
  `NomUsu` varchar(15) NOT NULL,
  `ApeUsu` varchar(15) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Sector` varchar(15) NOT NULL,
  `Lugar` varchar(30) DEFAULT NULL,
  `Asunto` varchar(15) NOT NULL,
  `Prioridad` varchar(6) NOT NULL,
  `Mensaje` varchar(1000) DEFAULT NULL,
  `FechaTick` datetime NOT NULL,
  `NumInforme` int(15) DEFAULT NULL,
  `FechaInfor` datetime DEFAULT NULL,
  `Solucion` varchar(2) DEFAULT NULL,
  `Detalle` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `ticket`
--

INSERT INTO `ticket` (`numero`, `codigo`, `NomUsu`, `ApeUsu`, `Email`, `Sector`, `Lugar`, `Asunto`, `Prioridad`, `Mensaje`, `FechaTick`, `NumInforme`, `FechaInfor`, `Solucion`, `Detalle`) VALUES
(1, '4ujQX', 'vero', ' lec', 'vero@.com', 'Biblioteca ', NULL, 'Software', 'Baja', 'asd', '2020-08-03 16:44:25', NULL, NULL, NULL, NULL),
(2, 'qqP0R', 'flu', ' fluu', 'flu@fluu.com', 'Biblioteca ', NULL, 'Hardware', 'Baja', 'falta de cables', '2020-08-03 13:08:47', NULL, NULL, NULL, NULL),
(3, 'FXmpq', 'gaag', ' ga', 'ga@gaag.com', 'Taller ', NULL, 'Hardware', 'Media', 'problemas con la computadora de la entrada', '2020-08-04 15:11:08', NULL, NULL, NULL, NULL),
(4, 'excvV', 'kk', ' qq', 'qq@kk.com', '6T ', NULL, 'Hardware', 'Baja', 'falta de computadoras', '2020-08-05 17:23:34', NULL, NULL, NULL, NULL),
(5, 'zLesV', 'jj', ' ejej', 'jj@jeje.com', '6T ', NULL, 'Hardware', 'Baja', 'fallas en la computadora del profesor', '2020-08-05 10:24:19', NULL, NULL, NULL, NULL),
(6, 'helPv', 'll', ' li', 'li@ll.com', '6T ', NULL, 'Hardware', 'Baja', 'faltan cargadores', '2020-08-07 07:26:20', NULL, NULL, NULL, NULL),
(7, 'VrkgA', 'nahara', ' Superi', 'nahar@gmail.com', 'Biblioteca ', NULL, 'Software', 'Media', 'Problemas con el programa .... en la computadora ...', '2020-08-07 21:37:49', NULL, NULL, NULL, NULL),
(8, '7xi6G', 'na', ' na', '@.', '6T ', NULL, 'Hardware', 'Baja', 'jiji', '2020-08-07 21:58:57', NULL, NULL, NULL, NULL),
(9, 'LjS51', 'asd', ' asd', 'asd@.c', 'Biblioteca ', NULL, 'Software', 'Media', 'asdasdd..', '2020-08-07 22:21:44', NULL, NULL, NULL, NULL),
(10, 'ubc87', 'sd', ' asd', 'asd@.', '6T ', NULL, 'Red', 'Media', 'asddddd', '2020-08-07 22:23:52', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiene`
--

CREATE TABLE `tiene` (
  `IdInsu` int(10) NOT NULL,
  `NumTick` int(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `Cedula` int(10) NOT NULL,
  `Pnombre` varchar(15) NOT NULL,
  `Snombre` varchar(15) DEFAULT NULL,
  `Papellido` varchar(15) NOT NULL,
  `Sapellido` varchar(15) DEFAULT NULL,
  `Email` varchar(200) NOT NULL,
  `Contraseña` varchar(15) NOT NULL,
  `Tipo` varchar(15) NOT NULL,
  `Lugar` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`Cedula`, `Pnombre`, `Snombre`, `Papellido`, `Sapellido`, `Email`, `Contraseña`, `Tipo`, `Lugar`) VALUES
(53676163, 'Nahara', ' ', 'Superi', ' ', 'Nahara@gmail.com', '19', 'Administrador', ''),
(25886311, 'Pablito', NULL, 'blabla', NULL, 'Pablito@gmail.com', '11', 'Tecnico', 'Taller'),
(85236890, 'Fulanito', NULL, 'bla', NULL, 'Fulanito@gmail.com', '22', 'Tecnico', 'Taller'),
(51855591, 'Melanie', 'Lucia', 'Martinez', 'Borgarelli', '097940754mela@gmail.com', '13', 'Tecnico', 'Salones'),
(12345670, 'flu', '  ', 'fluu', '  ', 'flu@fluu.com', 'flu', 'Tecnico', 'Salones'),
(13465798, 'gluu', '  ', 'gluu', '  ', 'glu@gluu.com', 'glu', 'Reporte', ' '),
(9876543, 'eso', '  ', 'ose', '  ', 'eso@ose.com', 'eso', 'Reporte', ' '),
(12345662, 'abcde', '  ', 'bdce', '  ', 'abc@def.com', 'abcd', 'Tecnico', 'Salones'),
(12344672, 'red', '  ', 'rojo', '  ', 'red@ds.com', 'red', 'Tecnico', 'Salones'),
(12345672, 'black', '  ', 'negro', '  ', 'black@bk.com', 'black', 'Tecnico', '6T');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `gestiona`
--
ALTER TABLE `gestiona`
  ADD PRIMARY KEY (`CeduUsu`,`Insu`),
  ADD KEY `Insu` (`Insu`);

--
-- Indices de la tabla `insumo`
--
ALTER TABLE `insumo`
  ADD PRIMARY KEY (`Id`);

--
-- Indices de la tabla `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`numero`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Indices de la tabla `tiene`
--
ALTER TABLE `tiene`
  ADD PRIMARY KEY (`IdInsu`,`NumTick`),
  ADD KEY `NumTick` (`NumTick`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`Cedula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `insumo`
--
ALTER TABLE `insumo`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `ticket`
--
ALTER TABLE `ticket`
  MODIFY `numero` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

CREATE USER 'Administrador'
IDENTIFIED BY '12345' ;

GRANT ALL PRIVILEGES 
ON *.* 
TO 'Administrador' ;


CREATE USER 'Tecnico'
IDENTIFIED BY '4567' ;

GRANT DELETE , SELECT , UPDATE 
ON dbsurinam.ticket 
TO 'Tecnico' ;


CREATE USER 'Invitado'
IDENTIFIED BY ' ' ;

GRANT INSERT
ON dbsurinam.ticket 
TO 'Invitado' ;
