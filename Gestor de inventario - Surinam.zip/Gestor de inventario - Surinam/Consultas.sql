/*1*/  /* Lista los tickets por fecha */
     CREATE  VIEW `listado_ticketsOrdenFecha`  AS select ticket.numero as Num,codigo as Cod,Prioridad,Asunto,insumo.Lugar as Sector,Mensaje,registra.FechaInicio AS Fecha
from ticket inner join registra on numTicket = numero inner join insumo on Id= idInsumo where registra.FechaCierre IS NULL order by Fecha;


/*2*/  /* Cantidad de ticket por area*/
CREATE  VIEW `Cantidad_ticketsPorArea`  AS SELECT count(insumo.Lugar) as cantidad, insumo.Lugar as Sector 
from ticket inner join insumo on ticket.idInsumo= insumo.Id INNER join registra on registra.numTicket= ticket.numero
where registra.FechaCierre IS NULL
GROUP by Sector;

 /*3*/  /* Solo trael el area con mayor cant de tickets */
    CREATE VIEW mayor_area AS SELECT insumo.Lugar as lugar, COUNT(Lugar) AS cuenta 
FROM insumo 
INNER JOIN ticket ON ticket.idInsumo = insumo.Id INNER JOIN registra ON registra.numTicket = ticket.numero 
WHERE registra.FechaCierre IS NULL 
GROUP BY lugar
ORDER by cuenta DESC LIMIT 0,1
;


/*4*/  /* cuenta los dias hasta el cierre */
    CREATE view calculoTickets as SELECT ticket.codigo as cod,registra.FechaInicio as fecha1,registra.FechaCierre as cierre,timestampdiff(month,registra.FechaInicio,registra.FechaCierre) as cantidadMeses,timestampdiff(day,registra.FechaInicio,registra.FechaCierre) as cantidadDias 
from registra 
inner join ticket on registra.numTicket=ticket.numero
HAVING registra.FechaCierre IS NOT NULL;


/*5*/  /* total stock de insumos */
Create view cantInsumosTotal as SELECT count(insumo.Id) as cantidad from insumo;


/*6*/  /* localizacion de insumos */
Create view lugarInsumos as SELECT insumo.Id as id,insumo.Nombre as insumo,insumo.Lugar as lugar, insumo.Localizacion as localizado from insumo;


 /*8*/  /* lista de donaciones */
create view donaciones as select insumo.Id as id,insumo.Nombre as insumo,insumo.Donador as donador,fechasinsumo.Fecha as fecha
from gestiona
inner join insumo on insumo.Id = gestiona.Insu
INNER join fechasinsumo on fechasinsumo.idG = gestiona.id
WHERE insumo.CompODon = "Donado";