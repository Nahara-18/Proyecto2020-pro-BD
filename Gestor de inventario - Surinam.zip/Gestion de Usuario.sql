
CREATE USER 'Administrador'
IDENTIFIED BY '12345' ;

GRANT ALL PRIVILEGES 
ON *.* 
TO 'Administrador' ;


CREATE USER 'Tecnico'
IDENTIFIED BY '4567' ;

GRANT DELETE , SELECT , UPDATE 
ON dbsurinam.ticket 
TO 'Tecnico' ;


CREATE USER 'Invitado'
IDENTIFIED BY ' ' ;

GRANT INSERT
ON dbsurinam.ticket 
TO 'Invitado' ;
