﻿Public Class Ticket
    Private Sub enviar_Click(sender As Object, e As EventArgs) Handles enviar.Click
        Modulo.email(tbEmailT.Text)


    End Sub

    Private Sub estado_Click(sender As Object, e As EventArgs) Handles estado.Click
        InformeInvitado.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Login.Visible = True
        Me.Close()


    End Sub
End Class