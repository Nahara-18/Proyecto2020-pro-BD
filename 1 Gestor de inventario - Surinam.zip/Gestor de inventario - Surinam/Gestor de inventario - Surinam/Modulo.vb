﻿Module Modulo
    Function cedula(C As String)
        Dim array(6), cantidad, pos, car, multi, suma, arr, resto As Integer
        array = {2, 9, 8, 7, 6, 3, 4}
        cantidad = Len(C)
        pos = 1
        arr = 0
        multi = 0
        suma = 0
        If (cantidad = 8) Then
            While (pos < 8)
                car = Mid(C, pos, 1)
                multi = car * array(arr)
                suma = suma + multi
                pos += 1
                arr += 1
            End While
            resto = 10 - Mid(suma, 3, 1)
            If (resto = Mid(C, 8, 1)) Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
    Function vacio(text As String)
        If (text = "") Then
            Return True
        Else
            Return False
        End If
    End Function

    Function email(text As String)
        Dim cant As Integer = Len(text)
        Dim pos As Integer = 1
        Dim caracter As String
        Dim arroba, punto As Integer
        arroba = 0
        punto = 0
        While (pos <= cant)
            caracter = Mid(text, pos, 1)
            If (caracter = "@") Then
                arroba = 1
            ElseIf (caracter = ".") Then
                punto = 1
            End If
            pos += 1
        End While
        If (arroba = 1 And punto = 1) Then
            Return True
        Else
            Return False
        End If
    End Function

End Module
