﻿Public Class Listado

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Dim a As Integer = 0
    Private Sub Listado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Modulo.listarT()
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles list.SelectedIndexChanged
        If (list.SelectedItem = "Abierto") Then
            a = 1
            'Modulo.listarTAbiertos()
        ElseIf (list.SelectedItem = "Cerrado") Then
            a = 2
            'Modulo.listarTCerrados()
        ElseIf (list.SelectedItem = "Todo") Then
            a = 0
            'Modulo.listarT()
        End If
    End Sub

    Private Sub ord_Click(sender As Object, e As EventArgs) Handles ord.Click
        If (a = 1) Then
            Modulo.listarTAbiertos()

        ElseIf (a = 2) Then
            Modulo.listarTCerrados()
        ElseIf (a = 0) Then
            Modulo.listarT()
        End If
    End Sub
End Class