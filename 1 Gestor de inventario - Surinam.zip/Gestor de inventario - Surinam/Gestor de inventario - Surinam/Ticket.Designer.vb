﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Ticket
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.nombre = New System.Windows.Forms.TextBox()
        Me.apellido = New System.Windows.Forms.TextBox()
        Me.email = New System.Windows.Forms.TextBox()
        Me.Sector = New System.Windows.Forms.ComboBox()
        Me.Asunto = New System.Windows.Forms.ComboBox()
        Me.N = New System.Windows.Forms.Label()
        Me.Em = New System.Windows.Forms.Label()
        Me.Prioridad = New System.Windows.Forms.ComboBox()
        Me.m = New System.Windows.Forms.Label()
        Me.A = New System.Windows.Forms.Label()
        Me.Mensaje = New System.Windows.Forms.TextBox()
        Me.enviar = New System.Windows.Forms.Button()
        Me.lug = New System.Windows.Forms.Label()
        Me.Lugar = New System.Windows.Forms.TextBox()
        Me.estado = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SecLugar = New System.Windows.Forms.Label()
        Me.asu = New System.Windows.Forms.Label()
        Me.prio = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'nombre
        '
        Me.nombre.Location = New System.Drawing.Point(123, 47)
        Me.nombre.Name = "nombre"
        Me.nombre.Size = New System.Drawing.Size(100, 20)
        Me.nombre.TabIndex = 0
        '
        'apellido
        '
        Me.apellido.Location = New System.Drawing.Point(301, 47)
        Me.apellido.Name = "apellido"
        Me.apellido.Size = New System.Drawing.Size(100, 20)
        Me.apellido.TabIndex = 1
        '
        'email
        '
        Me.email.Location = New System.Drawing.Point(123, 88)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(219, 20)
        Me.email.TabIndex = 2
        '
        'Sector
        '
        Me.Sector.FormattingEnabled = True
        Me.Sector.Items.AddRange(New Object() {"Sala", "Biblioteca", "6T", "Taller", "Salon", "Oficina", "(tutoría", "sala profesores", "biblioteca"})
        Me.Sector.Location = New System.Drawing.Point(195, 138)
        Me.Sector.Name = "Sector"
        Me.Sector.Size = New System.Drawing.Size(134, 21)
        Me.Sector.TabIndex = 3
        Me.Sector.Text = "Sector del problema"
        '
        'Asunto
        '
        Me.Asunto.FormattingEnabled = True
        Me.Asunto.Items.AddRange(New Object() {"Software", "Hardware", "Red"})
        Me.Asunto.Location = New System.Drawing.Point(102, 232)
        Me.Asunto.Name = "Asunto"
        Me.Asunto.Size = New System.Drawing.Size(121, 21)
        Me.Asunto.TabIndex = 4
        Me.Asunto.Text = "Asunto"
        '
        'N
        '
        Me.N.AutoSize = True
        Me.N.Location = New System.Drawing.Point(75, 50)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(42, 13)
        Me.N.TabIndex = 5
        Me.N.Text = "nombre"
        '
        'Em
        '
        Me.Em.AutoSize = True
        Me.Em.Location = New System.Drawing.Point(75, 91)
        Me.Em.Name = "Em"
        Me.Em.Size = New System.Drawing.Size(32, 13)
        Me.Em.TabIndex = 6
        Me.Em.Text = "Email"
        '
        'Prioridad
        '
        Me.Prioridad.FormattingEnabled = True
        Me.Prioridad.Items.AddRange(New Object() {"Baja", "Media", "Alta"})
        Me.Prioridad.Location = New System.Drawing.Point(301, 232)
        Me.Prioridad.Name = "Prioridad"
        Me.Prioridad.Size = New System.Drawing.Size(121, 21)
        Me.Prioridad.TabIndex = 9
        Me.Prioridad.Text = "Prioridad"
        '
        'm
        '
        Me.m.AutoSize = True
        Me.m.Location = New System.Drawing.Point(9, 295)
        Me.m.Name = "m"
        Me.m.Size = New System.Drawing.Size(47, 13)
        Me.m.TabIndex = 11
        Me.m.Text = "Mensaje"
        '
        'A
        '
        Me.A.AutoSize = True
        Me.A.Location = New System.Drawing.Point(251, 50)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(44, 13)
        Me.A.TabIndex = 12
        Me.A.Text = "Apellido"
        '
        'Mensaje
        '
        Me.Mensaje.Location = New System.Drawing.Point(37, 311)
        Me.Mensaje.Multiline = True
        Me.Mensaje.Name = "Mensaje"
        Me.Mensaje.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Mensaje.Size = New System.Drawing.Size(389, 91)
        Me.Mensaje.TabIndex = 13
        '
        'enviar
        '
        Me.enviar.Location = New System.Drawing.Point(195, 408)
        Me.enviar.Name = "enviar"
        Me.enviar.Size = New System.Drawing.Size(75, 23)
        Me.enviar.TabIndex = 14
        Me.enviar.Text = "Enviar"
        Me.enviar.UseVisualStyleBackColor = True
        '
        'lug
        '
        Me.lug.AutoSize = True
        Me.lug.Location = New System.Drawing.Point(145, 167)
        Me.lug.Name = "lug"
        Me.lug.Size = New System.Drawing.Size(34, 13)
        Me.lug.TabIndex = 15
        Me.lug.Text = "Lugar"
        Me.lug.Visible = False
        '
        'Lugar
        '
        Me.Lugar.Location = New System.Drawing.Point(185, 165)
        Me.Lugar.Name = "Lugar"
        Me.Lugar.Size = New System.Drawing.Size(128, 20)
        Me.Lugar.TabIndex = 16
        Me.Lugar.Visible = False
        '
        'estado
        '
        Me.estado.Location = New System.Drawing.Point(348, 10)
        Me.estado.Name = "estado"
        Me.estado.Size = New System.Drawing.Size(117, 23)
        Me.estado.TabIndex = 17
        Me.estado.Text = "Estado de un ticket"
        Me.estado.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(37, 21)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'SecLugar
        '
        Me.SecLugar.AutoSize = True
        Me.SecLugar.ForeColor = System.Drawing.Color.Red
        Me.SecLugar.Location = New System.Drawing.Point(124, 141)
        Me.SecLugar.Name = "SecLugar"
        Me.SecLugar.Size = New System.Drawing.Size(56, 13)
        Me.SecLugar.TabIndex = 19
        Me.SecLugar.Text = "Requerido"
        Me.SecLugar.Visible = False
        '
        'asu
        '
        Me.asu.AutoSize = True
        Me.asu.ForeColor = System.Drawing.Color.Red
        Me.asu.Location = New System.Drawing.Point(34, 235)
        Me.asu.Name = "asu"
        Me.asu.Size = New System.Drawing.Size(56, 13)
        Me.asu.TabIndex = 20
        Me.asu.Text = "Requerido"
        Me.asu.Visible = False
        '
        'prio
        '
        Me.prio.AutoSize = True
        Me.prio.ForeColor = System.Drawing.Color.Red
        Me.prio.Location = New System.Drawing.Point(239, 235)
        Me.prio.Name = "prio"
        Me.prio.Size = New System.Drawing.Size(56, 13)
        Me.prio.TabIndex = 21
        Me.prio.Text = "Requerido"
        Me.prio.Visible = False
        '
        'Ticket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(477, 449)
        Me.Controls.Add(Me.prio)
        Me.Controls.Add(Me.asu)
        Me.Controls.Add(Me.SecLugar)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.estado)
        Me.Controls.Add(Me.Lugar)
        Me.Controls.Add(Me.lug)
        Me.Controls.Add(Me.enviar)
        Me.Controls.Add(Me.Mensaje)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.m)
        Me.Controls.Add(Me.Prioridad)
        Me.Controls.Add(Me.Em)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.Asunto)
        Me.Controls.Add(Me.Sector)
        Me.Controls.Add(Me.email)
        Me.Controls.Add(Me.apellido)
        Me.Controls.Add(Me.nombre)
        Me.Name = "Ticket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ticket"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents nombre As TextBox
    Friend WithEvents apellido As TextBox
    Friend WithEvents email As TextBox
    Friend WithEvents Sector As ComboBox
    Friend WithEvents Asunto As ComboBox
    Friend WithEvents N As Label
    Friend WithEvents Em As Label
    Friend WithEvents Prioridad As ComboBox
    Friend WithEvents m As Label
    Friend WithEvents A As Label
    Friend WithEvents Mensaje As TextBox
    Friend WithEvents enviar As Button
    Friend WithEvents lug As Label
    Friend WithEvents Lugar As TextBox
    Friend WithEvents estado As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents SecLugar As Label
    Friend WithEvents asu As Label
    Friend WithEvents prio As Label
End Class
