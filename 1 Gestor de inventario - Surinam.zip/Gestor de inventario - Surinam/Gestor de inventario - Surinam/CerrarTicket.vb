﻿Public Class CerrarTicket

End Class