﻿Public Class Login
    Private Sub contraseña_TextChanged(sender As Object, e As EventArgs) Handles contraseña.TextChanged
        If mosCon.Checked = True Then
            contraseña.UseSystemPasswordChar = False
        Else
            contraseña.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub mosCon_CheckedChanged(sender As Object, e As EventArgs) Handles mosCon.CheckedChanged
        If mosCon.Checked = True Then
            contraseña.UseSystemPasswordChar = False
        Else
            contraseña.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Ticket.Visible = True
    End Sub
End Class
