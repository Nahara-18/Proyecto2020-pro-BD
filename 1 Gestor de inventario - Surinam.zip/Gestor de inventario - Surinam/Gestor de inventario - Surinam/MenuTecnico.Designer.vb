﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuTecnico
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ingreso = New System.Windows.Forms.Button()
        Me.editar = New System.Windows.Forms.Button()
        Me.tickets = New System.Windows.Forms.Button()
        Me.cerrar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ingreso
        '
        Me.ingreso.Location = New System.Drawing.Point(76, 49)
        Me.ingreso.Name = "ingreso"
        Me.ingreso.Size = New System.Drawing.Size(101, 23)
        Me.ingreso.TabIndex = 0
        Me.ingreso.Text = "Ingresar Insumo"
        Me.ingreso.UseVisualStyleBackColor = True
        '
        'editar
        '
        Me.editar.Location = New System.Drawing.Point(77, 98)
        Me.editar.Name = "editar"
        Me.editar.Size = New System.Drawing.Size(100, 23)
        Me.editar.TabIndex = 1
        Me.editar.Text = "Editar Insumo"
        Me.editar.UseVisualStyleBackColor = True
        '
        'tickets
        '
        Me.tickets.Location = New System.Drawing.Point(86, 149)
        Me.tickets.Name = "tickets"
        Me.tickets.Size = New System.Drawing.Size(75, 23)
        Me.tickets.TabIndex = 2
        Me.tickets.Text = "Tickets"
        Me.tickets.UseVisualStyleBackColor = True
        '
        'cerrar
        '
        Me.cerrar.Location = New System.Drawing.Point(183, 12)
        Me.cerrar.Name = "cerrar"
        Me.cerrar.Size = New System.Drawing.Size(78, 23)
        Me.cerrar.TabIndex = 4
        Me.cerrar.Text = "Cerrar sesión"
        Me.cerrar.UseVisualStyleBackColor = True
        '
        'MenuTecnico
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(273, 216)
        Me.Controls.Add(Me.cerrar)
        Me.Controls.Add(Me.tickets)
        Me.Controls.Add(Me.editar)
        Me.Controls.Add(Me.ingreso)
        Me.Name = "MenuTecnico"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ingreso As Button
    Friend WithEvents editar As Button
    Friend WithEvents tickets As Button
    Friend WithEvents cerrar As Button
End Class
