﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IngUsuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbnomIng = New System.Windows.Forms.TextBox()
        Me.tbEmailIng = New System.Windows.Forms.TextBox()
        Me.cbTipoIng = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbCedulaIng = New System.Windows.Forms.TextBox()
        Me.Registrar = New System.Windows.Forms.Button()
        Me.tbApeIng = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'tbnomIng
        '
        Me.tbnomIng.Location = New System.Drawing.Point(67, 26)
        Me.tbnomIng.Name = "tbnomIng"
        Me.tbnomIng.Size = New System.Drawing.Size(123, 20)
        Me.tbnomIng.TabIndex = 0
        '
        'tbEmailIng
        '
        Me.tbEmailIng.Location = New System.Drawing.Point(67, 139)
        Me.tbEmailIng.Name = "tbEmailIng"
        Me.tbEmailIng.Size = New System.Drawing.Size(236, 20)
        Me.tbEmailIng.TabIndex = 2
        '
        'cbTipoIng
        '
        Me.cbTipoIng.FormattingEnabled = True
        Me.cbTipoIng.Items.AddRange(New Object() {"Tecnico", "Reporte", "Administrador"})
        Me.cbTipoIng.Location = New System.Drawing.Point(69, 106)
        Me.cbTipoIng.Name = "cbTipoIng"
        Me.cbTipoIng.Size = New System.Drawing.Size(121, 21)
        Me.cbTipoIng.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Tipo"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Email"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(22, 30)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Nombre"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(209, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Apellido"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(22, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Cedula"
        '
        'tbCedulaIng
        '
        Me.tbCedulaIng.Location = New System.Drawing.Point(67, 75)
        Me.tbCedulaIng.Name = "tbCedulaIng"
        Me.tbCedulaIng.Size = New System.Drawing.Size(170, 20)
        Me.tbCedulaIng.TabIndex = 8
        '
        'Registrar
        '
        Me.Registrar.Location = New System.Drawing.Point(164, 272)
        Me.Registrar.Name = "Registrar"
        Me.Registrar.Size = New System.Drawing.Size(75, 23)
        Me.Registrar.TabIndex = 10
        Me.Registrar.Text = "Registrar"
        Me.Registrar.UseVisualStyleBackColor = True
        '
        'tbApeIng
        '
        Me.tbApeIng.Location = New System.Drawing.Point(259, 26)
        Me.tbApeIng.Name = "tbApeIng"
        Me.tbApeIng.Size = New System.Drawing.Size(123, 20)
        Me.tbApeIng.TabIndex = 11
        '
        'IngUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(410, 316)
        Me.Controls.Add(Me.tbApeIng)
        Me.Controls.Add(Me.Registrar)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.tbCedulaIng)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbTipoIng)
        Me.Controls.Add(Me.tbEmailIng)
        Me.Controls.Add(Me.tbnomIng)
        Me.Name = "IngUsuario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "IngUsuario"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbnomIng As TextBox
    Friend WithEvents tbEmailIng As TextBox
    Friend WithEvents cbTipoIng As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents tbCedulaIng As TextBox
    Friend WithEvents Registrar As Button
    Friend WithEvents tbApeIng As TextBox
End Class
