﻿Public Class Login
    Private Sub contraseña_TextChanged(sender As Object, e As EventArgs) Handles contraseña.TextChanged
        If mosCon.Checked = True Then
            contraseña.UseSystemPasswordChar = False
        Else
            contraseña.UseSystemPasswordChar = True
        End If
    End Sub
    Private Sub mosCon_CheckedChanged(sender As Object, e As EventArgs) Handles mosCon.CheckedChanged
        If mosCon.Checked = True Then
            contraseña.UseSystemPasswordChar = False
        Else
            contraseña.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Ticket.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (email.Text = 1) Then
            MenuAdmin.Visible = True
        ElseIf (email.Text = 2) Then
            MenuTecnico.Visible = True
        ElseIf (email.Text = 3) Then
            MenuReporte.Visible = True
        End If
    End Sub
End Class
