﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ticket
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbNomT = New System.Windows.Forms.TextBox()
        Me.tbApeT = New System.Windows.Forms.TextBox()
        Me.tbEmailT = New System.Windows.Forms.TextBox()
        Me.cbSectorT = New System.Windows.Forms.ComboBox()
        Me.cbAsuntoT = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbPrioridadT = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.tbMensajeT = New System.Windows.Forms.TextBox()
        Me.enviar = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.salon = New System.Windows.Forms.TextBox()
        Me.estado = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tbNomT
        '
        Me.tbNomT.Location = New System.Drawing.Point(123, 53)
        Me.tbNomT.Name = "tbNomT"
        Me.tbNomT.Size = New System.Drawing.Size(100, 20)
        Me.tbNomT.TabIndex = 0
        '
        'tbApeT
        '
        Me.tbApeT.Location = New System.Drawing.Point(301, 53)
        Me.tbApeT.Name = "tbApeT"
        Me.tbApeT.Size = New System.Drawing.Size(100, 20)
        Me.tbApeT.TabIndex = 1
        '
        'tbEmailT
        '
        Me.tbEmailT.Location = New System.Drawing.Point(123, 94)
        Me.tbEmailT.Name = "tbEmailT"
        Me.tbEmailT.Size = New System.Drawing.Size(219, 20)
        Me.tbEmailT.TabIndex = 2
        '
        'cbSectorT
        '
        Me.cbSectorT.FormattingEnabled = True
        Me.cbSectorT.Items.AddRange(New Object() {"Sala", "Biblioteca", "6T", "Taller", "Salones (docente)", "Oficinas (tutoría, ", "sala de profesores, ", "biblioteca)"})
        Me.cbSectorT.Location = New System.Drawing.Point(102, 139)
        Me.cbSectorT.Name = "cbSectorT"
        Me.cbSectorT.Size = New System.Drawing.Size(134, 21)
        Me.cbSectorT.TabIndex = 3
        Me.cbSectorT.Text = "Sector del problema"
        '
        'cbAsuntoT
        '
        Me.cbAsuntoT.FormattingEnabled = True
        Me.cbAsuntoT.Items.AddRange(New Object() {"Software", "Hardware", "Red"})
        Me.cbAsuntoT.Location = New System.Drawing.Point(102, 178)
        Me.cbAsuntoT.Name = "cbAsuntoT"
        Me.cbAsuntoT.Size = New System.Drawing.Size(121, 21)
        Me.cbAsuntoT.TabIndex = 4
        Me.cbAsuntoT.Text = "Asunto"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(75, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "nombre"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(75, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Email"
        '
        'cbPrioridadT
        '
        Me.cbPrioridadT.FormattingEnabled = True
        Me.cbPrioridadT.Items.AddRange(New Object() {"Baja", "Media", "Alta"})
        Me.cbPrioridadT.Location = New System.Drawing.Point(254, 178)
        Me.cbPrioridadT.Name = "cbPrioridadT"
        Me.cbPrioridadT.Size = New System.Drawing.Size(121, 21)
        Me.cbPrioridadT.TabIndex = 9
        Me.cbPrioridadT.Text = "Prioridad"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(43, 230)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Mensaje"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(251, 56)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Apellido"
        '
        'tbMensajeT
        '
        Me.tbMensajeT.Location = New System.Drawing.Point(40, 256)
        Me.tbMensajeT.Multiline = True
        Me.tbMensajeT.Name = "tbMensajeT"
        Me.tbMensajeT.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tbMensajeT.Size = New System.Drawing.Size(389, 91)
        Me.tbMensajeT.TabIndex = 13
        '
        'enviar
        '
        Me.enviar.Location = New System.Drawing.Point(195, 377)
        Me.enviar.Name = "enviar"
        Me.enviar.Size = New System.Drawing.Size(75, 23)
        Me.enviar.TabIndex = 14
        Me.enviar.Text = "Enviar"
        Me.enviar.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(261, 141)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(34, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Lugar"
        '
        'salon
        '
        Me.salon.Location = New System.Drawing.Point(301, 139)
        Me.salon.Name = "salon"
        Me.salon.Size = New System.Drawing.Size(93, 20)
        Me.salon.TabIndex = 16
        '
        'estado
        '
        Me.estado.Location = New System.Drawing.Point(348, 10)
        Me.estado.Name = "estado"
        Me.estado.Size = New System.Drawing.Size(117, 23)
        Me.estado.TabIndex = 17
        Me.estado.Text = "Estado de un ticket"
        Me.estado.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 10)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(37, 21)
        Me.Button1.TabIndex = 18
        Me.Button1.Text = "<"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Ticket
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(477, 422)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.estado)
        Me.Controls.Add(Me.salon)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.enviar)
        Me.Controls.Add(Me.tbMensajeT)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cbPrioridadT)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbAsuntoT)
        Me.Controls.Add(Me.cbSectorT)
        Me.Controls.Add(Me.tbEmailT)
        Me.Controls.Add(Me.tbApeT)
        Me.Controls.Add(Me.tbNomT)
        Me.Name = "Ticket"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ticket"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tbNomT As TextBox
    Friend WithEvents tbApeT As TextBox
    Friend WithEvents tbEmailT As TextBox
    Friend WithEvents cbSectorT As ComboBox
    Friend WithEvents cbAsuntoT As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cbPrioridadT As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents tbMensajeT As TextBox
    Friend WithEvents enviar As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents salon As TextBox
    Friend WithEvents estado As Button
    Friend WithEvents Button1 As Button
End Class
