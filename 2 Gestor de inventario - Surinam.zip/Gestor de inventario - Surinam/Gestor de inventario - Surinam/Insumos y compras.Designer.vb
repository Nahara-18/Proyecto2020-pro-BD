﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Insumos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Insumo = New System.Windows.Forms.DataGridView()
        Me.Compras = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.nom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lugar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.comp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.stock = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.FInicio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FFinal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cant = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.insu = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.Insumo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Compras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Insumo
        '
        Me.Insumo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Insumo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.nom, Me.tipo, Me.lugar, Me.comp, Me.stock})
        Me.Insumo.EnableHeadersVisualStyles = False
        Me.Insumo.Location = New System.Drawing.Point(3, 125)
        Me.Insumo.Name = "Insumo"
        Me.Insumo.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Insumo.RowHeadersVisible = False
        Me.Insumo.Size = New System.Drawing.Size(495, 184)
        Me.Insumo.TabIndex = 4
        '
        'Compras
        '
        Me.Compras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Compras.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FInicio, Me.FFinal, Me.cant, Me.insu, Me.num})
        Me.Compras.EnableHeadersVisualStyles = False
        Me.Compras.Location = New System.Drawing.Point(3, 345)
        Me.Compras.Name = "Compras"
        Me.Compras.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Compras.RowHeadersVisible = False
        Me.Compras.Size = New System.Drawing.Size(779, 140)
        Me.Compras.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 318)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Compras"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Insumos"
        '
        'nom
        '
        Me.nom.FillWeight = 110.7445!
        Me.nom.HeaderText = "Nombre"
        Me.nom.Name = "nom"
        Me.nom.Width = 150
        '
        'tipo
        '
        Me.tipo.FillWeight = 110.7445!
        Me.tipo.HeaderText = "Tipo"
        Me.tipo.Name = "tipo"
        Me.tipo.Width = 80
        '
        'lugar
        '
        Me.lugar.FillWeight = 110.7445!
        Me.lugar.HeaderText = "Lugar"
        Me.lugar.Name = "lugar"
        Me.lugar.Width = 120
        '
        'comp
        '
        Me.comp.FillWeight = 110.7445!
        Me.comp.HeaderText = "Necesidad de compra"
        Me.comp.Name = "comp"
        Me.comp.Width = 80
        '
        'stock
        '
        Me.stock.FillWeight = 110.7445!
        Me.stock.HeaderText = "Stock"
        Me.stock.Name = "stock"
        Me.stock.Width = 40
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(106, 70)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Buscar por"
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(170, 97)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 9
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"numero", "nombre", "tipo"})
        Me.ComboBox1.Location = New System.Drawing.Point(170, 70)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Enabled = False
        Me.Button1.Location = New System.Drawing.Point(276, 95)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(59, 23)
        Me.Button1.TabIndex = 11
        Me.Button1.Text = "Buscar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Realizadas", "A realizar"})
        Me.ComboBox2.Location = New System.Drawing.Point(77, 315)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 12
        Me.ComboBox2.Text = "Realizadas"
        '
        'FInicio
        '
        Me.FInicio.HeaderText = "Inicio"
        Me.FInicio.Name = "FInicio"
        '
        'FFinal
        '
        Me.FFinal.HeaderText = "Finalizacion"
        Me.FFinal.Name = "FFinal"
        '
        'cant
        '
        Me.cant.HeaderText = "Cantidad"
        Me.cant.Name = "cant"
        '
        'insu
        '
        Me.insu.HeaderText = "Insumo"
        Me.insu.Name = "insu"
        '
        'num
        '
        Me.num.HeaderText = "Numero del insumo"
        Me.num.Name = "num"
        '
        'Insumos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(783, 488)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Compras)
        Me.Controls.Add(Me.Insumo)
        Me.DoubleBuffered = True
        Me.Name = "Insumos"
        Me.Text = "Insumos"
        CType(Me.Insumo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Compras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Insumo As DataGridView
    Friend WithEvents nom As DataGridViewTextBoxColumn
    Friend WithEvents tipo As DataGridViewTextBoxColumn
    Friend WithEvents lugar As DataGridViewTextBoxColumn
    Friend WithEvents comp As DataGridViewTextBoxColumn
    Friend WithEvents stock As DataGridViewTextBoxColumn
    Friend WithEvents Compras As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents FInicio As DataGridViewTextBoxColumn
    Friend WithEvents FFinal As DataGridViewTextBoxColumn
    Friend WithEvents cant As DataGridViewTextBoxColumn
    Friend WithEvents insu As DataGridViewTextBoxColumn
    Friend WithEvents num As DataGridViewTextBoxColumn
    Friend WithEvents ComboBox2 As ComboBox
End Class
