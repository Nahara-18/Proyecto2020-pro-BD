﻿Public Class MenuReporte
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles cerrar.Click
        Login.Visible = True
        Me.Close()
    End Sub
End Class