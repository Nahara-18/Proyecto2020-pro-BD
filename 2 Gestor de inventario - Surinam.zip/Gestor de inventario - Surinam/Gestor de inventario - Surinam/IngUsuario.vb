﻿Public Class IngUsuario
    Private Sub Registrar_Click(sender As Object, e As EventArgs) Handles Registrar.Click
        Modulo.cedula(tbCedulaIng.Text)
        Modulo.email(tbEmailIng.Text)
    End Sub

    Private Sub tbCedulaIng_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tbCedulaIng.KeyPress
        'Esto indica que solo se puede ingresar numeros y borrar en el textbox
        If Char.IsDigit(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        Else
            e.Handled = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class