﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ListadoInformes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Tickets = New System.Windows.Forms.DataGridView()
        Me.fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.hora = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.asun = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.sec = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.men = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ver = New System.Windows.Forms.DataGridViewButtonColumn()
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(4, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(37, 21)
        Me.Button2.TabIndex = 25
        Me.Button2.Text = "<"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(278, 29)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(132, 20)
        Me.TextBox1.TabIndex = 24
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(429, 27)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Buscar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Tickets
        '
        Me.Tickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tickets.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.fecha, Me.hora, Me.cod, Me.asun, Me.sec, Me.men, Me.ver})
        Me.Tickets.EnableHeadersVisualStyles = False
        Me.Tickets.Location = New System.Drawing.Point(4, 60)
        Me.Tickets.Name = "Tickets"
        Me.Tickets.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        Me.Tickets.RowHeadersVisible = False
        Me.Tickets.Size = New System.Drawing.Size(793, 388)
        Me.Tickets.TabIndex = 22
        '
        'fecha
        '
        Me.fecha.FillWeight = 110.7445!
        Me.fecha.HeaderText = "Fecha"
        Me.fecha.Name = "fecha"
        Me.fecha.Width = 80
        '
        'hora
        '
        Me.hora.HeaderText = "Hora"
        Me.hora.Name = "hora"
        Me.hora.Width = 50
        '
        'cod
        '
        Me.cod.FillWeight = 110.7445!
        Me.cod.HeaderText = "Codigo"
        Me.cod.Name = "cod"
        Me.cod.Width = 80
        '
        'asun
        '
        Me.asun.FillWeight = 110.7445!
        Me.asun.HeaderText = "Asunto"
        Me.asun.Name = "asun"
        '
        'sec
        '
        Me.sec.FillWeight = 110.7445!
        Me.sec.HeaderText = "Sector"
        Me.sec.Name = "sec"
        Me.sec.Width = 150
        '
        'men
        '
        Me.men.FillWeight = 110.7445!
        Me.men.HeaderText = "Mensaje"
        Me.men.Name = "men"
        Me.men.Width = 270
        '
        'ver
        '
        Me.ver.FillWeight = 35.53299!
        Me.ver.HeaderText = ""
        Me.ver.Name = "ver"
        Me.ver.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ver.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ver.Width = 40
        '
        'ListadoInformes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Tickets)
        Me.Name = "ListadoInformes"
        Me.Text = "ListadoInformes"
        CType(Me.Tickets, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button2 As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Tickets As DataGridView
    Friend WithEvents fecha As DataGridViewTextBoxColumn
    Friend WithEvents hora As DataGridViewTextBoxColumn
    Friend WithEvents cod As DataGridViewTextBoxColumn
    Friend WithEvents asun As DataGridViewTextBoxColumn
    Friend WithEvents sec As DataGridViewTextBoxColumn
    Friend WithEvents men As DataGridViewTextBoxColumn
    Friend WithEvents ver As DataGridViewButtonColumn
End Class
